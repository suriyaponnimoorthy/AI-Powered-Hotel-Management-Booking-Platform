from django.conf import settings
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models

from hotels.models import Room
from bookings.models import Booking


class Review(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="reviews")
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name="reviews")
    room = models.ForeignKey(Room, on_delete=models.CASCADE, related_name="reviews")
    rating = models.PositiveSmallIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    title = models.CharField(max_length=150)
    comment = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        unique_together = ("user", "booking", "room")

    def __str__(self):
        return f"{self.rating}★ - {self.title}"

    @property
    def is_verified_stay(self):
        return (self.booking.can_be_reviewed and self.booking.user_id == self.user_id
                and self.booking.booking_rooms.filter(room_id=self.room_id).exists())
