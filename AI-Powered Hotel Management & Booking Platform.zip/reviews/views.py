from rest_framework import serializers, viewsets, permissions
from .models import Review
from .serializers import ReviewSerializer


class ReviewViewSet(viewsets.ModelViewSet):
    queryset = Review.objects.select_related("user", "room").all()
    serializer_class = ReviewSerializer
    http_method_names = ["get", "post", "delete"]

    def get_permissions(self):
        if self.action in ("create", "destroy"):
            return [permissions.IsAuthenticated()]
        return [permissions.AllowAny()]

    def get_queryset(self):
        qs = super().get_queryset()
        if self.action == "destroy":
            return qs.filter(user=self.request.user)
        room_id = self.request.query_params.get("room")
        if room_id is not None:
            field = serializers.IntegerField(min_value=1, max_value=2**63 - 1)
            qs = qs.filter(room_id=field.run_validation(room_id))
        return qs
