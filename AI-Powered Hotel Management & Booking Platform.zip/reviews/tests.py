from datetime import date, timedelta
from decimal import Decimal

from django.test import TestCase
from rest_framework.test import APIClient

from accounts.models import User
from hotels.models import RoomType, Room
from bookings.models import Booking, BookingRoom
from .models import Review


class ReviewSubmissionTests(TestCase):
    def setUp(self):
        self.room_type = RoomType.objects.create(name="Standard Room", base_price=Decimal("4500"), max_guests=2)
        self.room = Room.objects.create(room_number="301", room_type=self.room_type, price_per_night=Decimal("4500"))
        self.user = User.objects.create_user(username="reviewer", password="pass1234!")
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)

    def _make_booking(self, status):
        booking = Booking.objects.create(
            user=self.user, check_in=date.today() - timedelta(days=10),
            check_out=date.today() - timedelta(days=7), number_of_guests=2,
            status=status, total_amount=Decimal("13500"),
        )
        BookingRoom.objects.create(booking=booking, room=self.room, price_at_booking=self.room.price_per_night)
        return booking

    def test_review_allowed_after_checkout(self):
        booking = self._make_booking(Booking.Status.CHECKED_OUT)
        resp = self.client.post("/api/reviews/", {
            "booking": booking.id, "room": self.room.id, "rating": 5,
            "title": "Great stay", "comment": "Loved it!",
        }, format="json")
        self.assertEqual(resp.status_code, 201, resp.data)
        self.assertTrue(Review.objects.filter(booking=booking).exists())

    def test_review_rejected_for_pending_booking(self):
        booking = self._make_booking(Booking.Status.PENDING)
        resp = self.client.post("/api/reviews/", {
            "booking": booking.id, "room": self.room.id, "rating": 5,
            "title": "Too soon", "comment": "Haven't stayed yet",
        }, format="json")
        self.assertEqual(resp.status_code, 400)
