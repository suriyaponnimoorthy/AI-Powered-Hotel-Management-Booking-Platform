from rest_framework import serializers
from .models import Review


class ReviewSerializer(serializers.ModelSerializer):
    user_name = serializers.CharField(source="user.get_full_name", read_only=True)
    is_verified_stay = serializers.ReadOnlyField()

    class Meta:
        model = Review
        fields = ["id", "user", "user_name", "booking", "room", "rating", "title",
                  "comment", "created_at", "is_verified_stay"]
        read_only_fields = ["id", "user", "created_at"]

    def validate_booking(self, booking):
        request = self.context["request"]
        if booking.user != request.user:
            raise serializers.ValidationError("You can only review your own bookings.")
        if not booking.can_be_reviewed:
            raise serializers.ValidationError("You can only review completed stays.")
        return booking

    def validate(self, attrs):
        if not attrs["booking"].booking_rooms.filter(room=attrs["room"]).exists():
            raise serializers.ValidationError({"room": "Review a room included in this booking."})
        return attrs

    def create(self, validated_data):
        validated_data["user"] = self.context["request"].user
        return super().create(validated_data)
