from django.db import models


class Offer(models.Model):
    title = models.CharField(max_length=150)
    description = models.TextField(blank=True)
    discount_percentage = models.DecimalField(max_digits=5, decimal_places=2)
    promo_code = models.CharField(max_length=30, unique=True)
    start_date = models.DateField()
    end_date = models.DateField()
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["-start_date"]

    def __str__(self):
        return f"{self.title} ({self.promo_code})"

    def is_valid_today(self):
        from django.utils import timezone
        today = timezone.localdate()
        return self.is_active and self.start_date <= today <= self.end_date
