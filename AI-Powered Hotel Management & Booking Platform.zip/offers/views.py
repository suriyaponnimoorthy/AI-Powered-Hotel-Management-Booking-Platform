from rest_framework import viewsets, permissions
from django.shortcuts import render
from .models import Offer
from .serializers import OfferSerializer


class OfferViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Offer.objects.filter(is_active=True)
    serializer_class = OfferSerializer
    permission_classes = [permissions.AllowAny]


def offers_page_view(request):
    offers = [o for o in Offer.objects.filter(is_active=True) if o.is_valid_today()]
    return render(request, "offers/list.html", {"offers": offers})
