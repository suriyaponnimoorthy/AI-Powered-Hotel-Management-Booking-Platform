from datetime import date, timedelta
from decimal import Decimal
from django.test import TestCase
from .models import Offer


class OfferValidityTests(TestCase):
    def test_offer_valid_within_date_range(self):
        offer = Offer.objects.create(
            title="Active Offer", discount_percentage=Decimal("15"), promo_code="ACTIVE15",
            start_date=date.today() - timedelta(days=1), end_date=date.today() + timedelta(days=10),
        )
        self.assertTrue(offer.is_valid_today())

    def test_offer_invalid_before_start(self):
        offer = Offer.objects.create(
            title="Future Offer", discount_percentage=Decimal("15"), promo_code="FUTURE15",
            start_date=date.today() + timedelta(days=5), end_date=date.today() + timedelta(days=10),
        )
        self.assertFalse(offer.is_valid_today())

    def test_offer_invalid_after_end(self):
        offer = Offer.objects.create(
            title="Expired Offer", discount_percentage=Decimal("15"), promo_code="EXPIRED15",
            start_date=date.today() - timedelta(days=20), end_date=date.today() - timedelta(days=1),
        )
        self.assertFalse(offer.is_valid_today())
