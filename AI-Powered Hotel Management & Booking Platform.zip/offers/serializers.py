from rest_framework import serializers
from .models import Offer


class OfferSerializer(serializers.ModelSerializer):
    is_valid_today = serializers.SerializerMethodField()

    class Meta:
        model = Offer
        fields = ["id", "title", "description", "discount_percentage", "promo_code",
                  "start_date", "end_date", "is_active", "is_valid_today"]

    def get_is_valid_today(self, obj):
        return obj.is_valid_today()
