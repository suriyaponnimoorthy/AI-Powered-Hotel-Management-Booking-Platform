# ABC Hotels operating runbook

Use the production environment with the same Django settings, secrets, and direct
PostgreSQL connection as the web service. Run the included migrations before
starting the web service or scheduling jobs. Use separate provider credentials
and a separate database for staging drills.

## Routine checks

- Monitor the public HTTPS `/health/` endpoint for HTTP 200 and a JSON status
  of `ok`. It checks database connectivity. Provider and storage readiness
  require their own checks.
- Schedule `python manage.py run_hotel_maintenance --limit 100` on your host.
  A five-minute interval is a starting point. Use a direct PostgreSQL connection
  because the overlap guard uses a session advisory lock.
- Alert when the scheduled command exits unsuccessfully or misses its expected
  schedule. It expires booking holds, deletes expired JWT records, and runs KYC
  cleanup and payment reconciliation when configured. The Razorpay batch is
  capped at 20 provider orders per invocation. Watch job duration and exceptions
  before increasing volume or using a shorter interval.
- Run `python manage.py hotel_operations_status` for aggregate exception counts.
  Use `--fail-on-backlog` for a separate monitor if every outstanding exception
  needs attention. Alert and triage thresholds should reflect your hotel’s
  expected workload. The output contains counts without guest details.

## Payment timeout or late capture

1. Open `/payment-operations/` using an authorized finance account. Review cases,
   failed refunds, and checkouts missing an order are shown before routine payments.
2. For a stalled checkout, compare the displayed receipt with the order in the
   Razorpay dashboard. Use the payment UUID in hyphenated form as the first
   command argument. The displayed 32-character receipt is also accepted.
3. Attach the existing order and run reconciliation:

   ```bash
   python manage.py recover_payment_order PAYMENT_UUID order_PROVIDER_ID
   python manage.py reconcile_payments --payment-id PAYMENT_UUID
   ```

   The recovery command fetches the existing order and compares its ID, receipt,
   amount, and currency. It never creates another charge or order. A captured
   payment on an expired or conflicting booking goes to staff review. Reconcile
   the existing payment before asking a guest to start a new checkout.
4. Review refund exceptions against the original provider payment and refund.
   Continue the existing refund workflow using its established idempotency key.

## KYC cleanup failures

- Check private bucket access and object permissions. A failed delete remains
  queued with downloads denied. Cleanup rotates through the backlog while
  respecting legal holds.
- Run `python manage.py purge_expired_documents --limit 100` after repairing
  access. Verify the backlog through `hotel_operations_status`.
- Record bucket and database restore results in your deployment notes. Restore
  to an isolated environment first. Test with synthetic documents and separate
  credentials. Keep encryption keys available through your approved secrets
  recovery process.

## Before first live use

Verify that the host executes the maintenance schedule and delivers failure
alerts. Walk through a sandbox checkout timeout, late capture, refund, KYC
upload and purge, SMTP reset delivery, and a restore drill. These procedures
need your deployed environment and provider accounts.
