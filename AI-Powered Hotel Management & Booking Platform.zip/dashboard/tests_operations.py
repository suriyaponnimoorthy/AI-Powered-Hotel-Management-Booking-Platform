import json
from datetime import timedelta
from io import StringIO
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.core.management import call_command, CommandError
from django.db import connection
from django.test import TestCase
from django.utils import timezone

from bookings.models import Booking
from kyc.models import Document
from kyc.storage import PrivateStorageUnavailable
from payments.models import Payment


class HotelOperationsTests(TestCase):
    def setUp(self):
        self.guest = get_user_model().objects.create_user("operations-guest")
        today = timezone.localdate()
        self.booking = Booking.objects.create(
            user=self.guest, check_in=today, check_out=today + timedelta(days=1), total_amount=1200,
        )

    def test_status_reports_aggregate_exceptions(self):
        Booking.objects.filter(pk=self.booking.pk).update(created_at=timezone.now() - timedelta(days=1))
        stdout = StringIO()
        with self.assertRaises(CommandError):
            call_command("hotel_operations_status", "--fail-on-backlog", stdout=stdout)
        self.assertEqual(json.loads(stdout.getvalue())["expired_holds"], 1)
        self.assertNotIn(self.guest.username, stdout.getvalue())

    def test_expiry_batches_keep_later_holds_for_next_run(self):
        other = Booking.objects.create(
            user=self.guest, check_in=self.booking.check_in, check_out=self.booking.check_out,
        )
        Booking.objects.filter(pk__in=[self.booking.pk, other.pk]).update(
            created_at=timezone.now() - timedelta(days=1),
        )
        call_command("expire_booking_holds", limit=1, stdout=StringIO())
        self.assertEqual(Booking.objects.filter(status=Booking.Status.PENDING).count(), 1)
        call_command("expire_booking_holds", limit=1, stdout=StringIO())
        self.assertFalse(Booking.objects.filter(status=Booking.Status.PENDING).exists())

    def test_failed_document_does_not_block_other_cleanup(self):
        now = timezone.now()
        first, second = [
            Document.objects.create(
                owner=self.guest, kind=Document.Kind.PASSPORT, content_type="image/jpeg",
                size=1, scanned_at=now, consent_at=now, expires_at=now - timedelta(days=days),
            )
            for days in (2, 1)
        ]
        with patch("kyc.management.commands.purge_expired_documents.delete_document") as delete:
            delete.side_effect = [PrivateStorageUnavailable(), True]
            with self.assertRaises(CommandError):
                call_command("purge_expired_documents", limit=1, stdout=StringIO())
            call_command("purge_expired_documents", limit=1, stdout=StringIO())
        self.assertEqual([call.args[0] for call in delete.call_args_list], [first.pk, second.pk])

    def test_recovery_verifies_order_and_is_idempotent(self):
        payment = Payment.objects.create(
            booking=self.booking, amount=1200, payment_method=Payment.Method.RAZORPAY,
        )
        order = {"id": "order_recover123", "receipt": "wrong", "amount": 120000, "currency": "INR"}
        with patch("payments.gateway.RazorpayGateway.fetch_order", return_value=order):
            with self.assertRaises(CommandError):
                call_command("recover_payment_order", str(payment.payment_id), order["id"], stdout=StringIO())
            payment.refresh_from_db()
            self.assertIsNone(payment.provider_order_id)
            order["receipt"] = payment.payment_id.hex
            call_command("recover_payment_order", str(payment.payment_id), order["id"], stdout=StringIO())
            call_command("recover_payment_order", str(payment.payment_id), order["id"], stdout=StringIO())
        payment.refresh_from_db()
        self.assertEqual(payment.provider_order_id, order["id"])
        self.assertEqual(payment.payment_status, Payment.Status.PENDING)
        with patch("payments.gateway.RazorpayGateway.order_payments", return_value={"items": []}) as fetch:
            call_command("reconcile_payments", "--payment-id", str(payment.payment_id), stdout=StringIO())
        fetch.assert_called_once_with(order["id"])

    def test_maintenance_runs_local_jobs(self):
        if connection.vendor != "postgresql":
            self.skipTest("PostgreSQL advisory lock required")
        stdout = StringIO()
        call_command("run_hotel_maintenance", limit=1, stdout=stdout)
        self.assertIn("Hotel maintenance completed.", stdout.getvalue())
