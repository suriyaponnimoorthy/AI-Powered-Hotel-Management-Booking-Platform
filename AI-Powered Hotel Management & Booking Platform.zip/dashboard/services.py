from django.db.models import Sum, Count, Avg, Q
from django.db.models.functions import TruncMonth
from django.utils import timezone

from bookings.models import Booking
from hotels.models import Room
from reviews.models import Review
from accounts.models import User


def customer_overview(user):
    bookings = Booking.objects.filter(user=user)
    upcoming = bookings.filter(
        status__in=[Booking.Status.CONFIRMED, Booking.Status.PENDING],
        check_in__gte=timezone.localdate(),
    ).prefetch_related("booking_rooms__room__room_type").order_by("check_in").first()
    return {
        "upcoming_booking": upcoming,
        "total_bookings": bookings.count(),
        "completed_stays": bookings.filter(status=Booking.Status.COMPLETED).count(),
        "reward_points": user.reward_points,
    }


def admin_key_metrics():
    bookings = Booking.objects.all()
    paid_statuses = [Booking.Status.CONFIRMED, Booking.Status.CHECKED_IN,
                      Booking.Status.CHECKED_OUT, Booking.Status.COMPLETED]

    total_revenue = bookings.filter(status__in=paid_statuses).aggregate(s=Sum("total_amount"))["s"] or 0
    total_bookings = bookings.count()
    available_rooms = Room.objects.filter(status=Room.Status.AVAILABLE, is_available=True).count()
    occupied_rooms = Room.objects.filter(status=Room.Status.OCCUPIED).count()
    cancelled_bookings = bookings.filter(status=Booking.Status.CANCELLED).count()
    total_customers = User.objects.filter(role=User.Role.CUSTOMER).count()
    avg_rating = Review.objects.aggregate(a=Avg("rating"))["a"] or 0
    total_rooms = Room.objects.count()
    occupancy_rate = round((occupied_rooms / total_rooms) * 100, 1) if total_rooms else 0

    return {
        "total_revenue": total_revenue,
        "total_bookings": total_bookings,
        "available_rooms": available_rooms,
        "occupied_rooms": occupied_rooms,
        "cancelled_bookings": cancelled_bookings,
        "total_customers": total_customers,
        "average_rating": round(avg_rating, 1),
        "occupancy_rate": occupancy_rate,
    }


def revenue_by_month(paid_statuses=None):
    paid_statuses = paid_statuses or [Booking.Status.CONFIRMED, Booking.Status.CHECKED_IN,
                                       Booking.Status.CHECKED_OUT, Booking.Status.COMPLETED]
    qs = (Booking.objects.filter(status__in=paid_statuses)
          .annotate(month=TruncMonth("created_at"))
          .values("month").annotate(total=Sum("total_amount")).order_by("month"))
    return [{"month": r["month"].strftime("%b %Y"), "total": float(r["total"])} for r in qs]


def bookings_by_month():
    qs = (Booking.objects.annotate(month=TruncMonth("created_at"))
          .values("month").annotate(count=Count("id")).order_by("month"))
    return [{"month": r["month"].strftime("%b %Y"), "count": r["count"]} for r in qs]


def most_booked_room_types(limit=5):
    from bookings.models import BookingRoom
    qs = (BookingRoom.objects.values("room__room_type__name")
          .annotate(count=Count("id")).order_by("-count")[:limit])
    return [{"room_type": r["room__room_type__name"], "count": r["count"]} for r in qs]


def rating_distribution():
    qs = Review.objects.values("rating").annotate(count=Count("id")).order_by("rating")
    dist = {i: 0 for i in range(1, 6)}
    for r in qs:
        dist[r["rating"]] = r["count"]
    return dist
