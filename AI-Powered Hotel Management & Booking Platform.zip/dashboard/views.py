import json
from django.contrib.auth.decorators import login_required, user_passes_test
from django.shortcuts import render, redirect
from django.http import HttpResponseForbidden

from bookings.models import Booking
from notifications.models import Notification
from hotels.models import Room
from . import services


def staff_required(view_func):
    return user_passes_test(lambda u: u.is_authenticated and u.is_staff_member,
                             login_url="accounts:login")(view_func)


@login_required
def customer_overview_view(request):
    context = services.customer_overview(request.user)
    return render(request, "dashboard/overview.html", context)


@login_required
def customer_bookings_view(request):
    bookings = Booking.objects.filter(user=request.user).prefetch_related(
        "booking_rooms__room", "services__service")
    return render(request, "dashboard/bookings.html", {"bookings": bookings})


@login_required
def customer_wishlist_view(request):
    # Wishlist is stored client-side (localStorage) or could be a Room M2M on User;
    # kept simple here: show all rooms so the template JS can manage favorites.
    rooms = Room.objects.filter(is_available=True)[:12]
    return render(request, "dashboard/wishlist.html", {"rooms": rooms})


@login_required
def customer_notifications_view(request):
    notifications = Notification.objects.filter(user=request.user)
    return render(request, "dashboard/notifications.html", {"notifications": notifications})


@login_required
def customer_checkin_view(request):
    from hotels.models import DigitalCheckIn
    from django.utils import timezone as tz
    from django.contrib import messages as dj_messages

    upcoming = Booking.objects.filter(
        user=request.user, status=Booking.Status.CONFIRMED,
        check_in__gte=tz.localdate(),
    ).order_by("check_in").first()

    existing_checkin = None
    if upcoming:
        existing_checkin = DigitalCheckIn.objects.filter(booking=upcoming).first()

    if request.method == "POST" and upcoming and not existing_checkin:
        from bookings.serializers import DigitalCheckInSerializer
        from rest_framework.exceptions import ValidationError

        serializer = DigitalCheckInSerializer(
            data={**request.POST.dict(), "booking": upcoming.pk},
            context={"request": request},
        )
        if serializer.is_valid():
            try:
                serializer.save()
            except ValidationError:
                dj_messages.error(request, "This booking is no longer eligible for check-in.")
            else:
                dj_messages.success(request, "You're ready for check-in!")
            return redirect("dashboard:checkin")
        dj_messages.error(request, "Please check the name and arrival details and try again.")

    return render(request, "dashboard/checkin.html", {
        "upcoming": upcoming, "existing_checkin": existing_checkin,
    })


@staff_required
def admin_dashboard_view(request):
    from bookings.models import Booking
    from hotels.models import SpecialRequest

    metrics = services.admin_key_metrics()
    recent_bookings = Booking.objects.select_related("user").prefetch_related(
        "booking_rooms__room__room_type").order_by("-created_at")[:6]
    pending_requests = SpecialRequest.objects.select_related("booking__user").filter(
        is_fulfilled=False).order_by("-created_at")[:5]

    context = {
        **metrics,
        "recent_bookings": recent_bookings,
        "pending_requests": pending_requests,
        "revenue_by_month": json.dumps(services.revenue_by_month()),
        "occupancy_chart_data": json.dumps({"occupied": metrics["occupied_rooms"], "available": metrics["available_rooms"]}),
    }
    return render(request, "dashboard/admin_overview.html", context)


@staff_required
def admin_rooms_view(request):
    rooms = Room.objects.select_related("room_type").all()
    return render(request, "dashboard/admin_rooms.html", {"rooms": rooms})


@staff_required
def admin_bookings_view(request):
    bookings = Booking.objects.select_related("user").prefetch_related("booking_rooms__room").all()
    status_filter = request.GET.get("status")
    if status_filter:
        bookings = bookings.filter(status=status_filter)
    return render(request, "dashboard/admin_bookings.html", {
        "bookings": bookings, "statuses": Booking.Status.choices,
    })


@staff_required
def admin_customers_view(request):
    from accounts.models import User
    customers = User.objects.filter(role=User.Role.CUSTOMER)
    return render(request, "dashboard/admin_customers.html", {"customers": customers})


@staff_required
def admin_offers_view(request):
    from offers.models import Offer
    offers = Offer.objects.all()
    return render(request, "dashboard/admin_offers.html", {"offers": offers})
