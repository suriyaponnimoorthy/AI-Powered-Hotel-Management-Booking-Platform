from django.conf import settings
from django.core.management import call_command
from django.core.management.base import BaseCommand, CommandError
from django.db import connection, DatabaseError


# Stable, application-specific PostgreSQL lock key for the scheduler.
MAINTENANCE_LOCK = 418704103


class Command(BaseCommand):
    help = "Run routine hotel jobs in bounded batches and report failures to the scheduler."

    def add_arguments(self, parser):
        parser.add_argument("--limit", type=int, default=100)

    def handle(self, *args, **options):
        limit = options["limit"]
        if not 1 <= limit <= 1000:
            raise CommandError("--limit must be between 1 and 1000.")
        if connection.vendor != "postgresql":
            raise CommandError("Scheduled hotel maintenance requires PostgreSQL.")
        with connection.cursor() as cursor:
            cursor.execute("SELECT pg_try_advisory_lock(%s)", [MAINTENANCE_LOCK])
            acquired = cursor.fetchone()[0]
        if not acquired:
            self.stdout.write("Maintenance already running. Skipped overlapping invocation.")
            return

        try:
            jobs = [
                ("expire_booking_holds", {"limit": limit}),
                ("flushexpiredtokens", {}),
            ]
            if settings.KYC_ENABLED or settings.PRIVATE_UPLOADS_USE_S3:
                jobs.append(("purge_expired_documents", {"limit": limit}))
            if settings.PAYMENT_PROVIDER == "razorpay":
                jobs.append(("reconcile_payments", {"limit": min(limit, 20)}))

            failed = []
            for name, arguments in jobs:
                try:
                    call_command(name, stdout=self.stdout, stderr=self.stderr, **arguments)
                except (CommandError, DatabaseError):
                    failed.append(name)
                    self.stderr.write(f"{name} failed. Check the service configuration before retrying.")
            if failed:
                raise CommandError("Failed maintenance jobs: " + ", ".join(failed))
            self.stdout.write("Hotel maintenance completed.")
        finally:
            with connection.cursor() as cursor:
                cursor.execute("SELECT pg_advisory_unlock(%s)", [MAINTENANCE_LOCK])
