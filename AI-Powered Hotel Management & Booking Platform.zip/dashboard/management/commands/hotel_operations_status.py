import json
from datetime import timedelta

from django.core.management.base import BaseCommand, CommandError
from django.db.models import Q
from django.utils import timezone

from bookings.models import Booking
from bookings.services import hold_cutoff
from kyc.models import Document
from payments.models import Payment, Refund


class Command(BaseCommand):
    help = "Report aggregate operational exceptions without guest or document details."

    def add_arguments(self, parser):
        parser.add_argument("--fail-on-backlog", action="store_true")

    def handle(self, *args, **options):
        now = timezone.now()
        counts = {
            "expired_holds": Booking.objects.filter(
                status=Booking.Status.PENDING, created_at__lte=hold_cutoff(),
            ).count(),
            "checkout_attempts_without_order": Payment.objects.filter(
                payment_method=Payment.Method.RAZORPAY, payment_status=Payment.Status.PENDING,
                provider_order_id__isnull=True, created_at__lte=now - timedelta(minutes=2),
            ).count(),
            "payments_for_review": Payment.objects.filter(requires_review=True).count(),
            "refund_exceptions": Refund.objects.filter(
                status__in=[Refund.Status.UNKNOWN, Refund.Status.FAILED],
            ).count(),
            "documents_due_for_purge": Document.objects.filter(legal_hold=False).exclude(
                status=Document.Status.DELETED,
            ).filter(Q(expires_at__lte=now) | Q(status=Document.Status.DELETE_PENDING)).count(),
        }
        self.stdout.write(json.dumps(counts, sort_keys=True))
        if options["fail_on_backlog"] and any(counts.values()):
            raise CommandError("Operational exceptions require attention.")
