from django.urls import path
from . import views

app_name = "admin_dashboard"

urlpatterns = [
    path("", views.admin_dashboard_view, name="overview"),
    path("rooms/", views.admin_rooms_view, name="rooms"),
    path("bookings/", views.admin_bookings_view, name="bookings"),
    path("customers/", views.admin_customers_view, name="customers"),
    path("offers/", views.admin_offers_view, name="offers"),
]
