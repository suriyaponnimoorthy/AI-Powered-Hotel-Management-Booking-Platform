from django.urls import path
from . import views

app_name = "dashboard"

urlpatterns = [
    path("", views.customer_overview_view, name="overview"),
    path("bookings/", views.customer_bookings_view, name="bookings"),
    path("wishlist/", views.customer_wishlist_view, name="wishlist"),
    path("notifications/", views.customer_notifications_view, name="notifications"),
    path("check-in/", views.customer_checkin_view, name="checkin"),
]
