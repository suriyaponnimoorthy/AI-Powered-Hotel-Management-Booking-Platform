#!/usr/bin/env bash
set -o errexit
python manage.py check --deploy --tag security --fail-level ERROR
exec gunicorn config.wsgi:application --bind "0.0.0.0:${PORT:-8000}" --workers "${WEB_CONCURRENCY:-2}" --timeout 60 --access-logfile - --access-logformat '%(m)s %(s)s %(D)s' --error-logfile -
