# Deploy ABC Hotels on Render

See **[SECURITY_SETUP.md](SECURITY_SETUP.md)** for the implemented Razorpay payment/refund and encrypted KYC setup.

This package retains the Django customer portal, employee dashboard, admin,
API, recommendation engine, and concierge. It adds Render configuration,
Gunicorn, WhiteNoise, DATABASE_URL support, HTTPS settings, a health endpoint,
and optional SMTP and private S3 upload storage.

## 1. Put the source on GitHub

1. Extract the ZIP on your computer.
2. Create a **private** GitHub repository called `abc-hotels`.
3. Upload the contents of the project directory to the repository root.
   `manage.py`, `requirements.txt`, `render.yaml`, `build.sh`, and `start.sh`
   must be at the top level, not inside another folder.
4. Include `.python-version`, `.gitignore`, and `.env.example`.
   Never upload your real `.env`, database, or credentials.

## 2. Create the Render deployment

1. Sign into https://dashboard.render.com/ using your own account.
2. Choose **New → Blueprint** and connect the repository.
3. Select the branch containing the files and use `render.yaml`.
4. Review Render's cost summary before applying. This configuration selects
   a paid Starter web service and Basic PostgreSQL database in Singapore.
   It does not purchase anything until you apply it in your account.
5. Apply the Blueprint. Render installs dependencies, collects static assets,
   applies database migrations, then starts Gunicorn.
6. When the web service says **Live**, open the exact URL Render provides.
   Your actual hostname may differ from `abc-hotels.onrender.com`.

The Blueprint generates SECRET_KEY and JWT_SIGNING_KEY and connects DATABASE_URL automatically.
Render supplies RENDER_EXTERNAL_HOSTNAME; the project uses it for allowed
hosts and trusted CSRF origins. Keep DEBUG=False. The web frontend is public
at the Render URL; customer and staff pages still require application login.
Do not share the URL until you have completed setup if it is only a test.

## 3. Create your administrator and hotel inventory

Open the web service's **Shell**, then run:

```bash
python manage.py createsuperuser
```

Choose your own username and strong password at the prompts. The existing
project has a separate role field, so also set your administrator's role
(replace YOUR_ADMIN_USERNAME with the username you just created):

```bash
python manage.py shell -c "from accounts.models import User; u=User.objects.get(username='YOUR_ADMIN_USERNAME'); u.role=User.Role.ADMIN; u.save(update_fields=['role'])"
```

Visit `/admin/`
to create room types, amenities, rooms, policies, and services. Visit
`/admin-dashboard/` for the employee dashboard. A superuser can access both.
Use `/accounts/register/` for a normal customer account and `/dashboard/`
for the customer portal.

The demo seeder requires DEBUG=True and explicit opt-in. Use a separate local database for demo data.
A new deployment starts with an empty database. The uploaded ZIP contains no
existing bookings, customer records, or uploaded media to migrate.

## 4. Features to configure before live business use

| Feature | Default | Required action |
| --- | --- | --- |
| Chat concierge | Offline mock responses | Set AI_PROVIDER, AI_MODEL, AI_API_KEY using the Render Environment page; select a provider/model supported by `ai_assistant/services.py`. |
| Recommendations | Existing database-driven ranking | Add real room inventory; AI model keys are not needed for the existing ranking logic. |
| Payments | Disabled until configured | Razorpay checkout, verified webhooks and full refunds are implemented. Follow SECURITY_SETUP.md and verify sandbox/live behavior with your credentials. Do not enable mock payments for real purchases. |
| Password reset email | Disabled until configured | Set EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend, EMAIL_HOST, EMAIL_PORT, EMAIL_HOST_USER, EMAIL_HOST_PASSWORD, EMAIL_USE_TLS, DEFAULT_FROM_EMAIL for your verified mail provider. |
| Uploaded photographs | Local development storage | Configure private S3 storage below before uploading. Render's local filesystem is temporary; it does not preserve uploads across restarts/deploys. |
| Static editorial photographs | Included | WhiteNoise serves these automatically. |

### Persistent uploaded images

Create a private S3 bucket and a restricted IAM identity with list access to
that bucket and get/put/delete access to its objects. In Render Environment,
set the following values and redeploy:

```text
USE_S3=True
AWS_STORAGE_BUCKET_NAME=your-bucket-name
AWS_S3_REGION_NAME=your-bucket-region
AWS_ACCESS_KEY_ID=your-access-key
AWS_SECRET_ACCESS_KEY=your-secret-key
```

The app generates signed image URLs; do not make the bucket public.
AWS_S3_ENDPOINT_URL is optional for S3-compatible storage. Test an image upload
and display after a redeploy. Profile and room uploads must not use the default
local backend on Render. No existing uploaded files are included in this ZIP.

### Custom domain

Add the domain in Render's Settings page and follow its DNS instructions.
Set ALLOWED_HOSTS to the exact domain names separated by commas, and
CSRF_TRUSTED_ORIGINS to their full HTTPS origins separated by commas.
The automatic Render hostname remains supported. Never use `*` as a shortcut.

## 5. Verify the live deployment

- `/health/` returns `{"status":"ok"}` with a working database connection.
- Homepage, room list, and gallery load their CSS, JavaScript, and images.
- A new customer can register, log in, and view their own dashboard.
- The administrator can manage inventory and open the employee dashboard.
- Test real email, AI, uploaded media, and the payment integration separately
  after enabling them. Do not use real purchases to test the mock gateway.
- Configure monitoring and database backups in the hosting account.

The existing `expire_booking_holds` management command may be run through
an authenticated scheduler. Active inventory checks already account for expired
holds, but cleanup is still useful for stored booking state. No paid scheduler
is provisioned by this Blueprint.

## Troubleshooting

| Symptom | Check |
| --- | --- |
| Build cannot find manage.py | Files are nested; put the project contents at the repository root. |
| Invalid HTTP_HOST | ALLOWED_HOSTS or RENDER_EXTERNAL_HOSTNAME is missing or incorrect. |
| CSRF failure on custom domain | Add its `https://` origin to CSRF_TRUSTED_ORIGINS. |
| Database migration fails | Inspect pre-deploy logs and DATABASE_URL; web/database regions must match. |
| SSL redirect loop | TRUST_PROXY_HTTPS=True is intended for Render's trusted HTTPS proxy. |
| Missing uploaded images after restart | Configure S3; static hosting does not preserve user uploads. |
| Payment is unavailable | Expected with ALLOW_MOCK_PAYMENTS=False until a real gateway is implemented. |

## Verification in this package

- The original suite and new payment/KYC security tests run locally; see SECURITY_SETUP.md for integration limits.
- No missing model migrations; SQLite migrations and production HTTP/static
  smoke checks are tested locally.
- Static collection succeeds with compressed manifest storage.
- Production Django checks retain existing OpenAPI schema warnings and
  advisory HSTS subdomain/preload warnings. These do not block startup.
- A real Render deployment and live PostgreSQL concurrency behavior have not
  been verified; they require your hosting account.

Official setup reference: https://render.com/docs/deploy-django
Blueprint reference: https://render.com/docs/blueprint-spec

See [OPERATIONS.md](OPERATIONS.md) for scheduling, monitoring and recovery procedures.
