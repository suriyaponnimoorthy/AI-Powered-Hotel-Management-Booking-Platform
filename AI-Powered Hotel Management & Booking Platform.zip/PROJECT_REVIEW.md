> **Current implementation update:** Razorpay checkout, signed webhooks, full-refund reconciliation, encrypted KYC storage, permissioned review/download, malware scanning integration and retention cleanup are implemented. See SECURITY_SETUP.md. The earlier findings below document the prior review and roadmap. Current validation: all 146 tests passed on local PostgreSQL 16.2, including both concurrency tests. Live provider/storage/scanner verification remains required.

# ABC Hotels: project review and AI upgrade

Reviewed 31 October 2026 against the supplied ZIP. This is a source review and local functional validation, not a complete penetration test. The first update improved recommendations and the concierge. The second update strengthens booking creation, status changes, reservation expiry and demo-payment handling. Remaining production work is identified below.

## Main drawbacks and recommended improvements

| Priority | Finding | Current status and next improvement |
|---|---|---|
| Critical | General PATCH/DELETE could bypass booking validation or erase history. | Fixed for REST endpoints: only GET/POST/HEAD/OPTIONS are enabled. BookingSerializer is read-only. Django admin booking mutations are disabled. Date changes currently require cancellation and a new booking; no rescheduling/refund workflow is provided. |
| Critical | Booking writes lacked a transaction and inventory locks. | Shared creation now locks selected Room rows in ascending ID order, rechecks dates/capacity/availability and current prices, and atomically writes bookings, room/service lines and notification. PostgreSQL concurrency regression test is included but was skipped locally on SQLite. Direct database scripts can still bypass the workflow; database exclusion constraints are future work. |
| Critical | Payments were mock-only with no state/retry guard. | Both payment endpoints now use a transaction and a locked booking, reject expired/cancelled/invalid states and return the existing confirmation on a successful retry. Demo payments default off when DEBUG=False unless explicitly overridden. Razorpay orders, verified webhooks, full refunds and reconciliation have now been implemented; see SECURITY_SETUP.md. |
| High | Pending holds never expired; date/capacity validation was incomplete. | Fixed for web/API creation. Pending holds release inventory after BOOKING_HOLD_MINUTES (default 15), even before cleanup runs. Past/reversed dates, excess guests, duplicate rooms/services and unavailable service IDs are rejected. Cleanup command cancels expired pending rows once and notifies the owner. |
| High | Deployment settings default to demo configuration. | Still requires production work: external secrets, host allowlists, HTTPS, secure cookies, appropriate HSTS, backups, monitoring and restore testing. Do not deploy seeded demo accounts. |
| High | Original AI endpoints had weak cost/reliability controls. | Scoped limits, bounded role-validated history, owner-scoped resume and provider fallback were added. Shared cache, proxy limits, cost budgets, abuse monitoring and retention controls remain future work. |
| High | AI interfaces interpolated untrusted strings into HTML. | Touched chat/recommendation/stay-planning interfaces now use textContent/DOM construction. Audit other dynamic HTML and add a content security policy before launch. |
| Medium | Wishlist model/API exist but interface uses localStorage; dashboard shows available rooms. | Still open: use the Wishlist API as the source of truth and reconcile anonymous saves after login. |
| Medium | Email uses console backend; notifications have no external delivery worker. | Still open: configure transactional email, background retries and delivery tracking. |
| Medium | Ratings aggregate per room; ranking scans eligible inventory; API-schema warnings remain. | Still open: annotate ratings, prefetch, profile query costs and document request/response schemas. |
| Medium | Identity numbers are plain text; no chat-retention/deletion workflow. | Still open: minimize collection, restrict access, protect sensitive fields/backups and define retention/deletion. Digital pre-check-in is still allowed for pending bookings; it does not physically check in a guest or change reservation status. |


## Recommendation system now included

Open **Room matches** in the navigation (`/recommendations/`).

The implementation is an explainable content-based recommender, not a trained collaborative-filtering model. It works without historical bookings or an API key:

1. Treat guest count and maximum budget per room per night as hard filters.
2. Exclude disabled, maintenance and inactive inventory.
3. If both dates are supplied, exclude overlapping pending, confirmed and checked-in reservations; adjacent stays remain eligible.
4. Rank by the proportion of requested amenities matched, then ascending price and stable room ID.
5. Return reasons, unmatched preferences and an explicit indication of whether dates were checked.

The displayed percentage measures amenity coverage only. It is not an AI confidence score, review score, or probability of satisfaction. Unmatched preferences are soft; accessibility or other mandatory requirements need explicit structured inventory fields and hard filters before promising suitability. Results suggest one room; group allocation is not implemented.

Main files: `ai_assistant/recommendations.py`, `ai_assistant/views.py`, `templates/recommendations.html`, `static/js/recommendations.js`.

## Interactive concierge now improved

The existing chat widget remains available across the website. It uses hotel room/policy/service records, returns room links and handles follow-up constraints. Signed-in chats persist; resuming by conversation ID loads owner-scoped messages from the server. Anonymous history remains in the page's memory and disappears on reload.

Without an API key, the concierge provides deterministic English answers from recorded policies/services and room matches. This is offline assistance, not live language-model inference. With the existing Anthropic configuration, the concierge sends grounded context to the provider. Provider timeout/failure falls back to recorded hotel information. Live provider calls were not tested with a real key.

Example: `2 guests under ₹8000 with breakfast from 2026-12-10 to 2026-12-13`.

Date parsing currently supports two explicit ISO dates. Natural-language dates, robust negation/corrections, multilingual parsing, voice interaction and automatic conversation selection after reload remain future improvements. The bounded history uses at most 12 messages; older constraints may drop out. The bot cannot book, pay, cancel, or read private booking details. LLM prompt rules reduce risk but do not guarantee freedom from hallucinations or prompt injection; show authoritative room cards and require normal booking confirmation.

Stay planning now has a useful offline itinerary and clear room-subtotal labels. The legacy `days` API field is treated as nights, matching the existing calculation/tests. Stay planning does not accept/check booking dates, and taxes/add-ons are excluded from the displayed room subtotal.

## Suggested next AI stages

- Add structured preference profiles with opt-in storage and anonymous onboarding for new guests.
- Retrieve relevant policy chunks with embeddings when hotel documents outgrow the current small structured dataset; include source links and last-updated timestamps.
- After collecting consented impressions, clicks, saves and completed stays, evaluate a hybrid content/collaborative model. Do not train on payment or identity details.
- Measure Recall@K and NDCG on time-separated data; monitor zero-result rate, clicks, completed bookings, cancellations, latency and cost. Compare against the current price/content baseline before shipping a trained model.
- Add user feedback and human-support routing; define confidence and escalation rules for missing policy information.

## Setup and validation

Use Python 3.12 or later in a virtual environment. Install `requirements.txt`, copy `.env.example` to `.env`, then run:

```bash
python manage.py migrate
python manage.py seed_data --allow-demo-data
python manage.py runserver
```

`seed_data` is for local demos only. It refuses production settings and creates demo accounts with disabled passwords.

For live AI, configure `AI_PROVIDER=anthropic`, `AI_API_KEY` and a model supported by your provider account in `.env`. Keep the key on the server. No API key is needed for ranking or offline assistance. Only the Anthropic and mock dispatchers are implemented; the original settings comment mentioning OpenAI does not represent a working adapter.

Validation: 90 Django tests discovered on Python 3.12 with the original pinned requirements: 89 passed and 1 PostgreSQL concurrency test skipped on SQLite. The suite includes the original 52, 16 AI tests and 22 booking-safety/concurrency tests. Django system checks pass; no migrations are required. JavaScript syntax checks passed in the earlier AI update. Live AI, live payments, full browser-to-backend workflows and PostgreSQL locking remain unverified. Browser layouts and client-side menu/gallery/concierge controls were checked using rendered page snapshots in the UI update; see UI_DESIGN_NOTES.md. Deployment checks still report security/API-schema warnings.

## Second update: booking workflow operations

- Web and REST endpoints share create/cancel/payment rules. Generic date editing and deletion are disabled. Staff physical check-in requires CONFIRMED status and a date inside the booked stay; checkout requires CHECKED_IN. Existing staff API permissions are retained.
- Current price, service availability and offer validity are checked again when saving, after inventory locks are acquired. All creation writes and initial notification roll back together if one fails.
- Reservation holds use `created_at + BOOKING_HOLD_MINUTES`; no new database column is needed. Changing this setting changes the calculated expiry for existing pending records too. Existing old unpaid pending rows stop blocking inventory immediately after deploying this version; review these records before rollout.
- Run `python manage.py expire_booking_holds` periodically using your deployment's scheduler. It is safe to repeat and skips rows already paid/cancelled. Inventory is released by availability queries even when this command is not scheduled. No scheduler was configured in this deliverable.
- Confirmed, checked-in and historical completed stays do not expire. Cancelling a paid booking records cancellation but does not perform an automatic refund.
- `.env.example` leaves ALLOW_MOCK_PAYMENTS commented. With DEBUG=True demo payments work; with DEBUG=False they are disabled unless explicitly opted in. Mock payment is never a real charge. Do not expose the demo gateway on a real booking deployment.
- Use PostgreSQL for a multi-user deployment. SQLite remains a local demo database and does not provide the row-locking guarantees used here. Run `USE_POSTGRES=True python manage.py test bookings.tests_security.ConcurrentReservationTests` after configuring DATABASE_* credentials to exercise the included two-request race test.
- The management command, REST mutations and web mutations use locked/atomic shared workflows. Django admin booking mutations are disabled so inventory cannot be changed there without validation. Demo seeding and any custom scripts are privileged offline operations and must not run against a live booking database.


Technical references: Django QuerySet locking documentation (https://docs.djangoproject.com/en/dev/ref/models/querysets/) explains transaction-scoped locks and that SQLite does not implement SELECT FOR UPDATE. DRF throttling documentation (https://www.django-rest-framework.org/api-guide/throttling/) states that application throttling is not a complete brute-force/DoS defence.
