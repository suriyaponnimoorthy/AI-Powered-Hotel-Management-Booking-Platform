# Payments and private identity documents

This version implements Razorpay hosted checkout and full-refund processing,
plus encrypted document uploads and manual hotel identity review. No card data
is collected by Django. Stripe is not implemented. No live charges were made.

## Enable payments

In your hosting account's environment settings, set:

```text
PAYMENT_PROVIDER=razorpay
RAZORPAY_KEY_ID=your-test-key-id
RAZORPAY_KEY_SECRET=your-test-api-secret
RAZORPAY_WEBHOOK_SECRET=your-separate-webhook-secret
ALLOW_MOCK_PAYMENTS=False
```

Start with Razorpay test mode. Configure automatic payment capture in the
Razorpay dashboard. Add a webhook endpoint:

```text
https://YOUR-HOST/api/payments/webhook/razorpay/
```

Subscribe to `payment.captured`, `refund.created`, `refund.processed`, and
`refund.failed`. Match the webhook secret to RAZORPAY_WEBHOOK_SECRET. The
webhook uses an HMAC over the original request bytes; other browser/API
mutations require authenticated sessions/JWT and session CSRF protection.

Run `python manage.py check_payment_configuration`. This checks configuration
without making any charges and does not verify merchant activation.

Customers start checkout on the booking confirmation page. The backend creates
an order with the server-calculated booking amount; the hosted payment form
receives only the public key and order information. Checkout results are verified
by HMAC and a server-to-server payment fetch. Signed capture webhooks provide
recovery when the customer closes their browser. Captured funds confirm a
reservation only when the hold/inventory is still valid. Late, conflicting or
cancelled reservations require staff review and do not silently reserve rooms.

### Full refunds

Grant trusted finance users `payments.issue_refund` through Django admin
Groups/Users. A generic STAFF role alone does not grant this permission.
The finance console is `/payment-operations/`. Cancel the booking first, or
use a payment already flagged for review. Enter a reason to issue a full refund.

Each payment has one durable refund request. Retries reuse its UUID in the
provider's `X-Refund-Idempotency` header and the original amount/body. A timeout
leaves the request UNKNOWN, never successful. The console can reconcile the
same request. Pending, failed and processed states remain distinct. Full refunds
processed at the provider cancel pending/confirmed inventory. Refunds are not
automatically issued for customer cancellations: finance must approve them.
Partial refunds, multiple externally-created refunds and unexpected provider
amounts are flagged for manual investigation; this implementation supports one
full refund per payment.

Schedule the following command in your hosting scheduler, for example every
five minutes (no scheduled service has been purchased or activated here):

```bash
python manage.py reconcile_payments --limit 100
```

It fetches order payment/refund state to recover missed webhooks; it does not
create new refunds. Monitor nonzero exits and payment audit records. The limit
bounds one run. Least-recently-checked payments are selected first so repeated
runs rotate through all eligible orders without starving newer ones. Increase
the limit (up to 1000) or use a queue worker as transaction volume grows.

After sandbox verification, replace test credentials with live credentials,
configure the live webhook separately and run a controlled real transaction
and refund. Merchant activation, gateway payment-method eligibility, bank
settlement and actual live refunds are external setup, not verified locally.

## Enable encrypted private identity uploads

The customer page is `/identity/`; the review queue is `/identity/review/`.
Documents are manually checked by authorized staff; there is no automated
identity-provider validation, biometric matching or government database lookup.
Document approval is informational and does not automatically block or permit
all booking/check-in paths.

Create a **separate private S3 bucket** for identity files. Block all public
access. Grant the app identity only list/get/put/delete for that bucket/prefix.
Use a non-versioned bucket for direct file deletion. If organizational policies
require versioning, configure non-current-version deletion and backup retention
explicitly; deleting a current object alone does not erase historical copies.
Use encryption at rest; the application requests AES256 server-side encryption
by default, or KMS when KYC_S3_KMS_KEY_ID is set. Files are additionally encrypted
in the application before they reach storage. Never use a public CDN or a public
bucket for identity files.

Generate an encryption key on your machine:

```bash
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

Set these environment variables using your hosting secrets interface:

```text
KYC_ENABLED=True
KYC_ENCRYPTION_KEYS=your-generated-fernet-key
KYC_RETENTION_DAYS=30
PRIVATE_UPLOADS_USE_S3=True
KYC_S3_BUCKET=your-private-identity-bucket
KYC_S3_REGION=your-bucket-region
AWS_ACCESS_KEY_ID=restricted-storage-key
AWS_SECRET_ACCESS_KEY=restricted-storage-secret
KYC_SCANNER=clamd
CLAMD_HOST=your-private-scanner-host
CLAMD_PORT=3310
```

Optional: set KYC_S3_KMS_KEY_ID for AWS KMS encryption or KYC_S3_ENDPOINT for
compatible storage. Verify that the storage service supports the requested
server-side encryption. Existing general image uploads use USE_S3 and
AWS_STORAGE_BUCKET_NAME separately; identity storage does not expose file URLs.

### Malware scanner

Run a maintained ClamAV daemon with current signature databases, reachable on
a trusted private network only. TCP clamd does not authenticate clients; never
publish port 3310 to the internet. Set appropriate stream-size/time limits for
5 MB inputs and monitor signature updates. Scanner timeouts/errors reject the
upload, rather than accepting unscanned documents. `KYC_SCANNER=disabled` is
accepted only with DEBUG=True for local development; never disable it live.

A production host must have private S3 storage, valid encryption keys and
scanning configured before enabling uploads. Django system checks reject
missing core configuration. Run `python manage.py check --tag security`.
Storage connectivity and an actual malware scan still require a deployment test.

### Access, validation and audit

- Owners can upload, download, inspect status and request deletion of their
  own documents. They cannot access another user's files or approve their own.
- Explicit permissions `kyc.review_document` and
  `kyc.download_private_document` grant separate review/download access. Assign
  only the permissions each trusted staff member needs. Superusers have both.
- Reviewers must enter an access reason for downloads and a note for decisions.
- `kyc.manage_document_hold` can place/release retention holds via the API.
  It does not itself grant document download access.
- Downloads use authenticated POST requests and return attachment/no-store/
  nosniff headers. Neither object keys nor public/presigned document URLs are
  returned by APIs. Ciphertext remains unusable without the encryption key.
- Files are limited to 5 MB, JPEG/PNG or simple PDFs of up to 10 pages.
  Actual file content is checked; names and supplied MIME types are not trusted.
  Images are re-encoded to strip metadata. PDFs containing active actions,
  JavaScript, forms, embedded files or links are rejected.
- Identity request uploads use bounded memory instead of Django's default
  plaintext temporary-upload files. Files are scanned before storage.
- Uploads, downloads, denied access, review, holds and deletions create audit
  entries without filenames or identity numbers. Audit views in Django admin
  are read-only. Database administrators still control the database; external
  immutable audit storage is not included.
- Uploads require explicit consent. Maximum five undeleted files per owner and ten upload attempts per hour,
  enforced with a database lock shared by HTML/API requests.
  Do not enter full identity numbers in notes or collect unneeded documents.

### Retention, deletion and keys

The default retention period is 30 days (configurable 1–365). Choose an
appropriate policy for your hotel's requirements before accepting documents.
Expired documents cannot be downloaded even before cleanup runs. Schedule:

```bash
python manage.py purge_expired_documents
```

Run at least daily and monitor failures. Holds preserve files but do not extend
ordinary download access beyond expiry. Deletion clears the blob key, content
hash, byte size and review note; a minimal record/audit trail remains. Failed
storage deletion blocks downloads and is retried by the cleanup command.
Backups, bucket object versions and already-downloaded copies require their
own retention procedures.

Back up encryption keys separately and restrict access to them. Losing every
key permanently loses document access. For rotation, put a new key first in
KYC_ENCRYPTION_KEYS and retain old keys after it until all files encrypted with
those keys are deleted/expired or migrated. Existing files are not automatically
re-encrypted. Never put real keys or identity files into Git or the ZIP.

Local development may use encrypted files in `private_uploads/` with DEBUG=True.
That directory must remain outside public media/static roots and is ignored by
Git. Production refuses the local private-storage backend.

## APIs

| Endpoint | Method | Purpose |
| --- | --- | --- |
| `/api/payments/checkout/<booking_uuid>/` | POST | Owner creates/reuses a Razorpay order |
| `/api/payments/verify/<payment_pk>/` | POST | Owner submits signed checkout result |
| `/api/payments/refund/<payment_pk>/` | POST | Authorized finance approves/reconciles a full refund |
| `/api/payments/webhook/razorpay/` | POST | Provider-signed payment/refund events |
| `/api/identity/` | GET / POST | List authorized metadata / upload file, kind, consent |
| `/api/identity/<uuid>/download/` | POST | Owner or authorized reviewer downloads; reviewer supplies reason |
| `/api/identity/<uuid>/review/` | POST | Authorized reviewer submits status and note |
| `/api/identity/<uuid>/delete_file/` | POST | Owner requests deletion |
| `/api/identity/<uuid>/hold/` | POST | Authorized staff supplies enabled boolean and reason |
| `/api/identity/<uuid>/audit/` | GET | Owner or reviewer reads bounded audit history |

Local verification: all 146 tests passed on local PostgreSQL 16.2, including both concurrency tests. Migration checks, dependency compatibility and static collection pass.

The S3/ClamAV production path and live Razorpay test mode were not exercised
without your service credentials. GitHub Actions includes PostgreSQL services
and the full test suite, including concurrency tests skipped on SQLite.

References:
https://razorpay.com/docs/payments/payment-gateway/web-integration/standard/integration-steps
https://razorpay.com/docs/api/refunds/normal-refunds-idempotent
https://razorpay.com/docs/webhooks/validate-test/
https://docs.clamav.net/manual/Usage/Scanning.html

## Security remediation rollout

- Apply the migrations before serving traffic. The check-in migration drops legacy ID type and number columns. Retained database backups and logs can still contain old values. Review their access and retention separately.
- If an earlier demo seeder ran against a shared database, review existing demo accounts and the Hotel Admin and Hotel Staff groups. Remove unintended group membership and disable seeded credentials. The updated seeder rejects staff username collisions.
- Configure SMTP to deliver password resets. The default backend discards email and reset tokens are suppressed when console mail is selected. Restrict access to old application logs if the old console backend was used.
- Web and API authentication share database-backed counters per network address. Login allows 20 POST requests per five-minute window. Password reset allows 10 per hour. Registration allows 12 per hour. The app uses the immediate peer address and ignores client-supplied forwarding headers. Behind a reverse proxy this can create a shared limit, so verify addressing and configure per-client rate limiting at the trusted edge.
- Reservations allow 1–30 nights, arrival within 365 days, and up to five rooms per account across active unpaid holds. Existing holds continue to expire using the established hold period.
- Checkout persists an order attempt before contacting Razorpay outside the booking transaction. If order creation times out or its response cannot be verified, the attempt remains visible as a pending payment without a provider order ID. Check the provider dashboard using the stored payment UUID without hyphens as the receipt. This checkout is blocked from submitting another order for the same reservation. After checking for any payment or capture, staff can direct the guest to a new reservation if appropriate.

## Production settings and API token rollout

- Copy .env.example for local development. It explicitly enables DEBUG. A deployment without DEBUG uses production settings and requires PostgreSQL, exact allowed hosts, HTTPS redirects, HSTS, a Django secret and a separate JWT signing secret.
- The Render Blueprint generates both secrets. Render's base64-encoded 256-bit values are supported. For a manual deployment, generate independent random values using your hosting secret manager. Keep any valid existing Django secret when updating an existing service.
- Apply migrations before starting the service. Simple JWT creates tables for refresh-token tracking and revocation. Existing API clients must sign in again and store the replacement refresh token after every refresh. Access tokens expire after 15 minutes. Password changes invalidate both access and refresh tokens. API clients can POST a refresh token to /api/auth/token/revoke/ to revoke it. Schedule Django's flushexpiredtokens command daily to remove expired token records.
- Account, admin, booking, payment and identity responses use private no-store caching. Production disables interactive API docs. CORS requires explicit allowed origins. The baseline content policy prevents framing, object embeds and external base URLs. Gunicorn access logs omit request URLs and query strings, including password reset token paths. Check host and reverse proxy logging separately.
- Production refuses mock payments and requires independent Razorpay webhook credentials when checkout is enabled. KYC and ordinary media must use separate buckets. Custom production storage endpoints require HTTPS.
- The GitHub Actions workflow includes a dependency advisory check. Require that check and PostgreSQL tests in branch protection before deploying from the repository. The local advisory requests to PyPI and OSV timed out. Run the workflow in GitHub to obtain an advisory result.

Production-mode checks passed locally against PostgreSQL. Django reports two domain-policy advisories because HSTS does not cover subdomains or request preload. Enable those options only after confirming the HTTPS policy for the full domain.
