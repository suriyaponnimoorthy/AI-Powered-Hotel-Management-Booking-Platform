from datetime import date, timedelta
from decimal import Decimal

from django.test import TestCase
from rest_framework.test import APIClient

from accounts.models import User
from hotels.models import RoomType, Room
from offers.models import Offer
from .models import Booking


class BookingWorkflowTests(TestCase):
    def setUp(self):
        self.room_type = RoomType.objects.create(
            name="Suite", base_price=Decimal("12000"), max_guests=4, bed_type="King", room_size="600 sq.ft"
        )
        self.room = Room.objects.create(
            room_number="201", room_type=self.room_type, floor=2,
            price_per_night=Decimal("12000"), is_available=True,
        )
        self.user = User.objects.create_user(username="traveler", password="pass1234!")
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)

        self.check_in = (date.today() + timedelta(days=10)).isoformat()
        self.check_out = (date.today() + timedelta(days=12)).isoformat()

    def test_create_booking_recalculates_price_serverside(self):
        # Even if a malicious client claims a different total, the server
        # ignores it entirely — it isn't even part of the request schema.
        resp = self.client.post("/api/bookings/", {
            "room_ids": [self.room.id],
            "check_in": self.check_in,
            "check_out": self.check_out,
            "number_of_guests": 2,
        }, format="json")
        self.assertEqual(resp.status_code, 201, resp.data)
        booking = Booking.objects.get(booking_id=resp.data["booking_id"])
        self.assertEqual(booking.subtotal, Decimal("24000"))  # 2 nights x 12000

    def test_double_booking_is_rejected(self):
        self.client.post("/api/bookings/", {
            "room_ids": [self.room.id], "check_in": self.check_in,
            "check_out": self.check_out, "number_of_guests": 2,
        }, format="json")
        # First booking is PENDING which is still an "active" status, so a
        # second overlapping booking for the same room must be rejected.
        resp2 = self.client.post("/api/bookings/", {
            "room_ids": [self.room.id], "check_in": self.check_in,
            "check_out": self.check_out, "number_of_guests": 2,
        }, format="json")
        self.assertEqual(resp2.status_code, 400)

    def test_promo_code_applies_discount(self):
        Offer.objects.create(
            title="Test Offer", discount_percentage=Decimal("10"), promo_code="TEST10",
            start_date=date.today() - timedelta(days=1), end_date=date.today() + timedelta(days=30),
        )
        resp = self.client.post("/api/bookings/", {
            "room_ids": [self.room.id], "check_in": self.check_in,
            "check_out": self.check_out, "number_of_guests": 2, "promo_code": "TEST10",
        }, format="json")
        self.assertEqual(resp.status_code, 201, resp.data)
        self.assertEqual(Decimal(resp.data["discount"]), Decimal("2400.00"))

    def test_invalid_promo_code_rejected(self):
        resp = self.client.post("/api/bookings/", {
            "room_ids": [self.room.id], "check_in": self.check_in,
            "check_out": self.check_out, "number_of_guests": 2, "promo_code": "NOPE",
        }, format="json")
        self.assertEqual(resp.status_code, 400)

    def test_cancel_booking(self):
        resp = self.client.post("/api/bookings/", {
            "room_ids": [self.room.id], "check_in": self.check_in,
            "check_out": self.check_out, "number_of_guests": 2,
        }, format="json")
        booking_pk = resp.data["id"]
        cancel_resp = self.client.post(f"/api/bookings/{booking_pk}/cancel/")
        self.assertEqual(cancel_resp.status_code, 200)
        self.assertEqual(cancel_resp.data["status"], "CANCELLED")

    def test_cancel_already_cancelled_booking_fails(self):
        resp = self.client.post("/api/bookings/", {
            "room_ids": [self.room.id], "check_in": self.check_in,
            "check_out": self.check_out, "number_of_guests": 2,
        }, format="json")
        booking_pk = resp.data["id"]
        self.client.post(f"/api/bookings/{booking_pk}/cancel/")
        second_attempt = self.client.post(f"/api/bookings/{booking_pk}/cancel/")
        self.assertEqual(second_attempt.status_code, 400)

    def test_unauthenticated_user_cannot_book(self):
        anon_client = APIClient()
        resp = anon_client.post("/api/bookings/", {
            "room_ids": [self.room.id], "check_in": self.check_in,
            "check_out": self.check_out, "number_of_guests": 2,
        }, format="json")
        self.assertEqual(resp.status_code, 401)

    def test_pay_confirms_booking(self):
        resp = self.client.post("/api/bookings/", {
            "room_ids": [self.room.id], "check_in": self.check_in,
            "check_out": self.check_out, "number_of_guests": 2,
        }, format="json")
        booking_pk = resp.data["id"]
        pay_resp = self.client.post(f"/api/bookings/{booking_pk}/pay/")
        self.assertEqual(pay_resp.status_code, 200)
        self.assertEqual(pay_resp.data["status"], "CONFIRMED")
