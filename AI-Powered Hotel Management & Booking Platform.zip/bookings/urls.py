from django.urls import path
from . import views

app_name = "bookings"

urlpatterns = [
    path("start/<int:room_id>/", views.booking_start_view, name="start"),
    path("review/", views.booking_review_view, name="review"),
    path("pay/<uuid:booking_id>/", views.booking_pay_view, name="pay"),
    path("confirmation/<uuid:booking_id>/", views.booking_confirmation_view, name="confirmation"),
    path("cancel/<uuid:booking_id>/", views.booking_cancel_view, name="cancel"),
]
