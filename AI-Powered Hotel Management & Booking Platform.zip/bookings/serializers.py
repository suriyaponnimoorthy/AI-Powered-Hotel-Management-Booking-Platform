from rest_framework import serializers

from .models import Booking, BookingRoom, BookingService
from hotels.models import Room
from hotels.serializers import RoomSerializer, HotelServiceSerializer


class BookingServiceSerializer(serializers.ModelSerializer):
    service = HotelServiceSerializer(read_only=True)

    class Meta:
        model = BookingService
        fields = ["id", "service", "quantity", "price_at_booking", "line_total"]


class BookingRoomSerializer(serializers.ModelSerializer):
    room = RoomSerializer(read_only=True)

    class Meta:
        model = BookingRoom
        fields = ["id", "room", "price_at_booking"]


class BookingSerializer(serializers.ModelSerializer):
    booking_rooms = BookingRoomSerializer(many=True, read_only=True)
    services = BookingServiceSerializer(many=True, read_only=True)
    number_of_nights = serializers.ReadOnlyField()

    hold_expires_at = serializers.DateTimeField(read_only=True)
    hold_expired = serializers.BooleanField(read_only=True)

    class Meta:
        model = Booking
        fields = ["id", "booking_id", "check_in", "check_out", "number_of_guests", "number_of_rooms",
                  "status", "subtotal", "discount", "tax", "total_amount", "promo_code",
                  "special_requests", "number_of_nights", "booking_rooms", "services", "created_at", "hold_expires_at", "hold_expired"]
        read_only_fields = fields


class CreateBookingSerializer(serializers.Serializer):
    """
    Validates the request, re-fetches rooms/services from the DB, and
    recalculates the price server-side. Frontend numbers are never trusted.
    """
    room_ids = serializers.ListField(child=serializers.IntegerField(min_value=1), min_length=1, max_length=5)
    check_in = serializers.DateField()
    check_out = serializers.DateField()
    number_of_guests = serializers.IntegerField(min_value=1)
    service_ids = serializers.ListField(child=serializers.IntegerField(min_value=1), max_length=50, required=False, default=list)
    promo_code = serializers.CharField(max_length=30, required=False, allow_blank=True, default="")
    special_requests = serializers.CharField(max_length=5000, required=False, allow_blank=True, default="")

    def validate(self, attrs):
        from .services import validate_selection, selected_services_and_discount
        rooms = list(Room.objects.filter(id__in=attrs['room_ids']).select_related('room_type'))
        validate_selection(attrs, rooms)
        selected_services_and_discount(attrs)
        return attrs

    def create(self, validated_data):
        from .services import create_reservation
        return create_reservation(self.context['request'].user, validated_data)


# ---------------------------------------------------------------------------
# Digital check-in & special requests (Phase 14 / Section 25-26)
# ---------------------------------------------------------------------------
from hotels.models import DigitalCheckIn, SpecialRequest


class DigitalCheckInSerializer(serializers.ModelSerializer):
    class Meta:
        model = DigitalCheckIn
        fields = ["id", "booking", "arrival_time", "guest_full_name",
                  "special_requests", "is_completed", "completed_at"]
        read_only_fields = ["id", "is_completed", "completed_at"]

    def validate_booking(self, booking):
        request = self.context["request"]
        if booking.user != request.user:
            raise serializers.ValidationError("You can only check in for your own booking.")
        from django.utils import timezone
        if booking.status != Booking.Status.CONFIRMED or booking.check_out <= timezone.localdate():
            raise serializers.ValidationError("Digital check-in is only available for upcoming confirmed bookings.")
        return booking

    def create(self, validated_data):
        from django.db import transaction
        from django.utils import timezone

        with transaction.atomic():
            booking = Booking.objects.select_for_update().get(pk=validated_data.pop("booking").pk)
            self.validate_booking(booking)
            checkin, _ = DigitalCheckIn.objects.get_or_create(
                booking=booking,
                defaults={**validated_data, "is_completed": True, "completed_at": timezone.now()},
            )
        return checkin


class SpecialRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = SpecialRequest
        fields = ["id", "booking", "request_type", "details", "is_fulfilled", "created_at"]
        read_only_fields = ["id", "is_fulfilled", "created_at"]

    def validate_booking(self, booking):
        request = self.context["request"]
        if booking.user != request.user:
            raise serializers.ValidationError("You can only add requests to your own booking.")
        return booking
