import uuid
from django.conf import settings
from django.db import models

from hotels.models import Room, HotelService


class Booking(models.Model):
    class Status(models.TextChoices):
        PENDING = "PENDING", "Pending"
        CONFIRMED = "CONFIRMED", "Confirmed"
        CHECKED_IN = "CHECKED_IN", "Checked In"
        CHECKED_OUT = "CHECKED_OUT", "Checked Out"
        CANCELLED = "CANCELLED", "Cancelled"
        COMPLETED = "COMPLETED", "Completed"

    booking_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="bookings")
    check_in = models.DateField()
    check_out = models.DateField()
    number_of_guests = models.PositiveIntegerField(default=1)
    number_of_rooms = models.PositiveIntegerField(default=1)
    status = models.CharField(max_length=15, choices=Status.choices, default=Status.PENDING)

    subtotal = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    discount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    tax = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    promo_code = models.CharField(max_length=30, blank=True)
    special_requests = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Booking {str(self.booking_id)[:8]} - {self.user}"

    @property
    def hold_expires_at(self):
        from datetime import timedelta
        return self.created_at + timedelta(minutes=settings.BOOKING_HOLD_MINUTES)

    @property
    def hold_expired(self):
        from django.utils import timezone
        return self.status == self.Status.PENDING and timezone.now() >= self.hold_expires_at

    @property
    def number_of_nights(self):
        return (self.check_out - self.check_in).days

    @property
    def can_be_cancelled(self):
        return self.status in (self.Status.PENDING, self.Status.CONFIRMED)

    @property
    def can_be_reviewed(self):
        return self.status in (self.Status.CHECKED_OUT, self.Status.COMPLETED)


class BookingRoom(models.Model):
    """Through model linking a booking to the specific room(s) reserved."""
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name="booking_rooms")
    room = models.ForeignKey(Room, on_delete=models.PROTECT, related_name="booking_rooms")
    price_at_booking = models.DecimalField(max_digits=10, decimal_places=2)

    class Meta:
        unique_together = ("booking", "room")

    def __str__(self):
        return f"{self.room} for {self.booking}"


class BookingService(models.Model):
    """Additional services (breakfast, airport transfer, spa, etc.) added to a booking."""
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name="services")
    service = models.ForeignKey(HotelService, on_delete=models.PROTECT, related_name="booking_services")
    quantity = models.PositiveIntegerField(default=1)
    price_at_booking = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.service} x{self.quantity} ({self.booking})"

    @property
    def line_total(self):
        return self.price_at_booking * self.quantity
