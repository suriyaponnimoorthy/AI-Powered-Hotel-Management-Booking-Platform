from django.contrib import admin
from .models import Booking, BookingRoom, BookingService


class BookingRoomInline(admin.TabularInline):
    model = BookingRoom
    extra = 0


class BookingServiceInline(admin.TabularInline):
    model = BookingService
    extra = 0


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ("booking_id", "user", "check_in", "check_out", "status", "total_amount", "created_at")
    list_filter = ("status", "check_in", "check_out")
    search_fields = ("booking_id", "user__username", "user__email")
    readonly_fields = ("booking_id", "created_at", "updated_at")
    inlines = [BookingRoomInline, BookingServiceInline]

    # Reservation writes must go through the shared workflow services.
    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
