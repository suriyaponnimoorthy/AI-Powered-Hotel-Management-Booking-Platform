from datetime import date, timedelta
from decimal import Decimal

from django.test import TestCase
from rest_framework.test import APIClient

from accounts.models import User
from hotels.models import RoomType, Room, DigitalCheckIn, SpecialRequest
from .models import Booking


class DigitalCheckInTests(TestCase):
    def setUp(self):
        rt = RoomType.objects.create(name="Suite", base_price=Decimal("12000"), max_guests=4)
        self.room = Room.objects.create(room_number="601", room_type=rt, price_per_night=Decimal("12000"))
        self.user = User.objects.create_user(username="arriving_guest", password="pass1234!")
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)
        self.booking = Booking.objects.create(
            user=self.user, check_in=date.today() + timedelta(days=3),
            check_out=date.today() + timedelta(days=5), number_of_guests=2,
            status=Booking.Status.CONFIRMED, total_amount=Decimal("24000"),
        )

    def test_complete_digital_checkin(self):
        resp = self.client.post("/api/check-in/", {
            "booking": self.booking.id, "guest_full_name": "Rahul Sharma",
            "arrival_time": "3:00 PM", "id_type": "Passport", "id_number": "X1234567",
        }, format="json")
        self.assertEqual(resp.status_code, 201, resp.data)
        checkin = DigitalCheckIn.objects.get(booking=self.booking)
        self.assertTrue(checkin.is_completed)
        self.assertIsNotNone(checkin.completed_at)

    def test_cannot_checkin_for_someone_elses_booking(self):
        other = User.objects.create_user(username="stranger", password="pass1234!")
        other_client = APIClient()
        other_client.force_authenticate(user=other)
        resp = other_client.post("/api/check-in/", {
            "booking": self.booking.id, "guest_full_name": "Impersonator",
        }, format="json")
        self.assertEqual(resp.status_code, 400)

    def test_cannot_checkin_for_cancelled_booking(self):
        self.booking.status = Booking.Status.CANCELLED
        self.booking.save()
        resp = self.client.post("/api/check-in/", {
            "booking": self.booking.id, "guest_full_name": "Rahul Sharma",
        }, format="json")
        self.assertEqual(resp.status_code, 400)


class SpecialRequestTests(TestCase):
    def setUp(self):
        rt = RoomType.objects.create(name="Deluxe Room", base_price=Decimal("6500"), max_guests=2)
        self.room = Room.objects.create(room_number="602", room_type=rt, price_per_night=Decimal("6500"))
        self.user = User.objects.create_user(username="requester", password="pass1234!")
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)
        self.booking = Booking.objects.create(
            user=self.user, check_in=date.today() + timedelta(days=3),
            check_out=date.today() + timedelta(days=5), number_of_guests=2,
            status=Booking.Status.CONFIRMED, total_amount=Decimal("13000"),
        )

    def test_create_special_request(self):
        resp = self.client.post("/api/special-requests/", {
            "booking": self.booking.id, "request_type": "LATE_CHECKOUT",
            "details": "Flight leaves at 6 PM",
        }, format="json")
        self.assertEqual(resp.status_code, 201, resp.data)
        self.assertTrue(SpecialRequest.objects.filter(booking=self.booking).exists())

    def test_staff_can_see_all_requests(self):
        SpecialRequest.objects.create(booking=self.booking, request_type="BABY_CRIB")
        staff = User.objects.create_user(username="staffmember", password="pass1234!", role=User.Role.STAFF)
        staff_client = APIClient()
        staff_client.force_authenticate(user=staff)
        resp = staff_client.get("/api/special-requests/")
        results = resp.data.get("results", resp.data)
        self.assertEqual(len(results), 1)

    def test_customer_only_sees_own_requests(self):
        other = User.objects.create_user(username="another_guest", password="pass1234!")
        other_booking = Booking.objects.create(
            user=other, check_in=date.today() + timedelta(days=1),
            check_out=date.today() + timedelta(days=2), number_of_guests=1,
            status=Booking.Status.CONFIRMED, total_amount=Decimal("6500"),
        )
        SpecialRequest.objects.create(booking=other_booking, request_type="EXTRA_PILLOWS")
        resp = self.client.get("/api/special-requests/")
        results = resp.data.get("results", resp.data)
        self.assertEqual(len(results), 0)
