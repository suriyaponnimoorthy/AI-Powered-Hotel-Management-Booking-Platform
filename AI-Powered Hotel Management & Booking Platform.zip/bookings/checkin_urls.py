from rest_framework import viewsets, permissions
from rest_framework.routers import DefaultRouter
from .serializers import DigitalCheckInSerializer
from hotels.models import DigitalCheckIn


class DigitalCheckInViewSet(viewsets.ModelViewSet):
    serializer_class = DigitalCheckInSerializer
    permission_classes = [permissions.IsAuthenticated]
    http_method_names = ["get", "post"]

    def get_queryset(self):
        return DigitalCheckIn.objects.filter(booking__user=self.request.user)


router = DefaultRouter()
router.register("", DigitalCheckInViewSet, basename="checkin")
urlpatterns = router.urls
