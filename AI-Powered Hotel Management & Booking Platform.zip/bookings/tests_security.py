from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from io import StringIO
from threading import Barrier
from types import SimpleNamespace
from unittest.mock import patch

from django.core.management import call_command
from django.db import close_old_connections, connections
from django.test import TestCase, TransactionTestCase, override_settings, skipUnlessDBFeature
from django.utils import timezone
from rest_framework.exceptions import ValidationError
from rest_framework.test import APIClient

from accounts.models import User
from hotels.models import Room, RoomType, HotelService
from notifications.models import Notification
from payments.models import Payment
from bookings.models import Booking, BookingRoom
from bookings.serializers import CreateBookingSerializer
from bookings.services import available_rooms_queryset, room_is_available


@override_settings(ALLOW_MOCK_PAYMENTS=True, BOOKING_HOLD_MINUTES=15)
class BookingSafetyTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='guest', password='strong-test-password')
        self.client = APIClient()
        self.client.force_authenticate(self.user)
        rt = RoomType.objects.create(name='Double', base_price=1000, max_guests=2)
        self.room = Room.objects.create(room_number='100', room_type=rt, price_per_night=1000)
        self.start = timezone.localdate() + timedelta(days=2)
        self.end = self.start + timedelta(days=2)
        self.payload = dict(room_ids=[self.room.id], check_in=str(self.start), check_out=str(self.end), number_of_guests=2)

    def create(self, **overrides):
        return self.client.post('/api/bookings/', {**self.payload, **overrides}, format='json')

    def booking(self):
        response = self.create()
        self.assertEqual(response.status_code, 201, response.data)
        return Booking.objects.get(pk=response.data['id'])

    def expire(self, booking):
        Booking.objects.filter(pk=booking.pk).update(created_at=timezone.now() - timedelta(minutes=16))
        booking.refresh_from_db()

    def test_unsafe_mutations_disabled(self):
        booking = self.booking()
        for method in ('patch', 'put', 'delete'):
            response = getattr(self.client, method)(f'/api/bookings/{booking.id}/', {'check_in': '2030-01-01'}, format='json')
            self.assertEqual(response.status_code, 405)
        booking.refresh_from_db()
        self.assertEqual(booking.check_in, self.start)

    def test_invalid_stay_and_guest_capacity(self):
        for data in [dict(check_in=str(timezone.localdate() - timedelta(days=1))),
                     dict(check_out=str(self.start)), dict(number_of_guests=3), dict(number_of_guests=0)]:
            self.assertEqual(self.create(**data).status_code, 400)
        self.assertFalse(Booking.objects.exists())

    def test_capacity_combines_unique_rooms(self):
        second = Room.objects.create(room_number='101', room_type=self.room.room_type, price_per_night=1000)
        self.assertEqual(self.create(room_ids=[self.room.id, second.id], number_of_guests=4).status_code, 201)

    def test_duplicate_rooms_rejected(self):
        self.assertEqual(self.create(room_ids=[self.room.id, self.room.id]).status_code, 400)

    def test_invalid_and_duplicate_services_rejected(self):
        service = HotelService.objects.create(name='Transfer', price=500, is_active=False)
        for ids in [[service.id], [99999], [service.id, service.id]]:
            self.assertEqual(self.create(service_ids=ids).status_code, 400)

    def test_selection_rechecked_after_validation(self):
        serializer = CreateBookingSerializer(data=self.payload, context={'request': SimpleNamespace(user=self.user)})
        self.assertTrue(serializer.is_valid(), serializer.errors)
        self.booking()
        with self.assertRaises(ValidationError):
            serializer.save()
        self.assertEqual(Booking.objects.count(), 1)

    def test_price_refetched_after_validation(self):
        serializer = CreateBookingSerializer(data=self.payload, context={'request': SimpleNamespace(user=self.user)})
        self.assertTrue(serializer.is_valid())
        Room.objects.filter(pk=self.room.pk).update(price_per_night=2000)
        booking = serializer.save()
        self.assertEqual(booking.subtotal, 4000)
        self.assertEqual(booking.booking_rooms.get().price_at_booking, 2000)

    def test_creation_failure_rolls_back_booking_and_rooms(self):
        with patch('bookings.models.BookingRoom.objects.create', side_effect=RuntimeError('simulated failure')):
            with self.assertRaises(RuntimeError):
                self.create()
        self.assertEqual(Booking.objects.count(), 0)
        self.assertEqual(Notification.objects.count(), 0)

    def test_expired_hold_releases_inventory_without_cleanup(self):
        booking = self.booking(); self.expire(booking)
        self.assertTrue(room_is_available(self.room, self.start, self.end))
        self.assertTrue(available_rooms_queryset(self.start, self.end).filter(pk=self.room.pk).exists())
        self.assertEqual(self.create().status_code, 201)

    def test_confirmed_booking_does_not_expire(self):
        booking = self.booking(); self.expire(booking)
        booking.status = Booking.Status.CONFIRMED; booking.save()
        self.assertFalse(room_is_available(self.room, self.start, self.end))

    def test_cleanup_is_idempotent_and_keeps_confirmed(self):
        booking = self.booking(); self.expire(booking)
        confirmed = Booking.objects.create(user=self.user, check_in=self.start, check_out=self.end, status=Booking.Status.CONFIRMED)
        self.expire(confirmed)
        before = Notification.objects.count()
        for _ in range(2):
            call_command('expire_booking_holds', stdout=StringIO())
        booking.refresh_from_db(); confirmed.refresh_from_db()
        self.assertEqual(booking.status, Booking.Status.CANCELLED)
        self.assertEqual(confirmed.status, Booking.Status.CONFIRMED)
        self.assertEqual(Notification.objects.count(), before + 1)

    def test_repeated_payment_does_not_duplicate_records(self):
        booking = self.booking()
        for _ in range(2):
            self.assertEqual(self.client.post(f'/api/bookings/{booking.id}/pay/').status_code, 200)
        self.assertEqual(Payment.objects.count(), 1)
        self.assertEqual(Notification.objects.filter(category=Notification.Category.PAYMENT_SUCCESS).count(), 1)

    def test_cancelled_booking_cannot_be_paid(self):
        booking = self.booking()
        self.client.post(f'/api/bookings/{booking.id}/cancel/')
        self.assertEqual(self.client.post(f'/api/bookings/{booking.id}/pay/').status_code, 400)
        self.assertFalse(Payment.objects.exists())
        booking.refresh_from_db(); self.assertEqual(booking.status, Booking.Status.CANCELLED)

    def test_expired_booking_cannot_be_paid(self):
        booking = self.booking(); self.expire(booking)
        self.assertEqual(self.client.post(f'/api/bookings/{booking.id}/pay/').status_code, 400)
        self.assertFalse(Payment.objects.exists())

    @override_settings(ALLOW_MOCK_PAYMENTS=False)
    def test_payment_disabled_in_production_configuration(self):
        booking = self.booking()
        self.assertEqual(self.client.post(f'/api/bookings/{booking.id}/pay/').status_code, 400)
        self.assertFalse(Payment.objects.exists())

    def test_payment_notification_failure_rolls_back_charge(self):
        booking = self.booking()
        with patch('notifications.models.Notification.objects.create', side_effect=RuntimeError('simulated failure')):
            with self.assertRaises(RuntimeError):
                self.client.post(f'/api/bookings/{booking.id}/pay/')
        self.assertFalse(Payment.objects.exists())
        booking.refresh_from_db(); self.assertEqual(booking.status, Booking.Status.PENDING)

    def test_foreign_booking_actions_rejected(self):
        booking = self.booking()
        other = User.objects.create_user(username='stranger')
        self.client.force_authenticate(other)
        for action in ('cancel', 'pay'):
            self.assertEqual(self.client.post(f'/api/bookings/{booking.id}/{action}/').status_code, 404)

    def test_staff_transitions_validate_state(self):
        booking = self.booking()
        self.user.is_staff = True; self.user.role = User.Role.STAFF; self.user.save()
        self.assertEqual(self.client.post(f'/api/bookings/{booking.id}/check_in/').status_code, 400)
        self.client.post(f'/api/bookings/{booking.id}/pay/')
        self.assertEqual(self.client.post(f'/api/bookings/{booking.id}/check_out/').status_code, 400)
        self.assertEqual(self.client.post(f'/api/bookings/{booking.id}/check_in/').status_code, 400)  # too early
        Booking.objects.filter(pk=booking.pk).update(check_in=timezone.localdate())
        self.assertEqual(self.client.post(f'/api/bookings/{booking.id}/check_in/').status_code, 200)
        self.assertEqual(self.client.post(f'/api/bookings/{booking.id}/check_out/').status_code, 200)

    def test_web_invalid_numbers_do_not_crash(self):
        self.client.force_login(self.user)
        response = self.client.post('/booking/review/', {**self.payload, 'room_id': 'abc', 'guests': 'invalid'})
        self.assertEqual(response.status_code, 302)
        self.assertFalse(Booking.objects.exists())

    def test_web_payment_uses_same_retry_rules(self):
        booking = self.booking(); self.client.force_login(self.user)
        for _ in range(2):
            self.assertEqual(self.client.post(f'/booking/pay/{booking.booking_id}/').status_code, 302)
        self.assertEqual(Payment.objects.count(), 1)

    def test_web_expired_payment_does_not_confirm(self):
        booking = self.booking(); self.expire(booking); self.client.force_login(self.user)
        self.assertEqual(self.client.post(f'/booking/pay/{booking.booking_id}/').status_code, 302)
        self.assertFalse(Payment.objects.exists())
        response = self.client.get(f'/booking/confirmation/{booking.booking_id}/')
        self.assertContains(response, 'Your reservation hold expired')


@skipUnlessDBFeature('has_select_for_update')
class ConcurrentReservationTests(TransactionTestCase):
    """Run with USE_POSTGRES=True; SQLite cannot validate row locking."""
    def setUp(self):
        self.user = User.objects.create_user(username='concurrent')
        rt = RoomType.objects.create(name='Only room', base_price=1000, max_guests=2)
        self.room = Room.objects.create(room_number='1', room_type=rt, price_per_night=1000)
        start = timezone.localdate() + timedelta(days=2)
        self.data = dict(room_ids=[self.room.id], check_in=str(start), check_out=str(start + timedelta(days=1)), number_of_guests=1)

    def test_only_one_of_two_simultaneous_reservations_succeeds(self):
        barrier = Barrier(2)
        def reserve():
            close_old_connections()
            try:
                user = User.objects.get(pk=self.user.pk)
                serializer = CreateBookingSerializer(data=self.data, context={'request': SimpleNamespace(user=user)})
                serializer.is_valid(raise_exception=True)
                barrier.wait(timeout=10)
                try:
                    serializer.save()
                    return 'created'
                except ValidationError:
                    return 'unavailable'
            finally:
                connections["default"].close()
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(lambda _: reserve(), range(2)))
        self.assertCountEqual(results, ['created', 'unavailable'])
        self.assertEqual(Booking.objects.count(), 1)
