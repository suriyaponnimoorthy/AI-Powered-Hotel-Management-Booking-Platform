from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404

from hotels.models import Room, HotelService
from .models import Booking
from .serializers import CreateBookingSerializer
from payments.services import confirm_mock_payment
from .services import cancel_reservation
from rest_framework.exceptions import ValidationError


@login_required
def booking_start_view(request, room_id):
    """Step: select dates & guests for a specific room."""
    room = get_object_or_404(Room, pk=room_id)
    services = HotelService.objects.filter(is_active=True)
    return render(request, "bookings/start.html", {"room": room, "services": services})


@login_required
def booking_review_view(request):
    """
    Step: server recalculates price from posted room/service/date selections
    and shows the review + payment page. POST here creates a PENDING booking.
    """
    if request.method != "POST":
        return redirect("hotels:room_list")

    room_ids = request.POST.getlist("room_ids") or [request.POST.get("room_id")]
    service_ids = request.POST.getlist("service_ids")
    check_in = request.POST.get("check_in")
    check_out = request.POST.get("check_out")
    guests = request.POST.get("guests", 1)
    promo_code = request.POST.get("promo_code", "").strip()

    payload = {
        "room_ids": [r for r in room_ids if r],
        "check_in": check_in,
        "check_out": check_out,
        "number_of_guests": guests,
        "service_ids": [s for s in service_ids if s],
        "promo_code": promo_code,
        "special_requests": request.POST.get("special_requests", ""),
    }
    serializer = CreateBookingSerializer(data=payload, context={"request": request})
    if not serializer.is_valid():
        for field, errs in serializer.errors.items():
            messages.error(request, f"{field}: {errs[0] if isinstance(errs, list) else errs}")
        return redirect("hotels:room_list")

    try:
        booking = serializer.save()
    except ValidationError as exc:
        messages.error(request, ' '.join(map(str, exc.detail)))
        return redirect('hotels:room_list')
    return redirect("bookings:confirmation", booking_id=booking.booking_id)


@login_required
def booking_pay_view(request, booking_id):
    booking = get_object_or_404(Booking, booking_id=booking_id, user=request.user)
    if request.method == "POST":
        try:
            confirm_mock_payment(booking.id)
            messages.success(request, 'Demo payment confirmed. No real money was collected.')
        except ValidationError as exc:
            messages.error(request, ' '.join(map(str, exc.detail)))
    return redirect("bookings:confirmation", booking_id=booking.booking_id)


@login_required
def booking_confirmation_view(request, booking_id):
    booking = get_object_or_404(
        Booking.objects.prefetch_related("booking_rooms__room__room_type", "services__service"),
        booking_id=booking_id, user=request.user,
    )
    return render(request, "bookings/confirmation.html", {"booking": booking,
        "razorpay_enabled": settings.PAYMENT_PROVIDER == 'razorpay' and bool(settings.RAZORPAY_KEY_ID),
        "mock_enabled": settings.ALLOW_MOCK_PAYMENTS and settings.PAYMENT_PROVIDER != 'razorpay',
        "latest_payment": booking.payments.select_related('refund').first(),
        "payment_review": booking.payments.filter(requires_review=True, payment_status='SUCCESS').exists()})


@login_required
def booking_cancel_view(request, booking_id):
    booking = get_object_or_404(Booking, booking_id=booking_id, user=request.user)
    if request.method == 'POST':
        try:
            cancel_reservation(booking.id)
            messages.info(request, 'Your booking has been cancelled. Contact the hotel about any refund due.')
        except ValidationError as exc:
            messages.error(request, ' '.join(map(str, exc.detail)))
    return redirect("dashboard:bookings")
