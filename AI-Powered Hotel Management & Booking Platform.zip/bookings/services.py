"""
Core business logic for availability checking and price calculation.

Availability is NEVER decided by a simple `is_available` boolean alone.
A room is unavailable for a date range if:
  - its master `is_available` switch is off, or
  - its status is MAINTENANCE / INACTIVE, or
  - it has an overlapping BookingRoom whose parent Booking is in an
    "active" state (unexpired PENDING, CONFIRMED, CHECKED_IN).
"""
from decimal import Decimal
from django.db.models import Q

ACTIVE_BOOKING_STATUSES = ["PENDING", "CONFIRMED", "CHECKED_IN"]


def _overlap_query(check_in, check_out):
    """Two ranges [a1,a2) and [b1,b2) overlap iff a1 < b2 AND b1 < a2."""
    return Q(booking__check_in__lt=check_out) & Q(booking__check_out__gt=check_in)


def room_is_available(room, check_in, check_out):
    if not room.is_available:
        return False
    if room.status in ("MAINTENANCE", "INACTIVE"):
        return False

    from .models import BookingRoom
    overlapping = BookingRoom.objects.filter(
        room=room,
    ).filter(active_reservation_query("booking__")).filter(_overlap_query(check_in, check_out))
    return not overlapping.exists()


def available_rooms_queryset(check_in, check_out, base_queryset=None):
    """Return a queryset of rooms that are free for the given date range."""
    from hotels.models import Room
    from .models import BookingRoom

    qs = base_queryset if base_queryset is not None else Room.objects.all()
    qs = qs.exclude(status__in=["MAINTENANCE", "INACTIVE"]).filter(is_available=True)

    unavailable_room_ids = BookingRoom.objects.filter(active_reservation_query("booking__")).filter(_overlap_query(check_in, check_out)).values_list("room_id", flat=True)

    return qs.exclude(id__in=unavailable_room_ids)


def calculate_price(rooms, check_in, check_out, services=None, discount_percentage=Decimal("0"),
                     tax_percentage=Decimal("12")):
    """
    rooms: iterable of Room instances (one entry per room being booked)
    services: iterable of (HotelService, quantity) tuples
    Returns a dict with subtotal, services_total, discount, tax, grand_total.
    This is the single source of truth for pricing — always recomputed
    server-side, never trusted from the frontend.
    """
    nights = (check_out - check_in).days
    if nights <= 0:
        raise ValueError("check_out must be after check_in")

    room_total = sum((r.price_per_night for r in rooms), Decimal("0")) * nights

    services_total = Decimal("0")
    service_lines = []
    for service, qty in (services or []):
        line = service.price * qty
        services_total += line
        service_lines.append({"service": service, "quantity": qty, "line_total": line})

    subtotal = room_total + services_total
    discount = (subtotal * discount_percentage / Decimal("100")).quantize(Decimal("0.01"))
    taxable = subtotal - discount
    tax = (taxable * tax_percentage / Decimal("100")).quantize(Decimal("0.01"))
    grand_total = taxable + tax

    return {
        "nights": nights,
        "room_total": room_total,
        "services_total": services_total,
        "service_lines": service_lines,
        "subtotal": subtotal,
        "discount": discount,
        "tax": tax,
        "grand_total": grand_total,
    }


# Shared workflow rules used by both HTML and REST endpoints.
from datetime import timedelta
from django.conf import settings
from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError


def hold_cutoff():
    return timezone.now() - timedelta(minutes=settings.BOOKING_HOLD_MINUTES)


def active_reservation_query(prefix=''):
    return (Q(**{prefix + 'status__in': ['CONFIRMED', 'CHECKED_IN']}) |
            Q(**{prefix + 'status': 'PENDING', prefix + 'created_at__gt': hold_cutoff()}))


def validate_selection(data, rooms):
    if data['check_in'] < timezone.localdate():
        raise ValidationError('Check-in cannot be in the past.')
    nights = (data['check_out'] - data['check_in']).days
    if not 1 <= nights <= 30:
        raise ValidationError('Bookings must be between 1 and 30 nights.')
    if data['check_in'] > timezone.localdate() + timedelta(days=365):
        raise ValidationError('Check-in must be within the next 365 days.')
    if len(data['room_ids']) > 5:
        raise ValidationError('A booking can hold at most five rooms.')
    if len(data['room_ids']) != len(set(data['room_ids'])):
        raise ValidationError('Select each room only once.')
    if not rooms or len(rooms) != len(data['room_ids']):
        raise ValidationError('One or more rooms could not be found.')
    if data['number_of_guests'] > sum(r.room_type.max_guests for r in rooms):
        raise ValidationError('Guest count exceeds the capacity of the selected rooms.')
    ids = [r.id for r in rooms]
    available = set(available_rooms_queryset(data['check_in'], data['check_out']).filter(
        id__in=ids).values_list('id', flat=True))
    if available != set(ids):
        raise ValidationError('One or more rooms are no longer available for these dates.')


def selected_services_and_discount(data):
    from hotels.models import HotelService
    from offers.models import Offer
    ids = data.get('service_ids', [])
    if len(ids) != len(set(ids)):
        raise ValidationError('Select each service only once.')
    services = list(HotelService.objects.filter(id__in=ids, is_active=True))
    if len(services) != len(ids):
        raise ValidationError('One or more services are unavailable.')
    discount = Decimal('0')
    if data.get('promo_code'):
        offer = Offer.objects.filter(promo_code__iexact=data['promo_code']).first()
        if not offer or not offer.is_valid_today():
            raise ValidationError('Invalid or expired promo code.')
        discount = offer.discount_percentage
        if not Decimal('0') <= discount <= Decimal('100'):
            raise ValidationError('This offer is not configured correctly. Please contact the hotel.')
    return services, discount


@transaction.atomic
def create_reservation(user, data):
    from hotels.models import Room
    from .models import Booking, BookingRoom, BookingService
    from notifications.models import Notification
    from accounts.models import User
    User.objects.select_for_update().get(pk=user.pk)
    active_holds = Booking.objects.filter(
        user=user, status=Booking.Status.PENDING, created_at__gt=hold_cutoff(),
    )
    held_rooms = sum(active_holds.values_list("number_of_rooms", flat=True))
    if held_rooms + len(data["room_ids"]) > 5:
        raise ValidationError('You can hold at most five unpaid rooms across your bookings.')
    # Evaluate and lock Room rows in a stable order BEFORE checking overlaps.
    # Related types are fetched separately to avoid locking joined tables.
    rooms = list(Room.objects.select_for_update().filter(id__in=data['room_ids']).order_by('id'))
    validate_selection(data, rooms)
    services, discount = selected_services_and_discount(data)
    pricing = calculate_price(rooms, data['check_in'], data['check_out'],
                              services=[(s, 1) for s in services], discount_percentage=discount)
    booking = Booking.objects.create(
        user=user, check_in=data['check_in'], check_out=data['check_out'],
        number_of_guests=data['number_of_guests'], number_of_rooms=len(rooms),
        subtotal=pricing['subtotal'], discount=pricing['discount'], tax=pricing['tax'],
        total_amount=pricing['grand_total'], promo_code=data.get('promo_code', ''),
        special_requests=data.get('special_requests', ''))
    for room in rooms:
        BookingRoom.objects.create(booking=booking, room=room, price_at_booking=room.price_per_night)
    for service in services:
        BookingService.objects.create(booking=booking, service=service, price_at_booking=service.price)
    Notification.objects.create(user=user, category=Notification.Category.GENERAL,
        title='Booking received', message=f'Booking {booking.booking_id} is held until {booking.hold_expires_at.isoformat()}. Complete payment before this time.')
    return booking


@transaction.atomic
def cancel_reservation(booking_id):
    from .models import Booking
    from notifications.models import Notification
    booking = Booking.objects.select_for_update().get(pk=booking_id)
    if not booking.can_be_cancelled:
        raise ValidationError('This booking can no longer be cancelled.')
    booking.status = Booking.Status.CANCELLED
    booking.save(update_fields=['status', 'updated_at'])
    Notification.objects.create(user=booking.user, category=Notification.Category.BOOKING_CANCELLED,
        title='Booking cancelled', message=f'Booking {booking.booking_id} has been cancelled. Contact the hotel about any refund due.')
    return booking


@transaction.atomic
def transition_reservation(booking_id, target):
    from .models import Booking
    booking = Booking.objects.select_for_update().get(pk=booking_id)
    source = {Booking.Status.CHECKED_IN: Booking.Status.CONFIRMED,
              Booking.Status.CHECKED_OUT: Booking.Status.CHECKED_IN}.get(target)
    if source is None or booking.status != source:
        raise ValidationError('Invalid booking status transition.')
    today = timezone.localdate()
    if target == Booking.Status.CHECKED_IN and not booking.check_in <= today < booking.check_out:
        raise ValidationError('Check-in is only available during the booked stay.')
    booking.status = target
    booking.save(update_fields=['status', 'updated_at'])
    return booking
