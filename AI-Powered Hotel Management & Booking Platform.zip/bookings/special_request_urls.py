from rest_framework import viewsets, permissions
from rest_framework.routers import DefaultRouter
from .serializers import SpecialRequestSerializer
from hotels.models import SpecialRequest


class SpecialRequestViewSet(viewsets.ModelViewSet):
    serializer_class = SpecialRequestSerializer
    permission_classes = [permissions.IsAuthenticated]
    http_method_names = ["get", "post"]

    def get_queryset(self):
        user = self.request.user
        qs = SpecialRequest.objects.select_related("booking")
        if user.is_staff_member:
            return qs.all()
        return qs.filter(booking__user=user)


router = DefaultRouter()
router.register("", SpecialRequestViewSet, basename="special-request")
urlpatterns = router.urls
