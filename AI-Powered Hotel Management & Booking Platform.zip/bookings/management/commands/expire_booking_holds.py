from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from bookings.models import Booking
from bookings.services import hold_cutoff
from notifications.models import Notification


class Command(BaseCommand):
    help = 'Cancel expired pending reservation holds. Run periodically with your job scheduler.'

    def add_arguments(self, parser):
        parser.add_argument('--limit', type=int, default=100)

    def handle(self, *args, **options):
        limit = options['limit']
        if not 1 <= limit <= 1000:
            raise CommandError('--limit must be between 1 and 1000.')
        count = 0
        candidates = Booking.objects.filter(status=Booking.Status.PENDING,
                                             created_at__lte=hold_cutoff()).order_by('created_at', 'pk').values_list('id', flat=True)[:limit]
        for pk in list(candidates):
            with transaction.atomic():
                booking = Booking.objects.select_for_update().filter(pk=pk).first()
                # Payment or another worker may have changed the row while waiting.
                if booking is None or not booking.hold_expired:
                    continue
                booking.status = Booking.Status.CANCELLED
                booking.save(update_fields=['status', 'updated_at'])
                Notification.objects.create(user=booking.user, category=Notification.Category.BOOKING_CANCELLED,
                    title='Reservation hold expired', message=f'Unpaid reservation {booking.booking_id} expired. Please make a new booking.')
                count += 1
        self.stdout.write(self.style.SUCCESS(f'Expired {count} reservation hold(s).'))
