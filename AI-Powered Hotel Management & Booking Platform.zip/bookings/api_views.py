from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import Booking
from .serializers import BookingSerializer, CreateBookingSerializer
from payments.services import confirm_mock_payment
from .services import cancel_reservation, transition_reservation


class BookingViewSet(viewsets.ModelViewSet):
    serializer_class = BookingSerializer
    permission_classes = [permissions.IsAuthenticated]
    http_method_names = ["get", "post", "head", "options"]

    def get_queryset(self):
        user = self.request.user
        qs = Booking.objects.select_related("user").prefetch_related("booking_rooms__room", "services__service")
        if user.is_staff_member:
            return qs.all()
        return qs.filter(user=user)

    def create(self, request, *args, **kwargs):
        serializer = CreateBookingSerializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        booking = serializer.save()
        return Response(BookingSerializer(booking).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def cancel(self, request, pk=None):
        booking = self.get_object()
        booking = cancel_reservation(booking.id)
        return Response(BookingSerializer(booking).data)

    @action(detail=True, methods=["post"])
    def pay(self, request, pk=None):
        """Mock payment confirmation -> confirms booking."""
        booking = self.get_object()
        booking = confirm_mock_payment(booking.id)
        return Response(BookingSerializer(booking).data)

    # Staff-only transitions
    @action(detail=True, methods=["post"], permission_classes=[permissions.IsAdminUser])
    def check_in(self, request, pk=None):
        booking = self.get_object()
        booking = transition_reservation(booking.id, Booking.Status.CHECKED_IN)
        return Response(BookingSerializer(booking).data)

    @action(detail=True, methods=["post"], permission_classes=[permissions.IsAdminUser])
    def check_out(self, request, pk=None):
        booking = self.get_object()
        booking = transition_reservation(booking.id, Booking.Status.CHECKED_OUT)
        return Response(BookingSerializer(booking).data)
