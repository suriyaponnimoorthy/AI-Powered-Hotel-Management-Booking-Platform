# Illustrative photography

Photos are design placeholders, not verified photographs of ABC Hotels. Replace with hotel-owned photography before a real launch. No Campbell Gray branding, text or photography is included.

- hero.jpg: https://images.unsplash.com/photo-1571896349842-33c89424de2d
- suite.jpg: https://images.unsplash.com/photo-1611892440504-42a792e24d32
- retreat.jpg: https://images.unsplash.com/photo-1566073771259-6a8506099945
- interior.jpg: https://images.unsplash.com/photo-1578683010236-d716f9a3f461
- residence.jpg: https://images.unsplash.com/photo-1590490360182-c33d57733427
