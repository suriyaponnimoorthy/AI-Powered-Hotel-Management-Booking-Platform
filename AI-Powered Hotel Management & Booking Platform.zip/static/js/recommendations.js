document.getElementById('recommendForm').addEventListener('submit', async e => {
  e.preventDefault();
  const form = e.target, result = document.getElementById('recommendResults');
  const button = form.querySelector('button'); button.disabled = true;
  result.textContent = 'Finding room matches...';
  try {
    const fields = new FormData(form), payload = {guests: Number(fields.get('guests')),
      preferences: fields.get('preferences').split(',').map(s => s.trim()).filter(Boolean)};
    for (const key of ['check_in', 'check_out', 'budget']) {
      if (fields.get(key)) payload[key] = key === 'budget' ? Number(fields.get(key)) : fields.get(key);
    }
    const response = await fetch('/api/ai/recommend/', {method: 'POST',
      headers: {'Content-Type': 'application/json', 'X-CSRFToken': window.CSRF_TOKEN}, body: JSON.stringify(payload)});
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || Object.values(data).flat().join(' '));
    result.replaceChildren();
    const intro = document.createElement('p');
    intro.textContent = data.summary + (data.availability_checked ? ' Dates checked; availability is rechecked at booking.' : ' Add dates to check availability.');
    result.appendChild(intro);
    data.recommendations.forEach(room => {
      const card = document.createElement('article'); card.className = 'panel';
      card.style.marginBottom = '16px';
      const title = document.createElement('h2'); title.textContent = `${room.room_type.name} · Room ${room.room_number}`;
      const reasons = document.createElement('p'); reasons.textContent = room.reasons.join('. ');
      const matches = document.createElement('p');
      matches.textContent = payload.preferences.length ? `Preference match: ${room.preference_score}% (amenities only).` : 'Sorted by price; no amenity preferences supplied.';
      const missing = document.createElement('p'); missing.textContent = room.missing_preferences.length ? 'Unmatched: ' + room.missing_preferences.join(', ') : '';
      const link = document.createElement('a'); link.textContent = 'View room'; link.href = `/rooms/${Number(room.id)}/`;
      card.append(title, reasons, matches, missing, link); result.appendChild(card);
    });
  } catch (error) { result.textContent = error.message; }
  finally { button.disabled = false; }
});
