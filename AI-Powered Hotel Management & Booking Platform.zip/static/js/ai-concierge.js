document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('aiConciergeToggle');
  const panel = document.getElementById('aiConciergePanel');
  if (!toggle || !panel) return;
  const form = document.getElementById('aiChatForm');
  const input = document.getElementById('aiInput');
  const messages = document.getElementById('aiMessages');
  const results = document.getElementById('aiRoomResults');
  let history = [], conversationId = null, busy = false;
  function setOpen(open) {
    panel.classList.toggle('hidden', !open);
    toggle.setAttribute('aria-expanded', String(open));
    if (open) input.focus(); else toggle.focus();
  }
  toggle.addEventListener('click', () => setOpen(panel.classList.contains('hidden')));
  document.getElementById('aiCloseBtn').addEventListener('click', () => setOpen(false));
  panel.addEventListener('keydown', e => { if (e.key === 'Escape') setOpen(false); });
  document.querySelectorAll('[data-quick]').forEach(btn => btn.addEventListener('click', () => {
    if (!busy) { input.value = btn.dataset.quick; form.requestSubmit(); }
  }));
  function append(text, who) {
    const element = document.createElement('div');
    element.className = `ai-msg ai-msg-${who}`;
    element.style.whiteSpace = 'pre-line';
    element.textContent = text;
    messages.appendChild(element);
    messages.scrollTop = messages.scrollHeight;
    return element;
  }
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const message = input.value.trim();
    if (!message || busy) return;
    busy = true;
    form.querySelector('button').disabled = true;
    append(message, 'user'); input.value = '';
    const loading = append('Thinking...', 'bot');
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 35000);
    try {
      const resp = await fetch('/api/ai/chat/', {
        method: 'POST', signal: controller.signal,
        headers: {'Content-Type': 'application/json', 'X-CSRFToken': window.CSRF_TOKEN},
        body: JSON.stringify({message, history: history.slice(-12), conversation_id: conversationId})
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data.detail || 'Please check your message and try again.');
      loading.textContent = data.reply;
      results.replaceChildren();
      (data.matched_rooms || []).slice(0, 4).forEach(room => {
        const card = document.createElement('div'); card.className = 'ai-room-mini';
        card.textContent = `${room.room_type.name}, Room ${room.room_number} — ₹${room.price_per_night}/night · sleeps ${room.room_type.max_guests} `;
        const link = document.createElement('a');
        link.href = `/rooms/${Number(room.id)}/`; link.textContent = 'View room';
        card.appendChild(link); results.appendChild(card);
      });
      conversationId = data.conversation_id;
      history.push({role: 'user', content: message}, {role: 'assistant', content: data.reply.slice(0, 4000)});
    } catch (err) {
      loading.textContent = err.name === 'AbortError' ? 'The concierge timed out. Please try again.' : err.message;
      input.value = message;
    } finally {
      clearTimeout(timeout); busy = false; form.querySelector('button').disabled = false;
    }
  });
});
