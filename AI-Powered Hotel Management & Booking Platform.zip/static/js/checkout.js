document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('secureCheckout');
  if (!form) return;
  const button = form.querySelector('button'), status = document.getElementById('paymentStatus');
  const token = form.querySelector('[name=csrfmiddlewaretoken]').value;
  async function post(url, payload) {
    const response = await fetch(url, {method:'POST', credentials:'same-origin',
      headers:{'Content-Type':'application/json', 'X-CSRFToken': token}, body:JSON.stringify(payload)});
    const data = await response.json();
    if (!response.ok) throw new Error(typeof data.detail === 'string' ? data.detail : 'Unable to complete payment. Please check your booking status.');
    return data;
  }
  form.addEventListener('submit', async event => {
    event.preventDefault(); button.disabled = true; status.textContent = 'Preparing secure checkout…';
    try {
      if (!window.Razorpay) throw new Error('Secure checkout could not load. Please try again.');
      const checkout = await post(form.dataset.checkoutUrl, {});
      const rzp = new Razorpay({...checkout, description:'Hotel reservation',
        handler: async result => {
          status.textContent = 'Verifying payment…';
          try {
            const verified = await post(`/api/payments/verify/${checkout.payment_id}/`, result);
            status.textContent = verified.requires_review ? 'Payment received. Please contact the hotel about your reservation.' : 'Payment verified. Updating your booking…';
            window.location.reload();
          } catch (error) { status.textContent = error.message + ' If money was debited, do not pay again; the hotel will reconcile it.'; button.disabled = false; }
        },
        modal:{ondismiss:() => {button.disabled = false; status.textContent = 'Checkout closed. Payment confirmation may still arrive; check your booking before retrying.';}}
      });
      rzp.on('payment.failed', () => {status.textContent = 'Payment was not completed. Check your booking before retrying.'; button.disabled = false;});
      rzp.open(); status.textContent = 'Complete payment in the secure checkout.';
    } catch (error) { status.textContent = error.message; button.disabled = false; }
  });
});
