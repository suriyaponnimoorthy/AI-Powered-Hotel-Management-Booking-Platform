document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-open-concierge]').forEach(button => button.addEventListener('click', () => {
    const toggle = document.getElementById('aiConciergeToggle');
    if (toggle.getAttribute('aria-expanded') !== 'true') toggle.click();
    document.getElementById('aiInput').focus();
  }));
  // Use local calendar dates so the date picker agrees with the guest's timezone.
  const today = new Date();
  const dateString = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  document.querySelectorAll('input[type="date"]').forEach(input => { input.min = dateString(today); });
  document.querySelectorAll('form').forEach(form => {
    const start = form.querySelector('[name="check_in"]');
    const end = form.querySelector('[name="check_out"]');
    if (!start || !end) return;
    const update = () => {
      end.setCustomValidity('');
      if (start.value) {
        const next = new Date(`${start.value}T12:00:00`); next.setDate(next.getDate()+1);
        end.min = dateString(next);
        if (end.value && end.value <= start.value) end.setCustomValidity('Choose a departure after your arrival.');
      } else end.min = dateString(today);
    };
    start.addEventListener('change', update); end.addEventListener('change', update); update();
  });
  // Associate existing server-rendered form labels with their controls.
  document.querySelectorAll('.form-group').forEach((group, index) => {
    const label = group.querySelector('label'), input = group.querySelector('input,select,textarea');
    if (label && input && input.type !== 'checkbox' && !label.htmlFor) { if (!input.id) input.id = `field-${index}`; label.htmlFor = input.id; }
  });
});
