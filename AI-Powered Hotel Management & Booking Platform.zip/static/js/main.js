// ---------------------------------------------------------------------------
// Mobile nav toggle
// ---------------------------------------------------------------------------
document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('hamburgerBtn');
  const nav = document.getElementById('mainNav');
  if (!button || !nav) return;
  function setMenu(open) {
    nav.classList.toggle('open', open);
    nav.inert = !open;
    button.setAttribute('aria-expanded', String(open));
    button.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  }
  button.addEventListener('click', () => setMenu(button.getAttribute('aria-expanded') !== 'true'));
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && button.getAttribute('aria-expanded') === 'true') {
      setMenu(false); button.focus();
    }
  });
  document.addEventListener('click', e => { if (!nav.contains(e.target) && !button.contains(e.target)) setMenu(false); });
  nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => setMenu(false)));
});

// ---------------------------------------------------------------------------
// CSRF-aware fetch helper for AJAX calls to Django views/DRF endpoints
// ---------------------------------------------------------------------------
async function apiFetch(url, options = {}) {
  const headers = options.headers || {};
  if (options.method && options.method !== "GET") {
    headers["X-CSRFToken"] = window.CSRF_TOKEN;
    headers["Content-Type"] = headers["Content-Type"] || "application/json";
  }
  const resp = await fetch(url, { ...options, headers, credentials: "same-origin" });
  if (!resp.ok) {
    const errText = await resp.text();
    throw new Error(errText || `Request failed with ${resp.status}`);
  }
  return resp.json();
}

// ---------------------------------------------------------------------------
// Wishlist (favorite rooms) — stored in-memory + synced to a hidden localStorage
// fallback is intentionally avoided per artifact rules; here we use a simple
// server-optional client cache since Room<->User favorites isn't modeled yet.
// ---------------------------------------------------------------------------
const Wishlist = {
  key: "abc_hotels_wishlist",
  get() {
    try { return JSON.parse(localStorage.getItem(this.key) || "[]"); }
    catch { return []; }
  },
  toggle(roomId) {
    let list = this.get();
    if (list.includes(roomId)) list = list.filter((id) => id !== roomId);
    else list.push(roomId);
    localStorage.setItem(this.key, JSON.stringify(list));
    return list.includes(roomId);
  },
  has(roomId) { return this.get().includes(roomId); },
};

document.addEventListener("click", (e) => {
  const btn = e.target.closest("[data-wishlist-toggle]");
  if (!btn) return;
  const roomId = parseInt(btn.dataset.wishlistToggle, 10);
  const active = Wishlist.toggle(roomId);
  btn.setAttribute("aria-pressed", String(active));
  if (btn.classList.contains("fav-btn")) {
    btn.innerHTML = active ? "&#9829;" : "&#9825;";
    btn.style.color = active ? "var(--teal)" : "var(--deep-teal)";
  } else {
    btn.textContent = active ? "Saved" : "Save to wishlist";
  }
});

document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-wishlist-toggle]").forEach((btn) => {
    const roomId = parseInt(btn.dataset.wishlistToggle, 10);
    btn.setAttribute("aria-pressed", String(Wishlist.has(roomId)));
    if (Wishlist.has(roomId)) {
      if (btn.classList.contains("fav-btn")) {
        btn.innerHTML = "&#9829;";
        btn.style.color = "var(--teal)";
      } else {
        btn.textContent = "Saved";
      }
    }
  });
});

// ---------------------------------------------------------------------------
// Live price calculation on the booking start page.
// The backend ALWAYS recalculates on submit — this is for UX feedback only.
// ---------------------------------------------------------------------------
function initBookingCalculator() {
  const form = document.getElementById("bookingStartForm");
  if (!form) return;

  const pricePerNight = parseFloat(form.dataset.pricePerNight || "0");
  const checkIn = form.querySelector("[name=check_in]");
  const checkOut = form.querySelector("[name=check_out]");
  const serviceInputs = form.querySelectorAll("[name=service_ids]");
  const summaryEl = document.getElementById("priceSummary");

  function servicesTotal() {
    let total = 0;
    serviceInputs.forEach((el) => {
      if (el.checked) total += parseFloat(el.dataset.price || "0");
    });
    return total;
  }

  function recalc() {
    if (!checkIn.value || !checkOut.value) return;
    const nights = Math.max(0, (new Date(checkOut.value) - new Date(checkIn.value)) / 86400000);
    const roomTotal = nights * pricePerNight;
    const services = servicesTotal();
    const subtotal = roomTotal + services;
    const tax = subtotal * 0.12;
    const grandTotal = subtotal + tax;

    summaryEl.innerHTML = `
      <div>Nights: <strong>${nights}</strong></div>
      <div>Room total: <strong>₹${roomTotal.toFixed(2)}</strong></div>
      <div>Services: <strong>₹${services.toFixed(2)}</strong></div>
      <div>Tax (12%): <strong>₹${tax.toFixed(2)}</strong></div>
      <div class="room-price">Estimated total: ₹${grandTotal.toFixed(2)} <span>(confirmed on next step)</span></div>
    `;
  }

  [checkIn, checkOut, ...serviceInputs].forEach((el) => el && el.addEventListener("change", recalc));
  recalc();
}
document.addEventListener("DOMContentLoaded", initBookingCalculator);

// ---------------------------------------------------------------------------
// Notification "mark all read" (dashboard)
// ---------------------------------------------------------------------------
document.addEventListener("click", async (e) => {
  const btn = e.target.closest("[data-mark-read]");
  if (!btn) return;
  const id = btn.dataset.markRead;
  try {
    await apiFetch(`/api/notifications/${id}/mark_read/`, { method: "PATCH", body: "{}" });
    btn.closest(".notification-item")?.classList.add("read");
    btn.remove();
  } catch (err) {
    console.error(err);
  }
});
