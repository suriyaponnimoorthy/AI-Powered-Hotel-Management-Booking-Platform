document.addEventListener('DOMContentLoaded', () => {
 const dialog = document.getElementById('imageDialog');
 const image = document.getElementById('dialogImage');
 document.querySelectorAll('[data-gallery-image]').forEach(button => button.addEventListener('click', () => {
   image.src = button.dataset.galleryImage; image.alt = button.dataset.galleryAlt || 'Hotel photograph';
   dialog.showModal();
 }));
 document.getElementById('closeImageDialog').addEventListener('click', () => dialog.close());
 dialog.addEventListener('click', event => { if (event.target === dialog) {
   const bounds = dialog.getBoundingClientRect();
   if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) dialog.close();
 }});
});
