from decimal import Decimal
from django.test import TestCase

from .models import RoomType, Room, HotelImage


class HotelGalleryAndCompareTests(TestCase):
    def setUp(self):
        self.rt1 = RoomType.objects.create(name="Deluxe Room", base_price=Decimal("6500"), max_guests=2)
        self.rt2 = RoomType.objects.create(name="Suite", base_price=Decimal("12000"), max_guests=4)
        self.room1 = Room.objects.create(room_number="801", room_type=self.rt1, price_per_night=Decimal("6500"))
        self.room2 = Room.objects.create(room_number="802", room_type=self.rt2, price_per_night=Decimal("12000"))

    def test_gallery_page_loads_with_no_images(self):
        resp = self.client.get("/hotel-gallery/")
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, "Gallery")

    def test_compare_page_with_no_selection(self):
        resp = self.client.get("/compare/")
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, "Select rooms above to compare")

    def test_compare_page_shows_selected_rooms(self):
        resp = self.client.get(f"/compare/?ids={self.room1.id},{self.room2.id}")
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, "Deluxe Room")
        self.assertContains(resp, "Suite")

    def test_compare_page_caps_at_three_rooms(self):
        room3 = Room.objects.create(room_number="803", room_type=self.rt1, price_per_night=Decimal("7000"))
        room4 = Room.objects.create(room_number="804", room_type=self.rt2, price_per_night=Decimal("13000"))
        ids = f"{self.room1.id},{self.room2.id},{room3.id},{room4.id}"
        resp = self.client.get(f"/compare/?ids={ids}")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(len(resp.context["rooms"]), 3)
