from .models import HotelPolicy


def hotel_policies(request):
    """Expose hotel policies globally to templates (e.g. footer, AI widget)."""
    return {"hotel_policies": HotelPolicy.objects.all()}
