from rest_framework.routers import DefaultRouter
from . import api_views

router = DefaultRouter()
router.register("types", api_views.RoomTypeViewSet, basename="room-type")
router.register("amenities", api_views.AmenityViewSet, basename="amenity")
router.register("attractions", api_views.NearbyAttractionViewSet, basename="attraction")
router.register("policies", api_views.HotelPolicyViewSet, basename="policy")
router.register("services", api_views.HotelServiceViewSet, basename="hotel-service")
router.register("contact", api_views.ContactMessageViewSet, basename="contact")
router.register("", api_views.RoomViewSet, basename="room")

urlpatterns = router.urls
