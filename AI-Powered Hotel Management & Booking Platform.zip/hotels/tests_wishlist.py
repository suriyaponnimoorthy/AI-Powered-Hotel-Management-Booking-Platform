from decimal import Decimal
from django.test import TestCase
from rest_framework.test import APIClient

from accounts.models import User
from .models import RoomType, Room, Wishlist


class WishlistTests(TestCase):
    def setUp(self):
        rt = RoomType.objects.create(name="Deluxe Room", base_price=Decimal("6500"), max_guests=2)
        self.room = Room.objects.create(room_number="501", room_type=rt, price_per_night=Decimal("6500"))
        self.user = User.objects.create_user(username="fan", password="pass1234!")
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)

    def test_add_room_to_wishlist(self):
        resp = self.client.post("/api/wishlist/", {"room_id": self.room.id}, format="json")
        self.assertEqual(resp.status_code, 201, resp.data)
        self.assertTrue(Wishlist.objects.filter(user=self.user, room=self.room).exists())

    def test_wishlist_scoped_to_user(self):
        other = User.objects.create_user(username="other", password="pass1234!")
        Wishlist.objects.create(user=other, room=self.room)
        resp = self.client.get("/api/wishlist/")
        results = resp.data.get("results", resp.data)
        self.assertEqual(len(results), 0)

    def test_cannot_add_same_room_twice(self):
        Wishlist.objects.create(user=self.user, room=self.room)
        resp = self.client.post("/api/wishlist/", {"room_id": self.room.id}, format="json")
        self.assertEqual(resp.status_code, 400)

    def test_remove_from_wishlist(self):
        item = Wishlist.objects.create(user=self.user, room=self.room)
        resp = self.client.delete(f"/api/wishlist/{item.id}/")
        self.assertEqual(resp.status_code, 204)
        self.assertFalse(Wishlist.objects.filter(pk=item.id).exists())

    def test_unauthenticated_cannot_access_wishlist(self):
        anon = APIClient()
        resp = anon.get("/api/wishlist/")
        self.assertEqual(resp.status_code, 401)
