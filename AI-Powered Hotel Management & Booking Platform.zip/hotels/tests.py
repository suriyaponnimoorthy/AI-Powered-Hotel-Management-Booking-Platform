from datetime import date, timedelta
from decimal import Decimal

from django.test import TestCase
from rest_framework.test import APIClient

from accounts.models import User
from .models import RoomType, Room, Amenity
from bookings.models import Booking, BookingRoom
from bookings.services import room_is_available, available_rooms_queryset, calculate_price


class RoomSearchAndAvailabilityTests(TestCase):
    def setUp(self):
        self.room_type = RoomType.objects.create(
            name="Deluxe Room", base_price=Decimal("6500"), max_guests=2, bed_type="King", room_size="340 sq.ft"
        )
        self.room = Room.objects.create(
            room_number="101", room_type=self.room_type, floor=1,
            price_per_night=Decimal("6500"), is_available=True,
        )
        wifi = Amenity.objects.create(name="Wi-Fi")
        self.room.amenities.add(wifi)
        self.user = User.objects.create_user(username="guest", password="pass1234!")

    def test_room_available_with_no_bookings(self):
        ci, co = date.today(), date.today() + timedelta(days=2)
        self.assertTrue(room_is_available(self.room, ci, co))

    def test_room_unavailable_when_overlapping_confirmed_booking(self):
        ci, co = date.today() + timedelta(days=5), date.today() + timedelta(days=8)
        booking = Booking.objects.create(
            user=self.user, check_in=ci, check_out=co, number_of_guests=2,
            status=Booking.Status.CONFIRMED, total_amount=1000,
        )
        BookingRoom.objects.create(booking=booking, room=self.room, price_at_booking=self.room.price_per_night)

        overlap_ci, overlap_co = ci + timedelta(days=1), co + timedelta(days=1)
        self.assertFalse(room_is_available(self.room, overlap_ci, overlap_co))

    def test_room_available_again_after_cancellation(self):
        ci, co = date.today() + timedelta(days=5), date.today() + timedelta(days=8)
        booking = Booking.objects.create(
            user=self.user, check_in=ci, check_out=co, number_of_guests=2,
            status=Booking.Status.CANCELLED, total_amount=1000,
        )
        BookingRoom.objects.create(booking=booking, room=self.room, price_at_booking=self.room.price_per_night)
        self.assertTrue(room_is_available(self.room, ci, co))

    def test_available_rooms_queryset_excludes_maintenance(self):
        self.room.status = Room.Status.MAINTENANCE
        self.room.save()
        ci, co = date.today(), date.today() + timedelta(days=2)
        qs = available_rooms_queryset(ci, co)
        self.assertNotIn(self.room, qs)

    def test_price_calculation(self):
        ci, co = date.today(), date.today() + timedelta(days=3)
        result = calculate_price([self.room], ci, co, discount_percentage=Decimal("10"))
        self.assertEqual(result["nights"], 3)
        self.assertEqual(result["room_total"], Decimal("19500"))
        self.assertEqual(result["discount"], Decimal("1950.00"))

    def test_api_room_search_endpoint(self):
        client = APIClient()
        ci = (date.today() + timedelta(days=1)).isoformat()
        co = (date.today() + timedelta(days=3)).isoformat()
        resp = client.get(f"/api/rooms/search/?check_in={ci}&check_out={co}&guests=2")
        self.assertEqual(resp.status_code, 200)
        results = resp.data.get("results", resp.data)
        self.assertTrue(len(results) >= 1)

    def test_room_filter_by_price(self):
        client = APIClient()
        resp = client.get("/api/rooms/?min_price=7000")
        self.assertEqual(resp.status_code, 200)
        results = resp.data.get("results", resp.data)
        self.assertEqual(len(results), 0)
