from datetime import datetime, timedelta
from django.contrib import messages
from django.shortcuts import render, redirect, get_object_or_404

from .models import Room, RoomType, Amenity, NearbyAttraction, ContactMessage, HotelImage
from .filters import RoomFilter
from offers.models import Offer
from reviews.models import Review
from bookings.services import available_rooms_queryset


def home_view(request):
    featured_rooms = Room.objects.filter(is_available=True).select_related("room_type")[:6]
    amenities = Amenity.objects.all()[:8]
    active_offers = [o for o in Offer.objects.all() if o.is_valid_today()][:3]
    reviews = Review.objects.select_related("user", "room").order_by("-created_at")[:6]
    attractions = NearbyAttraction.objects.all()[:6]

    upcoming_booking = None
    last_booking = None
    if request.user.is_authenticated:
        from bookings.models import Booking
        from django.utils import timezone as tz
        user_bookings = Booking.objects.filter(user=request.user).select_related().prefetch_related(
            "booking_rooms__room__room_type")
        upcoming_booking = user_bookings.filter(
            status__in=[Booking.Status.CONFIRMED, Booking.Status.PENDING],
            check_in__gte=tz.localdate(),
        ).order_by("check_in").first()
        last_booking = user_bookings.exclude(status=Booking.Status.CANCELLED).order_by("-check_out").first()

    context = {
        "featured_rooms": featured_rooms,
        "amenities": amenities,
        "offers": active_offers,
        "reviews": reviews,
        "attractions": attractions,
        "upcoming_booking": upcoming_booking,
        "last_booking": last_booking,
    }
    return render(request, "home.html", context)


def about_view(request):
    return render(request, "about.html")


def room_list_view(request):
    check_in = request.GET.get("check_in")
    check_out = request.GET.get("check_out")

    qs = Room.objects.filter(is_available=True).select_related("room_type").prefetch_related("amenities")

    if check_in and check_out:
        try:
            ci = datetime.strptime(check_in, "%Y-%m-%d").date()
            co = datetime.strptime(check_out, "%Y-%m-%d").date()
            if co > ci:
                qs = available_rooms_queryset(ci, co, base_queryset=qs)
            else:
                messages.warning(request, "Check-out date must be after check-in date.")
        except ValueError:
            messages.warning(request, "Please provide valid dates.")

    room_filter = RoomFilter(request.GET, queryset=qs)
    room_types = RoomType.objects.all()
    amenities = Amenity.objects.all()

    sort = request.GET.get("sort")
    rooms = room_filter.qs
    if sort == "price_asc":
        rooms = rooms.order_by("price_per_night")
    elif sort == "price_desc":
        rooms = rooms.order_by("-price_per_night")

    context = {
        "rooms": rooms,
        "room_types": room_types,
        "amenities": amenities,
        "check_in": check_in,
        "check_out": check_out,
    }
    return render(request, "rooms/list.html", context)


def room_detail_view(request, room_id):
    room = get_object_or_404(Room.objects.select_related("room_type").prefetch_related(
        "amenities", "gallery", "reviews__user"), pk=room_id)
    similar_rooms = Room.objects.filter(room_type=room.room_type, is_available=True).exclude(pk=room.pk)[:3]

    why_this_room = None
    guests = request.GET.get("guests")
    budget = request.GET.get("budget")
    if guests or budget:
        from ai_assistant.services import why_this_room as compute_why
        criteria = {
            "guests": int(guests) if guests else None,
            "budget": int(budget) if budget else None,
            "preferences": request.GET.get("preferences", "").split(",") if request.GET.get("preferences") else [],
        }
        why_this_room = compute_why(room, criteria)

    context = {"room": room, "similar_rooms": similar_rooms, "why_this_room": why_this_room}
    return render(request, "rooms/detail.html", context)


def hotel_gallery_view(request):
    images = HotelImage.objects.all()
    featured = images.filter(is_primary=True).first() or images.first()
    return render(request, "hotel_gallery.html", {"images": images, "featured": featured})


def compare_rooms_view(request):
    ids = [i for i in request.GET.get("ids", "").split(",") if i.isdigit()][:3]
    rooms = Room.objects.filter(id__in=ids).select_related("room_type").prefetch_related("amenities")
    # preserve the order the user picked them in, if possible
    rooms = sorted(rooms, key=lambda r: ids.index(str(r.id))) if ids else []
    all_rooms = Room.objects.filter(is_available=True).select_related("room_type")
    return render(request, "compare.html", {"rooms": rooms, "all_rooms": all_rooms})


def contact_view(request):
    if request.method == "POST":
        ContactMessage.objects.create(
            name=request.POST.get("name", ""),
            email=request.POST.get("email", ""),
            phone=request.POST.get("phone", ""),
            subject=request.POST.get("subject", ""),
            message=request.POST.get("message", ""),
        )
        messages.success(request, "Thanks for reaching out — our team will respond shortly.")
        return redirect("hotels:contact")
    return render(request, "contact.html")
