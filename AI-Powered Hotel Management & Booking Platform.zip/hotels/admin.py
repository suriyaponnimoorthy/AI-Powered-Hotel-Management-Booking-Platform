from django.contrib import admin
from .models import (Amenity, RoomType, Room, RoomImage, HotelPolicy, HotelImage,
                      NearbyAttraction, HotelService, ContactMessage, Wishlist,
                      SpecialRequest, DigitalCheckIn)


class RoomImageInline(admin.TabularInline):
    model = RoomImage
    extra = 1


@admin.register(Room)
class RoomAdmin(admin.ModelAdmin):
    list_display = ("room_number", "room_type", "floor", "price_per_night", "status", "is_available")
    list_filter = ("status", "room_type", "is_available", "has_balcony")
    search_fields = ("room_number", "description")
    filter_horizontal = ("amenities",)
    inlines = [RoomImageInline]


@admin.register(RoomType)
class RoomTypeAdmin(admin.ModelAdmin):
    list_display = ("name", "base_price", "max_guests", "bed_type")
    search_fields = ("name",)


@admin.register(Amenity)
class AmenityAdmin(admin.ModelAdmin):
    list_display = ("name", "icon")
    search_fields = ("name",)


@admin.register(HotelPolicy)
class HotelPolicyAdmin(admin.ModelAdmin):
    list_display = ("key", "title", "value")
    search_fields = ("key", "title")


@admin.register(NearbyAttraction)
class NearbyAttractionAdmin(admin.ModelAdmin):
    list_display = ("name", "category", "distance_km")
    list_filter = ("category",)
    search_fields = ("name",)


@admin.register(HotelService)
class HotelServiceAdmin(admin.ModelAdmin):
    list_display = ("name", "price", "is_active")
    list_filter = ("is_active",)


@admin.register(ContactMessage)
class ContactMessageAdmin(admin.ModelAdmin):
    list_display = ("name", "email", "subject", "created_at", "is_read")
    list_filter = ("is_read", "created_at")
    search_fields = ("name", "email", "subject")
    readonly_fields = ("created_at",)


@admin.register(HotelImage)
class HotelImageAdmin(admin.ModelAdmin):
    list_display = ("category", "title", "is_primary", "display_order", "created_at")
    list_filter = ("category", "is_primary")
    search_fields = ("title", "alt_text")


@admin.register(Wishlist)
class WishlistAdmin(admin.ModelAdmin):
    list_display = ("user", "room", "created_at")
    search_fields = ("user__username", "room__room_number")


@admin.register(SpecialRequest)
class SpecialRequestAdmin(admin.ModelAdmin):
    list_display = ("booking", "request_type", "is_fulfilled", "created_at")
    list_filter = ("request_type", "is_fulfilled")


@admin.register(DigitalCheckIn)
class DigitalCheckInAdmin(admin.ModelAdmin):
    list_display = ("booking", "guest_full_name", "is_completed", "completed_at")
    list_filter = ("is_completed",)
    readonly_fields = ("completed_at",)
