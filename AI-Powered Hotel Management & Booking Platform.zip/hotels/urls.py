from django.urls import path
from django.views.generic import TemplateView
from . import views

app_name = "hotels"

urlpatterns = [
    path("", views.home_view, name="home"),
    path("recommendations/", TemplateView.as_view(template_name="recommendations.html"), name="recommendations"),
    path("about/", views.about_view, name="about"),
    path("rooms/", views.room_list_view, name="room_list"),
    path("rooms/<int:room_id>/", views.room_detail_view, name="room_detail"),
    path("hotel-gallery/", views.hotel_gallery_view, name="hotel_gallery"),
    path("compare/", views.compare_rooms_view, name="compare"),
    path("plan-my-stay/", TemplateView.as_view(template_name="plan_my_stay.html"), name="plan_my_stay"),
    path("contact/", views.contact_view, name="contact"),
]
