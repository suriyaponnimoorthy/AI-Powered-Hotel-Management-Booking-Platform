from rest_framework import viewsets, permissions, filters as drf_filters
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend

from .models import Room, RoomType, Amenity, NearbyAttraction, HotelPolicy, HotelService, ContactMessage, Wishlist
from .serializers import (
    RoomSerializer, RoomTypeSerializer, AmenitySerializer, RoomAvailabilitySerializer,
    NearbyAttractionSerializer, HotelPolicySerializer, HotelServiceSerializer, ContactMessageSerializer,
    WishlistSerializer,
)
from .filters import RoomFilter
from bookings.services import available_rooms_queryset


class RoomTypeViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = RoomType.objects.all()
    serializer_class = RoomTypeSerializer
    permission_classes = [permissions.AllowAny]


class AmenityViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Amenity.objects.all()
    serializer_class = AmenitySerializer
    permission_classes = [permissions.AllowAny]


class RoomViewSet(viewsets.ReadOnlyModelViewSet):
    """
    /api/rooms/                 -> list + filter (price, type, guests, amenities)
    /api/rooms/<id>/             -> detail
    /api/rooms/search/?check_in=&check_out=&guests=  -> real availability search
    """
    queryset = Room.objects.select_related("room_type").prefetch_related("amenities", "gallery").all()
    serializer_class = RoomSerializer
    permission_classes = [permissions.AllowAny]
    filter_backends = [DjangoFilterBackend, drf_filters.OrderingFilter]
    filterset_class = RoomFilter
    ordering_fields = ["price_per_night", "room_type__max_guests"]

    @action(detail=False, methods=["get"])
    def search(self, request):
        serializer = RoomAvailabilitySerializer(data=request.query_params)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        qs = self.get_queryset()
        qs = available_rooms_queryset(data["check_in"], data["check_out"], base_queryset=qs)
        if data.get("guests"):
            qs = qs.filter(room_type__max_guests__gte=data["guests"])
        if data.get("min_price"):
            qs = qs.filter(price_per_night__gte=data["min_price"])
        if data.get("max_price"):
            qs = qs.filter(price_per_night__lte=data["max_price"])

        page = self.paginate_queryset(qs)
        result = self.get_serializer(page or qs, many=True).data
        if page is not None:
            return self.get_paginated_response(result)
        return Response(result)


class NearbyAttractionViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = NearbyAttraction.objects.all()
    serializer_class = NearbyAttractionSerializer
    permission_classes = [permissions.AllowAny]


class HotelPolicyViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = HotelPolicy.objects.all()
    serializer_class = HotelPolicySerializer
    permission_classes = [permissions.AllowAny]
    lookup_field = "key"


class HotelServiceViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = HotelService.objects.filter(is_active=True)
    serializer_class = HotelServiceSerializer
    permission_classes = [permissions.AllowAny]


class WishlistViewSet(viewsets.ModelViewSet):
    """A guest's saved rooms — always scoped to the authenticated user."""
    serializer_class = WishlistSerializer
    permission_classes = [permissions.IsAuthenticated]
    http_method_names = ["get", "post", "delete"]

    def get_queryset(self):
        return Wishlist.objects.filter(user=self.request.user).select_related("room__room_type")

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


class ContactMessageViewSet(viewsets.ModelViewSet):
    queryset = ContactMessage.objects.all()
    serializer_class = ContactMessageSerializer
    http_method_names = ["get", "post"]

    def get_permissions(self):
        if self.action == "create":
            return [permissions.AllowAny()]
        return [permissions.IsAdminUser()]
