from django.core.exceptions import ValidationError
from django.db import models
from django.utils.text import slugify


class Amenity(models.Model):
    name = models.CharField(max_length=100, unique=True)
    icon = models.CharField(max_length=50, blank=True, help_text="Icon class/name, e.g. 'wifi'")

    class Meta:
        verbose_name_plural = "Amenities"
        ordering = ["name"]

    def __str__(self):
        return self.name


class RoomType(models.Model):
    name = models.CharField(max_length=100, unique=True)
    slug = models.SlugField(max_length=120, unique=True, blank=True)
    description = models.TextField(blank=True)
    base_price = models.DecimalField(max_digits=10, decimal_places=2)
    max_guests = models.PositiveIntegerField(default=2)
    bed_type = models.CharField(max_length=50, blank=True)
    room_size = models.CharField(max_length=30, blank=True, help_text="e.g. '350 sq.ft'")

    class Meta:
        ordering = ["base_price"]

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


class Room(models.Model):
    class Status(models.TextChoices):
        AVAILABLE = "AVAILABLE", "Available"
        OCCUPIED = "OCCUPIED", "Occupied"
        MAINTENANCE = "MAINTENANCE", "Maintenance"
        INACTIVE = "INACTIVE", "Inactive"

    room_number = models.CharField(max_length=10, unique=True)
    room_type = models.ForeignKey(RoomType, on_delete=models.CASCADE, related_name="rooms")
    floor = models.PositiveIntegerField(default=1)
    price_per_night = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=15, choices=Status.choices, default=Status.AVAILABLE)
    description = models.TextField(blank=True)
    image = models.ImageField(upload_to="rooms/", blank=True, null=True)
    amenities = models.ManyToManyField(Amenity, blank=True, related_name="rooms")
    has_balcony = models.BooleanField(default=False)
    is_available = models.BooleanField(default=True, help_text="Master on/off switch set by staff")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["room_number"]

    def __str__(self):
        return f"Room {self.room_number} ({self.room_type.name})"

    @property
    def average_rating(self):
        agg = self.reviews.aggregate(models.Avg("rating"))
        return round(agg["rating__avg"] or 0, 1)

    def is_available_for(self, check_in, check_out):
        """Real overlap-based availability check (see bookings.services)."""
        from bookings.services import room_is_available
        return room_is_available(self, check_in, check_out)


def validate_image_size(image):
    max_size_mb = 5
    if image.size > max_size_mb * 1024 * 1024:
        raise ValidationError(f"Image file too large ( > {max_size_mb}MB ).")


class RoomImage(models.Model):
    room = models.ForeignKey(Room, on_delete=models.CASCADE, related_name="gallery")
    image = models.ImageField(upload_to="rooms/", validators=[validate_image_size])
    title = models.CharField(max_length=150, blank=True)
    alt_text = models.CharField(max_length=200, blank=True)
    caption = models.CharField(max_length=150, blank=True)
    is_primary = models.BooleanField(default=False)
    display_order = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["display_order", "created_at"]

    def __str__(self):
        return f"Image for {self.room}"

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if self.is_primary:
            RoomImage.objects.filter(room=self.room).exclude(pk=self.pk).update(is_primary=False)


class HotelImage(models.Model):
    class Category(models.TextChoices):
        EXTERIOR = "EXTERIOR", "Exterior"
        LOBBY = "LOBBY", "Lobby"
        RECEPTION = "RECEPTION", "Reception"
        RESTAURANT = "RESTAURANT", "Restaurant"
        POOL = "POOL", "Swimming Pool"
        SPA = "SPA", "Spa"
        GYM = "GYM", "Gym"
        CONFERENCE = "CONFERENCE", "Conference Hall"
        GARDEN = "GARDEN", "Garden"
        ROOFTOP = "ROOFTOP", "Rooftop"
        LOUNGE = "LOUNGE", "Lounge"

    category = models.CharField(max_length=15, choices=Category.choices, default=Category.EXTERIOR)
    image = models.ImageField(upload_to="hotels/", validators=[validate_image_size])
    title = models.CharField(max_length=150, blank=True)
    alt_text = models.CharField(max_length=200, blank=True)
    description = models.TextField(blank=True)
    is_primary = models.BooleanField(default=False)
    display_order = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["display_order", "created_at"]

    def __str__(self):
        return f"{self.get_category_display()} — {self.title or self.image.name}"

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if self.is_primary:
            HotelImage.objects.exclude(pk=self.pk).update(is_primary=False)


class HotelPolicy(models.Model):
    """Single source of truth for policies the AI concierge must quote verbatim."""
    key = models.SlugField(max_length=50, unique=True)
    title = models.CharField(max_length=150)
    value = models.TextField(help_text="The actual policy text/value, e.g. '2:00 PM'")

    def __str__(self):
        return self.title


class NearbyAttraction(models.Model):
    class Category(models.TextChoices):
        RESTAURANT = "RESTAURANT", "Restaurant"
        MALL = "MALL", "Shopping Mall"
        AIRPORT = "AIRPORT", "Airport"
        TRAIN = "TRAIN", "Train Station"
        TOURIST = "TOURIST", "Tourist Attraction"
        BUSINESS = "BUSINESS", "Business District"

    name = models.CharField(max_length=150)
    category = models.CharField(max_length=15, choices=Category.choices)
    distance_km = models.DecimalField(max_digits=5, decimal_places=1)
    description = models.TextField(blank=True)

    class Meta:
        ordering = ["distance_km"]

    def __str__(self):
        return f"{self.name} ({self.get_category_display()})"


class HotelService(models.Model):
    """Extra services offered during booking, e.g. breakfast, airport transfer."""
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    price = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class Wishlist(models.Model):
    """A customer's saved/favorite rooms — synced across devices once logged in."""
    user = models.ForeignKey("accounts.User", on_delete=models.CASCADE, related_name="wishlist_items")
    room = models.ForeignKey(Room, on_delete=models.CASCADE, related_name="wishlisted_by")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("user", "room")
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.user} ♥ {self.room}"


class SpecialRequest(models.Model):
    """Structured guest requests attached to a booking, visible to staff."""
    class RequestType(models.TextChoices):
        EXTRA_PILLOWS = "EXTRA_PILLOWS", "Extra Pillows"
        BABY_CRIB = "BABY_CRIB", "Baby Crib"
        LATE_CHECKOUT = "LATE_CHECKOUT", "Late Checkout"
        AIRPORT_TRANSFER = "AIRPORT_TRANSFER", "Airport Transfer"
        ROOM_DECORATION = "ROOM_DECORATION", "Room Decoration"
        DIETARY = "DIETARY", "Dietary Preference"
        ACCESSIBILITY = "ACCESSIBILITY", "Accessibility Request"
        OTHER = "OTHER", "Other"

    booking = models.ForeignKey("bookings.Booking", on_delete=models.CASCADE, related_name="special_request_items")
    request_type = models.CharField(max_length=20, choices=RequestType.choices, default=RequestType.OTHER)
    details = models.TextField(blank=True)
    is_fulfilled = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.get_request_type_display()} for {self.booking}"


class DigitalCheckIn(models.Model):
    """Simulated pre-arrival digital check-in — no real ID verification performed."""
    booking = models.OneToOneField("bookings.Booking", on_delete=models.CASCADE, related_name="digital_checkin")
    arrival_time = models.CharField(max_length=30, blank=True, help_text="e.g. '3:00 PM'")
    guest_full_name = models.CharField(max_length=150)
    special_requests = models.TextField(blank=True)
    is_completed = models.BooleanField(default=False)
    completed_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"Digital check-in for {self.booking}"


class ContactMessage(models.Model):
    name = models.CharField(max_length=150)
    email = models.EmailField()
    phone = models.CharField(max_length=20, blank=True)
    subject = models.CharField(max_length=200)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.subject} - {self.name}"
