import random
from datetime import date, timedelta
from decimal import Decimal

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils import timezone

from accounts.models import User
from hotels.models import (
    RoomType, Room, Amenity, HotelPolicy, NearbyAttraction, HotelService, ContactMessage,
)
from bookings.models import Booking, BookingRoom, BookingService
from bookings.services import calculate_price
from payments.models import Payment
from reviews.models import Review
from offers.models import Offer
from notifications.models import Notification


class Command(BaseCommand):
    help = "Populate the database with realistic ABC Hotels demo/development data."

    def add_arguments(self, parser):
        parser.add_argument("--allow-demo-data", action="store_true")
        parser.add_argument(
            "--flush", action="store_true",
            help="Delete existing demo data before seeding (does not touch superusers).",
        )

    @transaction.atomic
    def handle(self, *args, **options):
        if not settings.DEBUG or not options["allow_demo_data"]:
            raise CommandError("Demo seeding requires DEBUG=True and --allow-demo-data.")
        if not options["flush"] and User.objects.filter(username__in=("frontdesk1", "manager1")).exists():
            raise CommandError("A demo staff username already exists. Use a fresh demo database.")
        if options["flush"]:
            self.stdout.write("Flushing existing demo data...")
            Notification.objects.all().delete()
            Review.objects.all().delete()
            Payment.objects.all().delete()
            BookingService.objects.all().delete()
            BookingRoom.objects.all().delete()
            Booking.objects.all().delete()
            Offer.objects.all().delete()
            HotelService.objects.all().delete()
            NearbyAttraction.objects.all().delete()
            HotelPolicy.objects.all().delete()
            ContactMessage.objects.all().delete()
            Room.objects.all().delete()
            RoomType.objects.all().delete()
            Amenity.objects.all().delete()
            User.objects.filter(is_superuser=False).delete()

        self.stdout.write("Seeding amenities...")
        amenity_names = [
            ("Wi-Fi", "wifi"), ("Swimming Pool", "pool"), ("Gym", "gym"), ("Spa", "spa"),
            ("Restaurant", "restaurant"), ("Parking", "parking"), ("Room Service", "room-service"),
            ("Airport Transfer", "airport"), ("Breakfast", "breakfast"), ("Air Conditioning", "ac"),
            ("TV", "tv"), ("Mini Bar", "minibar"), ("Balcony View", "balcony"),
            ("Work Desk", "desk"), ("Bathtub", "bathtub"),
        ]
        amenities = {}
        for name, icon in amenity_names:
            a, _ = Amenity.objects.get_or_create(name=name, defaults={"icon": icon})
            amenities[name] = a

        self.stdout.write("Seeding room types...")
        room_type_defs = [
            ("Standard Room", Decimal("4500"), 2, "Queen Bed", "280 sq.ft"),
            ("Deluxe Room", Decimal("6500"), 2, "King Bed", "340 sq.ft"),
            ("Executive Room", Decimal("8500"), 3, "King Bed + Sofa", "420 sq.ft"),
            ("Suite", Decimal("12000"), 4, "King Bed + Living Area", "600 sq.ft"),
            ("Presidential Suite", Decimal("20000"), 4, "King Bed + 2 Living Areas", "950 sq.ft"),
        ]
        room_types = []
        for name, price, guests, bed, size in room_type_defs:
            rt, _ = RoomType.objects.get_or_create(
                name=name,
                defaults={
                    "description": f"The {name} offers a refined blend of comfort and style, "
                                   f"perfect for {'business travelers' if guests <= 2 else 'families and groups'}.",
                    "base_price": price, "max_guests": guests, "bed_type": bed, "room_size": size,
                },
            )
            room_types.append(rt)

        self.stdout.write("Seeding rooms (20)...")
        rooms = []
        amenity_pool = list(amenities.values())
        for i in range(1, 21):
            rt = room_types[(i - 1) % len(room_types)]
            floor = ((i - 1) // 5) + 1
            room_number = f"{floor}{i:02d}"
            price_variance = Decimal(random.choice([0, 200, -200, 500]))
            room, created = Room.objects.get_or_create(
                room_number=room_number,
                defaults={
                    "room_type": rt,
                    "floor": floor,
                    "price_per_night": rt.base_price + price_variance,
                    "status": Room.Status.AVAILABLE,
                    "description": f"A well-appointed {rt.name.lower()} with modern amenities and a serene ambiance.",
                    "has_balcony": random.choice([True, False, False]),
                    "is_available": True,
                },
            )
            if created:
                chosen = random.sample(amenity_pool, k=min(6, len(amenity_pool)))
                room.amenities.set(chosen)
            rooms.append(room)

        self.stdout.write("Seeding hotel services (10)...")
        service_defs = [
            ("Breakfast", "Continental breakfast buffet", 500),
            ("Airport Transfer", "One-way private airport transfer", 1200),
            ("Spa Session", "60-minute relaxation spa treatment", 2500),
            ("Extra Bed", "Additional bed in the room", 800),
            ("Late Checkout", "Checkout extended to 3 PM", 700),
            ("Room Service (Premium)", "24-hour in-room dining", 300),
            ("Laundry Service", "Same-day laundry & pressing", 400),
            ("Airport Lounge Pass", "Access to airport lounge before your flight", 1500),
            ("Candlelight Dinner", "Private candlelight dinner setup", 3500),
            ("City Tour", "Half-day guided city tour", 1800),
        ]
        services = []
        for name, desc, price in service_defs:
            s, _ = HotelService.objects.get_or_create(name=name, defaults={"description": desc, "price": price})
            services.append(s)

        self.stdout.write("Seeding hotel policies...")
        policy_defs = [
            ("check_in", "Check-in Time", "2:00 PM"),
            ("check_out", "Check-out Time", "11:00 AM"),
            ("cancellation", "Cancellation Policy",
             "Free cancellation up to 48 hours before check-in. Cancellations within 48 hours are charged one night's stay."),
            ("pet_policy", "Pet Policy", "Pets are not permitted, except registered service animals."),
            ("child_policy", "Child Policy", "Children under 12 stay free when using existing bedding."),
            ("payment_policy", "Payment Policy", "Full payment is required at the time of booking to confirm a reservation."),
            ("smoking_policy", "Smoking Policy", "ABC Hotels is a smoke-free property; smoking is permitted only in designated outdoor areas."),
        ]
        for key, title, value in policy_defs:
            HotelPolicy.objects.get_or_create(key=key, defaults={"title": title, "value": value})

        self.stdout.write("Seeding nearby attractions (10)...")
        attraction_defs = [
            ("Grand Central Mall", NearbyAttraction.Category.MALL, 1.2, "Premium shopping and dining."),
            ("Riverside Fine Dining", NearbyAttraction.Category.RESTAURANT, 0.8, "Award-winning riverside restaurant."),
            ("City International Airport", NearbyAttraction.Category.AIRPORT, 14.5, "Main international airport."),
            ("Central Railway Station", NearbyAttraction.Category.TRAIN, 3.0, "Major railway hub."),
            ("Heritage Fort", NearbyAttraction.Category.TOURIST, 2.5, "Historic fort and museum."),
            ("Tech Business Park", NearbyAttraction.Category.BUSINESS, 5.0, "Corporate offices and convention center."),
            ("Old Town Bazaar", NearbyAttraction.Category.TOURIST, 1.8, "Traditional market and street food."),
            ("Lakeside Gardens", NearbyAttraction.Category.TOURIST, 3.5, "Botanical gardens with a scenic lake."),
            ("Skyline Rooftop Bar", NearbyAttraction.Category.RESTAURANT, 0.5, "Rooftop bar with city views."),
            ("Metro Business District", NearbyAttraction.Category.BUSINESS, 4.2, "Financial district with major corporate HQs."),
        ]
        for name, cat, dist, desc in attraction_defs:
            NearbyAttraction.objects.get_or_create(name=name, defaults={
                "category": cat, "distance_km": dist, "description": desc,
            })

        self.stdout.write("Seeding offers (5)...")
        today = timezone.localdate()
        offer_defs = [
            ("Weekend Escape", 20, "WEEKEND20", -5, 60),
            ("Early Booking", 25, "EARLY25", -10, 90),
            ("Honeymoon Package", 15, "HONEYMOON15", -3, 120),
            ("Festive Season Special", 30, "FESTIVE30", -1, 30),
            ("Long Stay Discount", 18, "LONGSTAY18", -7, 180),
        ]
        for title, pct, code, start_offset, end_offset in offer_defs:
            Offer.objects.get_or_create(promo_code=code, defaults={
                "title": title,
                "description": f"Enjoy {pct}% off with the {title} offer. Use code {code} at checkout.",
                "discount_percentage": Decimal(pct),
                "start_date": today + timedelta(days=start_offset),
                "end_date": today + timedelta(days=end_offset),
                "is_active": True,
            })

        self.stdout.write("Seeding customers (20)...")
        customers = []
        first_names = ["Aarav", "Vivaan", "Aditya", "Ishaan", "Ananya", "Diya", "Saanvi", "Myra",
                        "Kabir", "Rohan", "Neha", "Priya", "Karan", "Meera", "Arjun", "Sneha",
                        "Rahul", "Pooja", "Vikram", "Anjali"]
        for i, fname in enumerate(first_names, start=1):
            username = f"{fname.lower()}{i}"
            user, created = User.objects.get_or_create(
                username=username,
                defaults={
                    "email": f"{username}@example.com",
                    "first_name": fname,
                    "last_name": "Sharma",
                    "phone": f"9{random.randint(100000000, 999999999)}",
                    "role": User.Role.CUSTOMER,
                },
            )
            if created:
                user.set_unusable_password()
                user.reward_points = random.randint(0, 500)
                user.save()
            customers.append(user)

        self.stdout.write("Seeding Django Groups & Permissions for staff role separation...")
        from django.contrib.auth.models import Group, Permission
        from django.contrib.contenttypes.models import ContentType

        staff_group, _ = Group.objects.get_or_create(name="Hotel Staff")
        staff_perm_codenames = [
            ("bookings", "booking", ["view_booking", "change_booking"]),
            ("hotels", "room", ["view_room", "change_room"]),
            ("hotels", "specialrequest", ["view_specialrequest", "change_specialrequest"]),
            ("accounts", "user", ["view_user"]),
        ]
        for app_label, model, codenames in staff_perm_codenames:
            try:
                ct = ContentType.objects.get(app_label=app_label, model=model)
                perms = Permission.objects.filter(content_type=ct, codename__in=codenames)
                staff_group.permissions.add(*perms)
            except ContentType.DoesNotExist:
                pass  # model not yet migrated in this environment; safe to skip

        admin_group, _ = Group.objects.get_or_create(name="Hotel Admin")
        admin_group.permissions.set(Permission.objects.all())

        # A couple of staff accounts
        for uname, role, group in [
            ("frontdesk1", User.Role.STAFF, staff_group),
            ("manager1", User.Role.ADMIN, admin_group),
        ]:
            staff, created = User.objects.get_or_create(
                username=uname,
                defaults={"email": f"{uname}@abchotels.com", "role": role, "is_staff": True},
            )
            if not created:
                raise CommandError("A demo staff username already exists.")
            staff.set_unusable_password()
            staff.save(update_fields=["password"])
            staff.groups.add(group)

        self.stdout.write("Seeding bookings (15) with payments...")
        statuses_pool = [Booking.Status.CONFIRMED, Booking.Status.COMPLETED,
                          Booking.Status.CHECKED_OUT, Booking.Status.CANCELLED, Booking.Status.PENDING]
        created_bookings = []
        for i in range(15):
            user = random.choice(customers)
            room = random.choice(rooms)
            start_day = random.randint(-60, 30)
            nights = random.randint(1, 5)
            check_in = today + timedelta(days=start_day)
            check_out = check_in + timedelta(days=nights)
            status = random.choice(statuses_pool)

            pricing = calculate_price([room], check_in, check_out)
            booking = Booking.objects.create(
                user=user, check_in=check_in, check_out=check_out,
                number_of_guests=random.randint(1, room.room_type.max_guests),
                number_of_rooms=1, status=status,
                subtotal=pricing["subtotal"], discount=pricing["discount"],
                tax=pricing["tax"], total_amount=pricing["grand_total"],
            )
            BookingRoom.objects.create(booking=booking, room=room, price_at_booking=room.price_per_night)

            if random.random() < 0.6:
                service = random.choice(services)
                BookingService.objects.create(
                    booking=booking, service=service, quantity=1, price_at_booking=service.price,
                )

            if status != Booking.Status.PENDING:
                Payment.objects.create(
                    booking=booking, amount=booking.total_amount,
                    payment_method=Payment.Method.MOCK,
                    payment_status=Payment.Status.SUCCESS if status != Booking.Status.CANCELLED else Payment.Status.REFUNDED,
                    transaction_id=f"MOCK-{random.randint(10**10, 10**11-1)}",
                )
            created_bookings.append(booking)

        self.stdout.write("Seeding reviews (20)...")
        review_titles = ["Wonderful stay!", "Exceeded expectations", "Great value", "Will book again",
                          "Comfortable and clean", "Excellent service", "Perfect for families",
                          "Relaxing getaway", "Beautiful rooms", "Highly recommended"]
        completed_bookings = [b for b in created_bookings
                               if b.status in (Booking.Status.COMPLETED, Booking.Status.CHECKED_OUT)]
        review_pool = completed_bookings or created_bookings
        for i in range(20):
            booking = random.choice(review_pool)
            room = booking.booking_rooms.first().room if booking.booking_rooms.exists() else random.choice(rooms)
            Review.objects.get_or_create(
                user=booking.user, booking=booking, room=room,
                defaults={
                    "rating": random.randint(3, 5),
                    "title": random.choice(review_titles),
                    "comment": "The room was spotless, staff were attentive, and the AI concierge made "
                               "planning our stay incredibly easy. Would happily return.",
                },
            )

        self.stdout.write("Seeding notifications (10)...")
        notif_templates = [
            (Notification.Category.BOOKING_CONFIRMED, "Booking confirmed", "Your booking has been confirmed."),
            (Notification.Category.PAYMENT_SUCCESS, "Payment received", "We've received your payment successfully."),
            (Notification.Category.BOOKING_CANCELLED, "Booking cancelled", "Your booking has been cancelled as requested."),
            (Notification.Category.CHECKIN_REMINDER, "Check-in reminder", "Your check-in is coming up soon — we look forward to hosting you."),
            (Notification.Category.OFFER, "Special offer", "Enjoy 20% off your next weekend stay with code WEEKEND20."),
        ]
        for i in range(10):
            cat, title, msg = random.choice(notif_templates)
            Notification.objects.create(
                user=random.choice(customers), category=cat, title=title, message=msg,
                is_read=random.choice([True, False]),
            )

        self.stdout.write("Seeding a few contact messages...")
        for name, subj in [("Rita Kapoor", "Question about group booking"), ("Sam Lee", "Wheelchair accessibility")]:
            ContactMessage.objects.get_or_create(
                name=name, subject=subj,
                defaults={"email": f"{name.split()[0].lower()}@example.com", "message": "Could you share more details?"},
            )

        self.stdout.write(self.style.SUCCESS(
            "✔ Seed data created: 20 rooms, 5 room types, 15 amenities, 20 customers, "
            "15 bookings, 20 reviews, 5 offers, 10 services, 10 notifications, 10 attractions."
        ))
        self.stdout.write(self.style.SUCCESS(
            "Demo accounts have login disabled. Create separate accounts for local testing."
        ))
