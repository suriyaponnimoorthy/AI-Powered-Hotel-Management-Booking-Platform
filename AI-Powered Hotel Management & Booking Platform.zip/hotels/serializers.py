from rest_framework import serializers
from .models import Room, RoomType, Amenity, RoomImage, NearbyAttraction, HotelPolicy, HotelService, ContactMessage, Wishlist


class AmenitySerializer(serializers.ModelSerializer):
    class Meta:
        model = Amenity
        fields = ["id", "name", "icon"]


class RoomTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = RoomType
        fields = ["id", "name", "slug", "description", "base_price", "max_guests", "bed_type", "room_size"]


class RoomImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = RoomImage
        fields = ["id", "image", "caption"]


class RoomSerializer(serializers.ModelSerializer):
    room_type = RoomTypeSerializer(read_only=True)
    amenities = AmenitySerializer(many=True, read_only=True)
    gallery = RoomImageSerializer(many=True, read_only=True)
    average_rating = serializers.ReadOnlyField()

    class Meta:
        model = Room
        fields = ["id", "room_number", "room_type", "floor", "price_per_night", "status",
                  "description", "image", "amenities", "gallery", "has_balcony",
                  "is_available", "average_rating"]


class RoomAvailabilitySerializer(serializers.Serializer):
    check_in = serializers.DateField()
    check_out = serializers.DateField()
    guests = serializers.IntegerField(required=False, default=1)
    min_price = serializers.DecimalField(max_digits=10, decimal_places=2, required=False)
    max_price = serializers.DecimalField(max_digits=10, decimal_places=2, required=False)


class NearbyAttractionSerializer(serializers.ModelSerializer):
    class Meta:
        model = NearbyAttraction
        fields = ["id", "name", "category", "distance_km", "description"]


class HotelPolicySerializer(serializers.ModelSerializer):
    class Meta:
        model = HotelPolicy
        fields = ["key", "title", "value"]


class HotelServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = HotelService
        fields = ["id", "name", "description", "price", "is_active"]


class WishlistSerializer(serializers.ModelSerializer):
    room = RoomSerializer(read_only=True)
    room_id = serializers.PrimaryKeyRelatedField(queryset=Room.objects.all(), source="room", write_only=True)

    class Meta:
        model = Wishlist
        fields = ["id", "room", "room_id", "created_at"]
        read_only_fields = ["id", "created_at"]

    def validate_room_id(self, room):
        request = self.context.get("request")
        if request and Wishlist.objects.filter(user=request.user, room=room).exists():
            raise serializers.ValidationError("This room is already in your wishlist.")
        return room


class ContactMessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContactMessage
        fields = ["id", "name", "email", "phone", "subject", "message", "created_at"]
        read_only_fields = ["id", "created_at"]
