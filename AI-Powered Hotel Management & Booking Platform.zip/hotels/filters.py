import django_filters
from .models import Room


class RoomFilter(django_filters.FilterSet):
    min_price = django_filters.NumberFilter(field_name="price_per_night", lookup_expr="gte")
    max_price = django_filters.NumberFilter(field_name="price_per_night", lookup_expr="lte")
    room_type = django_filters.CharFilter(field_name="room_type__slug", lookup_expr="iexact")
    guests = django_filters.NumberFilter(field_name="room_type__max_guests", lookup_expr="gte")
    amenities = django_filters.CharFilter(method="filter_amenities")
    has_balcony = django_filters.BooleanFilter()

    class Meta:
        model = Room
        fields = ["room_type", "min_price", "max_price", "guests", "amenities", "has_balcony"]

    def filter_amenities(self, queryset, name, value):
        names = [v.strip() for v in value.split(",") if v.strip()]
        for n in names:
            queryset = queryset.filter(amenities__name__iexact=n)
        return queryset.distinct()
