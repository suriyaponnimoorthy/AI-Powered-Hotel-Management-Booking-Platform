from django.conf import settings
from django.db import models


class Notification(models.Model):
    class Category(models.TextChoices):
        BOOKING_CONFIRMED = "BOOKING_CONFIRMED", "Booking Confirmed"
        PAYMENT_SUCCESS = "PAYMENT_SUCCESS", "Payment Successful"
        BOOKING_CANCELLED = "BOOKING_CANCELLED", "Booking Cancelled"
        CHECKIN_REMINDER = "CHECKIN_REMINDER", "Check-in Reminder"
        OFFER = "OFFER", "Special Offer"
        GENERAL = "GENERAL", "General"

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notifications")
    category = models.CharField(max_length=25, choices=Category.choices, default=Category.GENERAL)
    title = models.CharField(max_length=150)
    message = models.TextField()
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.title
