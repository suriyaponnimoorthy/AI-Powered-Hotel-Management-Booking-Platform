from django.test import TestCase
from rest_framework.test import APIClient
from accounts.models import User
from .models import Notification


class NotificationTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="notifuser", password="pass1234!")
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)
        self.notif = Notification.objects.create(
            user=self.user, category=Notification.Category.GENERAL,
            title="Test", message="Hello",
        )

    def test_list_own_notifications_only(self):
        other = User.objects.create_user(username="other", password="pass1234!")
        Notification.objects.create(user=other, title="Not yours", message="x")
        resp = self.client.get("/api/notifications/")
        results = resp.data.get("results", resp.data)
        self.assertEqual(len(results), 1)

    def test_mark_read(self):
        resp = self.client.patch(f"/api/notifications/{self.notif.id}/mark_read/")
        self.assertEqual(resp.status_code, 200)
        self.notif.refresh_from_db()
        self.assertTrue(self.notif.is_read)
