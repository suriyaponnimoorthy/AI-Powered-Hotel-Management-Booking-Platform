"""ABC Hotels URL configuration."""
from .health import health
from accounts.throttling import limit_auth_attempts
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView

urlpatterns = [
    path("health/", health, name="health"),
    path("admin/login/", limit_auth_attempts("login", 20, 300)(admin.site.login)),
    path("admin/", admin.site.urls),
    path("identity/", include("kyc.urls")),
    path("api/identity/", include("kyc.api_urls")),
    path("payment-operations/", include("payments.urls")),

    # Website (Django templates)
    path("", include("hotels.urls")),
    path("accounts/", include("accounts.urls")),
    path("booking/", include("bookings.urls")),
    path("dashboard/", include("dashboard.urls")),
    path("admin-dashboard/", include("dashboard.admin_urls")),
    path("reviews/", include("reviews.urls")),
    path("offers/", include("offers.urls")),

    # REST API
    path("api/auth/", include("accounts.api_urls")),
    path("api/rooms/", include("hotels.api_urls")),
    path("api/bookings/", include("bookings.api_urls")),
    path("api/payments/", include("payments.api_urls")),
    path("api/reviews/", include("reviews.api_urls")),
    path("api/offers/", include("offers.api_urls")),
    path("api/notifications/", include("notifications.api_urls")),
    path("api/wishlist/", include("hotels.wishlist_urls")),
    path("api/check-in/", include("bookings.checkin_urls")),
    path("api/special-requests/", include("bookings.special_request_urls")),
    path("api/ai/", include("ai_assistant.urls")),

]

if settings.DEBUG:
    urlpatterns += [
        path("api/schema/", SpectacularAPIView.as_view(), name="schema"),
        path("api/docs/", SpectacularSwaggerView.as_view(url_name="schema"), name="api-docs"),
    ]
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATICFILES_DIRS[0])
