import base64
import binascii

from django.core.exceptions import ImproperlyConfigured


def production_secret(value, name):
    """Accept Render's base64 256-bit secret or a long random text secret."""
    try:
        decoded = base64.b64decode(value, validate=True)
    except (ValueError, binascii.Error):
        decoded = b""
    if len(value) == 44 and len(decoded) == 32 and len(set(decoded)) >= 16:
        return decoded.hex()
    if len(value) < 50 or len(set(value)) < 12 or value.lower().startswith(("django-insecure-", "change-me")):
        raise ImproperlyConfigured(f"Set {name} to a unique, randomly generated secret.")
    return value


class SensitiveResponseMiddleware:
    """Keep credentials and authenticated data out of intermediary caches."""

    private_prefixes = ("/accounts/", "/admin/", "/admin-dashboard/", "/dashboard/",
                        "/identity/", "/booking/", "/payment-operations/",
                        "/api/auth/", "/api/identity/", "/api/bookings/",
                        "/api/check-in/", "/api/payments/", "/api/notifications/",
                        "/api/wishlist/", "/api/special-requests/", "/api/ai/")

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        if request.path_info.startswith(self.private_prefixes) or getattr(request.user, "is_authenticated", False):
            response.headers["Cache-Control"] = "private, no-store"
        return response
