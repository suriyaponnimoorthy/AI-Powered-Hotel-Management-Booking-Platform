"""
Django settings for ABC Hotels project.
"""
import os
from pathlib import Path
from urllib.parse import urlsplit
from datetime import timedelta
from dotenv import load_dotenv
from django.core.exceptions import ImproperlyConfigured
import dj_database_url

from .security import production_secret

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

SECRET_KEY = os.getenv("SECRET_KEY", "django-insecure-change-me-in-production")
DEBUG = os.getenv("DEBUG", "False") == "True"
JWT_SIGNING_KEY = os.getenv("JWT_SIGNING_KEY", SECRET_KEY if DEBUG else "")
ALLOWED_HOSTS = [host.strip() for host in os.getenv("ALLOWED_HOSTS", "localhost,127.0.0.1").split(",") if host.strip()]
RENDER_EXTERNAL_HOSTNAME = os.getenv("RENDER_EXTERNAL_HOSTNAME", "")
if RENDER_EXTERNAL_HOSTNAME:
    ALLOWED_HOSTS.append(RENDER_EXTERNAL_HOSTNAME)
CSRF_TRUSTED_ORIGINS = [origin.strip() for origin in os.getenv("CSRF_TRUSTED_ORIGINS", "").split(",") if origin.strip()]
if RENDER_EXTERNAL_HOSTNAME:
    CSRF_TRUSTED_ORIGINS.append(f"https://{RENDER_EXTERNAL_HOSTNAME}")
if not DEBUG:
    SECRET_KEY = production_secret(SECRET_KEY, "SECRET_KEY")
    JWT_SIGNING_KEY = production_secret(JWT_SIGNING_KEY, "JWT_SIGNING_KEY")
    if JWT_SIGNING_KEY == SECRET_KEY:
        raise ImproperlyConfigured("JWT_SIGNING_KEY must be separate from SECRET_KEY.")
    if not ALLOWED_HOSTS or any("*" in host or host.startswith(".") for host in ALLOWED_HOSTS):
        raise ImproperlyConfigured("Production ALLOWED_HOSTS requires exact hostnames.")

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",

    # third party
    "rest_framework",
    "rest_framework_simplejwt",
    "rest_framework_simplejwt.token_blacklist",
    "corsheaders",
    "django_filters",
    "drf_spectacular",

    # local apps
    "accounts",
    "hotels",
    "bookings",
    "payments",
    "reviews",
    "offers",
    "notifications",
    "ai_assistant",
    "dashboard",
    "kyc",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.middleware.csp.ContentSecurityPolicyMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "kyc.middleware.PrivateUploadMiddleware",
    "corsheaders.middleware.CorsMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "config.security.SensitiveResponseMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "hotels.context_processors.hotel_policies",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"
ASGI_APPLICATION = "config.asgi.application"

# ---------------------------------------------------------------------------
# Database
# By default this uses SQLite so the project runs out-of-the-box for demos.
# Set USE_POSTGRES=True in .env (with the DATABASE_* vars) for production.
# ---------------------------------------------------------------------------
if os.getenv("DATABASE_URL"):
    DATABASES = {"default": dj_database_url.config(conn_max_age=600, conn_health_checks=True)}
elif os.getenv("USE_POSTGRES", "False") == "True":
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": os.getenv("DATABASE_NAME", "abc_hotels"),
            "USER": os.getenv("DATABASE_USER", "postgres"),
            "PASSWORD": os.getenv("DATABASE_PASSWORD", ""),
            "HOST": os.getenv("DATABASE_HOST", "localhost"),
            "PORT": os.getenv("DATABASE_PORT", "5432"),
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": BASE_DIR / "db.sqlite3",
        }
    }

if not DEBUG and DATABASES["default"]["ENGINE"] != "django.db.backends.postgresql":
    raise ImproperlyConfigured("Production requires PostgreSQL for reservation locking.")

AUTH_USER_MODEL = "accounts.User"

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LANGUAGE_CODE = "en-us"
TIME_ZONE = "Asia/Kolkata"
USE_I18N = True
USE_TZ = True

STATIC_URL = "/static/"
STATICFILES_DIRS = [BASE_DIR / "static"]
STATIC_ROOT = BASE_DIR / "staticfiles"
STORAGES = {
    "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
    "staticfiles": {"BACKEND": "whitenoise.storage.CompressedManifestStaticFilesStorage"},
}

MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

LOGIN_URL = "accounts:login"
LOGIN_REDIRECT_URL = "dashboard:overview"
LOGOUT_REDIRECT_URL = "hotels:home"

# ---------------------------------------------------------------------------
# REST Framework / JWT / API docs
# ---------------------------------------------------------------------------
REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": (
        "rest_framework_simplejwt.authentication.JWTAuthentication",
        "rest_framework.authentication.SessionAuthentication",
    ),
    "DEFAULT_PERMISSION_CLASSES": (
        "rest_framework.permissions.IsAuthenticatedOrReadOnly",
    ),
    "DEFAULT_FILTER_BACKENDS": ("django_filters.rest_framework.DjangoFilterBackend",),
    "DEFAULT_PAGINATION_CLASS": "rest_framework.pagination.PageNumberPagination",
    "PAGE_SIZE": 12,
    "DEFAULT_THROTTLE_RATES": {"ai": "20/min"},
    "DEFAULT_SCHEMA_CLASS": "drf_spectacular.openapi.AutoSchema",
}

SIMPLE_JWT = {
    "ACCESS_TOKEN_LIFETIME": timedelta(minutes=15),
    "SIGNING_KEY": JWT_SIGNING_KEY,
    "ROTATE_REFRESH_TOKENS": True,
    "BLACKLIST_AFTER_ROTATION": True,
    "CHECK_REVOKE_TOKEN": True,
    "TOKEN_REFRESH_SERIALIZER": "accounts.serializers.RotatingRefreshSerializer",
    "REFRESH_TOKEN_LIFETIME": timedelta(days=7),
}

SPECTACULAR_SETTINGS = {
    "TITLE": "ABC Hotels API",
    "DESCRIPTION": "AI-powered hotel management & booking platform API",
    "VERSION": "1.0.0",
}

CORS_ALLOWED_ORIGINS = [origin.strip() for origin in os.getenv("CORS_ALLOWED_ORIGINS", "").split(",") if origin.strip()]
SECURE_CSP = {
    "base-uri": ["'self'"],
    "object-src": ["'none'"],
    "frame-ancestors": ["'none'"],
}
SECURE_REFERRER_POLICY = "same-origin"

# ---------------------------------------------------------------------------
# AI Concierge configuration (provider-agnostic; see ai_assistant/services.py)
# ---------------------------------------------------------------------------
AI_PROVIDER = os.getenv("AI_PROVIDER", "anthropic")  # "anthropic" | "openai" | "mock"
AI_API_KEY = os.getenv("AI_API_KEY", "")
AI_MODEL = os.getenv("AI_MODEL", "claude-sonnet-4-6")

CURRENCY_SYMBOL = "₹"

# Mail is disabled until a delivery backend is configured.
EMAIL_BACKEND = os.getenv("EMAIL_BACKEND", "django.core.mail.backends.dummy.EmailBackend")
DEFAULT_FROM_EMAIL = os.getenv("DEFAULT_FROM_EMAIL", "no-reply@abchotels.example.com")
EMAIL_HOST = os.getenv("EMAIL_HOST", "")
EMAIL_PORT = int(os.getenv("EMAIL_PORT", "587"))
EMAIL_HOST_USER = os.getenv("EMAIL_HOST_USER", "")
EMAIL_HOST_PASSWORD = os.getenv("EMAIL_HOST_PASSWORD", "")
EMAIL_USE_TLS = os.getenv("EMAIL_USE_TLS", "True") == "True"

# Pending holds stop blocking inventory after this interval, even before cleanup.
BOOKING_HOLD_MINUTES = max(1, int(os.getenv('BOOKING_HOLD_MINUTES', '15')))
# Mock payments are restricted to local debug mode.
ALLOW_MOCK_PAYMENTS = DEBUG and os.getenv('ALLOW_MOCK_PAYMENTS', 'True') == 'True'

# Render terminates HTTPS and replaces the forwarded-proto header.
# Enable this only behind a trusted reverse proxy with that behavior.
if os.getenv("TRUST_PROXY_HTTPS", "False") == "True":
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
SECURE_SSL_REDIRECT = os.getenv("SECURE_SSL_REDIRECT", "False" if DEBUG else "True") == "True"
SESSION_COOKIE_SECURE = not DEBUG
CSRF_COOKIE_SECURE = not DEBUG
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_HSTS_SECONDS = int(os.getenv("SECURE_HSTS_SECONDS", "0" if DEBUG else "31536000"))
SECURE_HSTS_INCLUDE_SUBDOMAINS = False
SECURE_HSTS_PRELOAD = False

# Optional durable uploaded images. Never use the ephemeral host filesystem
# for production uploads. Static editorial photographs do not need S3.
if os.getenv("USE_S3", "False") == "True":
    media_endpoint = os.getenv("AWS_S3_ENDPOINT_URL") or None
    if not DEBUG and media_endpoint:
        endpoint = urlsplit(media_endpoint)
        if endpoint.scheme != "https" or not endpoint.hostname:
            raise ImproperlyConfigured("Production media storage requires an HTTPS endpoint.")
    STORAGES["default"] = {
        "BACKEND": "storages.backends.s3.S3Storage",
        "OPTIONS": {
            "bucket_name": os.environ["AWS_STORAGE_BUCKET_NAME"],
            "region_name": os.getenv("AWS_S3_REGION_NAME", "us-east-1"),
            "endpoint_url": media_endpoint,
            "default_acl": None,
            "querystring_auth": True,
            "file_overwrite": False,
        },
    }

# Hosted checkout; secrets never appear in templates or API responses.
PAYMENT_PROVIDER = os.getenv('PAYMENT_PROVIDER', 'mock' if DEBUG else 'disabled')
RAZORPAY_KEY_ID = os.getenv('RAZORPAY_KEY_ID', '')
RAZORPAY_KEY_SECRET = os.getenv('RAZORPAY_KEY_SECRET', '')
RAZORPAY_WEBHOOK_SECRET = os.getenv('RAZORPAY_WEBHOOK_SECRET', '')

# Private identity documents: separate storage, encryption and access controls.
KYC_ENABLED = os.getenv('KYC_ENABLED', 'False') == 'True'
KYC_ENCRYPTION_KEYS = [key.strip() for key in os.getenv('KYC_ENCRYPTION_KEYS', '').split(',') if key.strip()]
KYC_RETENTION_DAYS = max(1, min(365, int(os.getenv('KYC_RETENTION_DAYS', '30'))))
KYC_MAX_BYTES = 5 * 1024 * 1024
PRIVATE_UPLOAD_ROOT = Path(os.getenv('PRIVATE_UPLOAD_ROOT', str(BASE_DIR / 'private_uploads')))
PRIVATE_UPLOADS_USE_S3 = os.getenv('PRIVATE_UPLOADS_USE_S3', 'False') == 'True'
KYC_S3_BUCKET = os.getenv('KYC_S3_BUCKET', '')
KYC_S3_REGION = os.getenv('KYC_S3_REGION', 'ap-south-1')
KYC_S3_ENDPOINT = os.getenv('KYC_S3_ENDPOINT', '')
KYC_S3_KMS_KEY_ID = os.getenv('KYC_S3_KMS_KEY_ID', '')
KYC_SCANNER = os.getenv('KYC_SCANNER', 'clamd')
CLAMD_HOST = os.getenv('CLAMD_HOST', '127.0.0.1')
CLAMD_PORT = int(os.getenv('CLAMD_PORT', '3310'))
REST_FRAMEWORK['DEFAULT_THROTTLE_RATES']['kyc'] = '10/hour'
FILE_UPLOAD_MAX_MEMORY_SIZE = 1024 * 1024
DATA_UPLOAD_MAX_MEMORY_SIZE = 6 * 1024 * 1024

if not DEBUG:
    if not SECURE_SSL_REDIRECT or SECURE_HSTS_SECONDS < 31536000:
        raise ImproperlyConfigured("Production requires HTTPS redirects and at least one year of HSTS.")
    if PAYMENT_PROVIDER not in {"disabled", "razorpay"}:
        raise ImproperlyConfigured("Production payments must be disabled or use Razorpay.")
    if PAYMENT_PROVIDER == "razorpay":
        if not RAZORPAY_KEY_ID or not RAZORPAY_KEY_SECRET or len(RAZORPAY_WEBHOOK_SECRET) < 24:
            raise ImproperlyConfigured("Configure Razorpay credentials and a random webhook secret of at least 24 characters.")
        if RAZORPAY_WEBHOOK_SECRET == RAZORPAY_KEY_SECRET:
            raise ImproperlyConfigured("Use a separate Razorpay webhook secret.")
