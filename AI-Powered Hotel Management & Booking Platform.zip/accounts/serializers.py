from django.contrib.auth import authenticate
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError as DjangoValidationError
from django.db import transaction
from django.utils.crypto import constant_time_compare
from rest_framework_simplejwt.exceptions import InvalidToken
from rest_framework_simplejwt.serializers import TokenRefreshSerializer
from rest_framework_simplejwt.settings import api_settings
from rest_framework_simplejwt.token_blacklist.models import OutstandingToken
from rest_framework_simplejwt.utils import get_md5_hash_password
from rest_framework import serializers
from .models import User


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["id", "username", "first_name", "last_name", "email", "phone",
                  "profile_image", "role", "reward_points", "date_joined"]
        read_only_fields = ["id", "role", "reward_points", "date_joined"]


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=8, max_length=128, trim_whitespace=False)
    email = serializers.EmailField(required=True)

    class Meta:
        model = User
        fields = ["username", "email", "first_name", "last_name", "phone", "password"]

    def validate(self, attrs):
        user = User(**{key: value for key, value in attrs.items() if key != "password"})
        try:
            validate_password(attrs["password"], user)
        except DjangoValidationError as exc:
            raise serializers.ValidationError({"password": exc.messages}) from exc
        return attrs

    def create(self, validated_data):
        password = validated_data.pop("password")
        user = User(**validated_data, role=User.Role.CUSTOMER)
        user.set_password(password)
        user.save()
        return user


class LoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField(write_only=True, trim_whitespace=False)

    def validate(self, attrs):
        user = authenticate(username=attrs["username"], password=attrs["password"])
        if not user:
            raise serializers.ValidationError("Invalid credentials")
        attrs["user"] = user
        return attrs


class RotatingRefreshSerializer(TokenRefreshSerializer):
    @transaction.atomic
    def validate(self, attrs):
        refresh = self.token_class(attrs["refresh"])
        try:
            outstanding = OutstandingToken.objects.select_for_update().get(jti=refresh[api_settings.JTI_CLAIM])
            user = User.objects.get(pk=outstanding.user_id, is_active=True)
        except (OutstandingToken.DoesNotExist, User.DoesNotExist):
            raise InvalidToken("Refresh token is no longer valid.") from None
        password_claim = refresh.get(api_settings.REVOKE_TOKEN_CLAIM)
        if not password_claim or not constant_time_compare(password_claim, get_md5_hash_password(user.password)):
            raise InvalidToken("Refresh token is no longer valid.")
        # Validate again after acquiring the lock to catch concurrent rotation.
        return super().validate(attrs)
