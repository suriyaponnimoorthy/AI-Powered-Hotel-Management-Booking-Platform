from django.test import TestCase
from django.urls import reverse
from rest_framework.test import APIClient
from rest_framework import status
from .models import User


class RegistrationLoginTests(TestCase):
    def test_register_via_web(self):
        resp = self.client.post(reverse("accounts:register"), {
            "username": "newguest", "first_name": "New", "last_name": "Guest",
            "email": "newguest@example.com", "phone": "9998887777",
            "password1": "StrongPass123!", "password2": "StrongPass123!",
        })
        self.assertEqual(resp.status_code, 302)
        self.assertTrue(User.objects.filter(username="newguest").exists())

    def test_login_via_web(self):
        User.objects.create_user(username="guest1", password="StrongPass123!")
        resp = self.client.post(reverse("accounts:login"), {
            "username": "guest1", "password": "StrongPass123!",
        })
        self.assertEqual(resp.status_code, 302)

    def test_api_register_and_login(self):
        client = APIClient()
        resp = client.post("/api/auth/register/", {
            "username": "apiguest", "email": "apiguest@example.com",
            "first_name": "Api", "last_name": "Guest", "password": "StrongPass123!",
        })
        self.assertEqual(resp.status_code, status.HTTP_201_CREATED)
        self.assertIn("access", resp.data)

        resp2 = client.post("/api/auth/login/", {"username": "apiguest", "password": "StrongPass123!"})
        self.assertEqual(resp2.status_code, 200)
        self.assertIn("access", resp2.data)

    def test_api_login_invalid_credentials(self):
        client = APIClient()
        resp = client.post("/api/auth/login/", {"username": "nouser", "password": "wrong"})
        self.assertEqual(resp.status_code, 400)
