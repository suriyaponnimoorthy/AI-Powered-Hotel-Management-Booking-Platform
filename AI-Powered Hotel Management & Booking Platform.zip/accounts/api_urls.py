from django.urls import path
from rest_framework_simplejwt.views import TokenBlacklistView, TokenRefreshView
from . import api_views
from .throttling import limit_auth_attempts

urlpatterns = [
    path("register/", api_views.RegisterAPIView.as_view(), name="api-register"),
    path("login/", api_views.LoginAPIView.as_view(), name="api-login"),
    path("token/refresh/", limit_auth_attempts("token", 60, 300)(TokenRefreshView.as_view()), name="token-refresh"),
    path("token/revoke/", limit_auth_attempts("token", 60, 300)(TokenBlacklistView.as_view()), name="token-revoke"),
    path("profile/", api_views.ProfileAPIView.as_view(), name="api-profile"),
]
