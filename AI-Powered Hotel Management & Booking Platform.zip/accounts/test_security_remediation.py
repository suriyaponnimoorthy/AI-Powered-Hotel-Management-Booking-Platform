from contextlib import redirect_stdout
from datetime import timedelta
from io import StringIO
from unittest.mock import patch

from django.core.management import call_command, CommandError
from django.db import connection
from django.test import Client, TestCase, TransactionTestCase, override_settings
from django.utils import timezone
from rest_framework.test import APIClient

from accounts.models import User
from bookings.models import Booking, BookingRoom
from hotels.models import DigitalCheckIn, Room, RoomType
from payments.gateway import GatewayUnavailable
from payments.models import Payment
from payments.razorpay_services import create_order
from reviews.models import Review


class SecurityRemediationTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.owner = User.objects.create_user('guest', email='guest@example.test', password='Test-only-password-93!')
        cls.other = User.objects.create_user('other')
        room_type = RoomType.objects.create(name='Audit suite', base_price=1000)
        cls.room = Room.objects.create(room_type=room_type, room_number='101', price_per_night=1000)
        cls.other_room = Room.objects.create(room_type=room_type, room_number='102', price_per_night=1000)
        cls.start = timezone.localdate() + timedelta(days=1)

    def setUp(self):
        self.client = APIClient()

    def booking(self, status, room=None):
        booking = Booking.objects.create(
            user=self.owner, status=status, check_in=self.start, check_out=self.start + timedelta(days=1),
        )
        if room:
            BookingRoom.objects.create(booking=booking, room=room, price_at_booking=1000)
        return booking

    def test_only_owner_can_delete_review(self):
        booking = self.booking(Booking.Status.COMPLETED, self.room)
        review = Review.objects.create(user=self.owner, booking=booking, room=self.room, rating=5)
        url = f'/api/reviews/{review.pk}/'
        self.client.force_authenticate(self.other)
        self.assertEqual(self.client.delete(url).status_code, 404)
        self.client.force_authenticate(self.owner)
        self.assertEqual(self.client.delete(url).status_code, 204)

    def test_unbooked_room_cannot_get_verified_review(self):
        booking = self.booking(Booking.Status.COMPLETED, self.room)
        self.client.force_authenticate(self.owner)
        response = self.client.post('/api/reviews/', {
            'booking': booking.pk, 'room': self.other_room.pk, 'rating': 5,
            'title': 'Review', 'comment': 'Test comment',
        }, format='json')
        self.assertEqual(response.status_code, 400)
        old_review = Review.objects.create(user=self.owner, booking=booking, room=self.other_room, rating=5)
        self.assertFalse(old_review.is_verified_stay)

    def test_malformed_review_filter_is_client_error(self):
        self.assertEqual(self.client.get('/api/reviews/?room=bad').status_code, 400)

    def test_login_redirect_and_post_only_logout(self):
        client = Client(enforce_csrf_checks=True)
        client.get('/accounts/login/')
        token = client.cookies['csrftoken'].value
        response = client.post('/accounts/login/?next=https://example.test/', {
            'username': 'guest', 'password': 'Test-only-password-93!', 'csrfmiddlewaretoken': token,
        })
        self.assertEqual(response['Location'], '/dashboard/')
        self.assertEqual(client.get('/accounts/logout/').status_code, 405)
        self.assertEqual(client.post('/accounts/logout/').status_code, 403)
        self.assertEqual(client.post('/accounts/logout/', {
            'csrfmiddlewaretoken': client.cookies['csrftoken'].value,
        }).status_code, 302)

    @override_settings(EMAIL_BACKEND='django.core.mail.backends.console.EmailBackend')
    def test_reset_tokens_do_not_reach_console(self):
        output = StringIO()
        with redirect_stdout(output):
            response = self.client.post('/accounts/forgot-password/', {'email': self.owner.email})
        self.assertEqual(response.status_code, 302)
        self.assertNotIn('/accounts/reset/', output.getvalue())

    def test_login_limit_shared_across_web_and_api(self):
        for _ in range(20):
            response = self.client.post('/api/auth/login/', {}, format='json')
            self.assertEqual(response.status_code, 400)
        response = self.client.post('/accounts/login/', {})
        self.assertEqual(response.status_code, 429)
        self.assertIn('Retry-After', response.headers)
        self.assertEqual(self.client.post('/admin/login/', {}).status_code, 429)

    @override_settings(DEBUG=True)
    def test_demo_seed_rejects_reserved_username_collision(self):
        user = User.objects.create_user('manager1')
        with self.assertRaises(CommandError):
            call_command('seed_data', '--allow-demo-data', stdout=StringIO())
        self.assertFalse(user.groups.exists())
        self.assertFalse(user.has_perm('payments.issue_refund'))

    @override_settings(DEBUG=False)
    def test_demo_seed_blocked_in_production(self):
        with self.assertRaises(CommandError):
            call_command('seed_data', '--allow-demo-data', stdout=StringIO())

    def test_pending_checkin_rejected_and_confirmed_discards_legacy_id(self):
        booking = self.booking(Booking.Status.PENDING)
        self.client.force_authenticate(self.owner)
        payload = {'booking': booking.pk, 'guest_full_name': 'Test Guest', 'id_number': 'synthetic-id'}
        self.assertEqual(self.client.post('/api/check-in/', payload, format='json').status_code, 400)
        browser = Client()
        browser.force_login(self.owner)
        browser.post('/dashboard/check-in/', payload)
        self.assertFalse(DigitalCheckIn.objects.filter(booking=booking).exists())
        booking.status = Booking.Status.CONFIRMED
        booking.save()
        response = self.client.post('/api/check-in/', payload, format='json')
        self.assertEqual(response.status_code, 201)
        self.assertNotIn('id_number', response.json())
        self.assertNotIn('id_number', {field.name for field in DigitalCheckIn._meta.fields})

    def test_hold_duration_and_cumulative_room_quota(self):
        self.client.force_authenticate(self.owner)
        payload = {'room_ids': [self.room.pk], 'check_in': self.start.isoformat(),
                   'check_out': (self.start + timedelta(days=365)).isoformat(), 'number_of_guests': 1}
        self.assertEqual(self.client.post('/api/bookings/', payload, format='json').status_code, 400)
        held = self.booking(Booking.Status.PENDING, self.other_room)
        Booking.objects.filter(pk=held.pk).update(number_of_rooms=5)
        payload['check_out'] = (self.start + timedelta(days=1)).isoformat()
        self.assertEqual(self.client.post('/api/bookings/', payload, format='json').status_code, 400)


@override_settings(PAYMENT_PROVIDER='razorpay')
class CheckoutTransactionTests(TransactionTestCase):
    def test_provider_timeout_preserves_order_claim_without_open_transaction(self):
        user = User.objects.create_user('payer')
        start = timezone.localdate() + timedelta(days=1)
        booking = Booking.objects.create(
            user=user, check_in=start, check_out=start + timedelta(days=1), total_amount=1000,
        )

        def provider_call(payment):
            self.assertFalse(connection.in_atomic_block)
            self.assertTrue(Payment.objects.filter(pk=payment.pk).exists())
            raise GatewayUnavailable()

        with patch('payments.razorpay_services.RazorpayGateway.create_order', side_effect=provider_call) as provider:
            with self.assertRaises(GatewayUnavailable):
                create_order(booking.pk, user)
            with self.assertRaises(GatewayUnavailable):
                create_order(booking.pk, user)
        self.assertEqual(provider.call_count, 1)
        self.assertEqual(booking.payments.count(), 1)


class TokenHardeningTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user('token-user', password='Synthetic-Password-18!')

    def login(self):
        response = self.client.post('/api/auth/login/', {
            'username': self.user.username, 'password': 'Synthetic-Password-18!',
        })
        self.assertEqual(response.status_code, 200)
        self.assertIn('no-store', response.headers['Cache-Control'])
        return response.json()

    def test_refresh_rotates_and_replay_is_rejected(self):
        original = self.login()['refresh']
        endpoint = '/api/auth/token/refresh/'
        response = self.client.post(endpoint, {'refresh': original})
        self.assertEqual(response.status_code, 200)
        self.assertNotEqual(response.json()['refresh'], original)
        self.assertEqual(self.client.post(endpoint, {'refresh': original}).status_code, 401)
        self.assertEqual(self.client.post(endpoint, {'refresh': response.json()['refresh']}).status_code, 200)

    def test_password_change_revokes_access_and_refresh(self):
        tokens = self.login()
        self.user.set_password('Synthetic-Password-82!')
        self.user.save(update_fields=['password'])
        response = self.client.get('/api/auth/profile/', HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")
        self.assertEqual(response.status_code, 401)
        self.assertEqual(self.client.post('/api/auth/token/refresh/', {'refresh': tokens['refresh']}).status_code, 401)

    def test_explicit_refresh_revocation(self):
        refresh = self.login()['refresh']
        self.assertEqual(self.client.post('/api/auth/token/revoke/', {'refresh': refresh}).status_code, 200)
        self.assertEqual(self.client.post('/api/auth/token/refresh/', {'refresh': refresh}).status_code, 401)

    def test_api_rejects_common_password(self):
        response = self.client.post('/api/auth/register/', {
            'username': 'new-user', 'email': 'test@example.test', 'password': 'password123',
        })
        self.assertEqual(response.status_code, 400)
        self.assertIn('password', response.json())

    def test_response_headers_and_render_secret_format(self):
        import base64
        from django.core.exceptions import ImproperlyConfigured
        from config.security import production_secret

        secret = bytes(range(32))
        self.assertEqual(production_secret(base64.b64encode(secret).decode(), 'SECRET_KEY'), secret.hex())
        with self.assertRaises(ImproperlyConfigured):
            production_secret('x' * 60, 'SECRET_KEY')
        response = self.client.get('/accounts/login/')
        self.assertIn("object-src 'none'", response.headers['Content-Security-Policy'])
        self.assertIn('no-store', response.headers['Cache-Control'])
