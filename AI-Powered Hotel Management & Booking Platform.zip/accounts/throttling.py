import hashlib
from datetime import datetime, timezone
from functools import wraps

from django.db.models import F
from django.http import JsonResponse
from django.utils import timezone as django_timezone

from .models import AuthAttemptWindow


def limit_auth_attempts(scope, limit, seconds):
    """Use shared counters across workers. Only trust the socket peer address."""
    def decorate(view):
        @wraps(view)
        def wrapped(request, *args, **kwargs):
            if request.method != "POST":
                return view(request, *args, **kwargs)
            now = django_timezone.now()
            timestamp = int(now.timestamp())
            window_end = timestamp - timestamp % seconds + seconds
            address = request.META.get("REMOTE_ADDR") or "unknown"
            key = hashlib.sha256(f"{scope}:{address}:{window_end}".encode()).hexdigest()
            counter, created = AuthAttemptWindow.objects.get_or_create(
                key=key, defaults={"expires_at": datetime.fromtimestamp(window_end, timezone.utc)},
            )
            if created:
                AuthAttemptWindow.objects.filter(expires_at__lte=now).delete()
            allowed = AuthAttemptWindow.objects.filter(pk=counter.pk, count__lt=limit).update(
                count=F("count") + 1,
            )
            if not allowed:
                response = JsonResponse({"detail": "Too many attempts. Try again later."}, status=429)
                response["Retry-After"] = str(window_end - timestamp)
                return response
            return view(request, *args, **kwargs)
        return wrapped
    return decorate
