# ABC Hotels — premium editorial interface

The third project update blends minimalism with immersive photography, taking broad inspiration from Campbell Gray Hotels' hospitality presentation. ABC Hotels retains its own name, copy, navigation and functionality; no Campbell Gray logo, photography, video or text is included.

## Visual direction

- Warm ivory surfaces, charcoal text, bronze accents and fine dividing rules.
- Large serif headlines paired with small, spaced sans-serif navigation.
- Full-width hero photography, generous editorial spacing and simple room cards.
- Split-image experience section, personal planning links, offers and authentic database-backed guest reviews.
- Shared styling across room pages, recommendations, booking forms, account pages and dashboards.
- A compact expandable navigation menu and a restyled concierge.

## Files and customization

The original `static/css/style.css` remains as the application base; `static/css/premium.css` supplies the new design tokens and overrides. `templates/base.html` contains the new shared shell. `rooms/_card.html` is reused on the home and room-list pages. Shared menu/date/label helpers are in `static/js/main.js` and `static/js/premium.js`.

Five illustrative photos are bundled in `static/images/editorial/`; see SOURCES.md in that folder. Replace these with licensed, hotel-owned photography for launch. Uploaded room and gallery photos continue to take priority over the illustrative fallbacks. Fonts load from Google Fonts with system/Georgia fallbacks; self-host the fonts if fully offline operation is required.

The gallery uses a native dialog with keyboard close and focus restoration. The menu supports Escape and marks hidden links inert. Inputs have visible focus styling; shared JavaScript associates older form labels with their inputs. Motion preferences are respected. This is not a complete accessibility certification.

## Verification

- The full regression suite discovered 90 tests: 89 passed and the PostgreSQL concurrency test was skipped on SQLite.
- JavaScript syntax and Django system checks passed.
- Rendered Django page snapshots were reviewed in the browser at desktop width and in 390px iframe viewports. Menu expansion/Escape, narrow-screen concierge opening and gallery lightbox opening/closing were checked.
- The managed preview environment cannot execute this project's Python virtual environment. Browser review therefore used rendered snapshots with the real CSS, scripts and local images. Live AJAX/booking behavior was covered by the Django tests, not by a connected browser session in this update.
- No public deployment was created. The deliverable is the updated Django project ZIP.

Existing booking-safety and AI features remain in place. Read PROJECT_REVIEW.md for remaining live-payment, production and PostgreSQL-validation work.
