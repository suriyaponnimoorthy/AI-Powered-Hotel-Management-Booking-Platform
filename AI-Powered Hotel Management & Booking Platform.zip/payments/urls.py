from django.urls import path
from .operations_views import operations
app_name = 'payments'
urlpatterns = [path('', operations, name='operations')]
