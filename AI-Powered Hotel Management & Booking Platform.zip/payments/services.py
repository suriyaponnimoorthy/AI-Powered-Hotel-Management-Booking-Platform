"""
Pluggable payment gateway architecture.
Real Razorpay/Stripe integration should implement the same `charge()`
interface, so swapping providers doesn't touch view/booking logic.
"""
import uuid
from .models import Payment


class MockGateway:
    """Development gateway that always succeeds. Never use in production."""

    def charge(self, booking, amount, method=Payment.Method.MOCK):
        payment = Payment.objects.create(
            booking=booking,
            amount=amount,
            payment_method=method,
            payment_status=Payment.Status.SUCCESS,
            transaction_id=f"MOCK-{uuid.uuid4().hex[:12].upper()}",
        )
        return payment


def get_gateway(name="mock"):
    if name == "mock":
        return MockGateway()
    raise NotImplementedError(
        f"Gateway '{name}' is not yet wired up. Implement a class with a "
        f".charge(booking, amount) method mirroring MockGateway, using the "
        f"Razorpay/Stripe SDK and PAYMENT_API_KEY from settings."
    )


from django.conf import settings
from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError


@transaction.atomic
def confirm_mock_payment(booking_id):
    """Local demo only. Real gateways need verified, idempotent webhook handling."""
    from bookings.models import Booking
    from hotels.models import Room
    from bookings.services import active_reservation_query, _overlap_query
    from bookings.models import BookingRoom
    from notifications.models import Notification
    if not settings.ALLOW_MOCK_PAYMENTS or settings.PAYMENT_PROVIDER == 'razorpay':
        raise ValidationError('Demo payments are disabled. A real payment gateway must be configured.')
    booking = Booking.objects.select_for_update().get(pk=booking_id)
    existing = booking.payments.filter(payment_status=Payment.Status.SUCCESS).first()
    if booking.status == Booking.Status.CONFIRMED and existing:
        return booking  # Network retries return the original confirmation.
    if booking.status != Booking.Status.PENDING:
        raise ValidationError('Only a pending booking can be paid.')
    if existing:
        raise ValidationError('Payment records require staff review before retrying.')
    if booking.hold_expired or booking.check_in < timezone.localdate():
        raise ValidationError('This reservation hold has expired. Please make a new booking.')
    ids = list(booking.booking_rooms.values_list('room_id', flat=True))
    rooms = list(Room.objects.select_for_update().filter(id__in=ids).order_by('id'))
    if booking.hold_expired:
        raise ValidationError('This reservation hold has expired. Please make a new booking.')
    if not rooms or any(not r.is_available or r.status in ('MAINTENANCE', 'INACTIVE') for r in rooms):
        raise ValidationError('Reserved rooms are unavailable. Please contact the hotel.')
    conflicts = BookingRoom.objects.filter(room_id__in=ids).exclude(booking=booking).filter(
        active_reservation_query('booking__')).filter(_overlap_query(booking.check_in, booking.check_out))
    if conflicts.exists():
        raise ValidationError('The reserved inventory has changed. Please contact the hotel.')
    payment = get_gateway('mock').charge(booking, booking.total_amount)
    booking.status = Booking.Status.CONFIRMED
    booking.save(update_fields=['status', 'updated_at'])
    Notification.objects.create(user=booking.user, category=Notification.Category.PAYMENT_SUCCESS,
        title='Demo payment successful', message=f'Demo payment of ₹{payment.amount} recorded for {booking.booking_id}. No real money was collected.')
    Notification.objects.create(user=booking.user, category=Notification.Category.BOOKING_CONFIRMED,
        title='Booking confirmed', message=f'Booking {booking.booking_id} is confirmed in this demonstration.')
    return booking
