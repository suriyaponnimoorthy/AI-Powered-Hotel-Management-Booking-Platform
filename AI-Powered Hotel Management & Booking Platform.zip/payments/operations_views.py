from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.exceptions import PermissionDenied
from django.shortcuts import render, redirect, get_object_or_404
from django.db.models import Case, Value, When
from rest_framework.exceptions import APIException
from .models import Payment
from .razorpay_services import issue_refund


@login_required
def operations(request):
    if not request.user.is_active or not request.user.has_perm('payments.issue_refund'):
        raise PermissionDenied()
    if request.method == 'POST':
        pk = request.POST.get('payment_id', '')
        if not pk.isascii() or not pk.isdecimal() or len(pk) > 18:
            from django.http import HttpResponseBadRequest
            return HttpResponseBadRequest('Invalid payment.')
        payment = get_object_or_404(Payment, pk=pk)
        try:
            refund = issue_refund(payment.pk, request.user, request.POST.get('reason', ''))
            messages.success(request, f'Refund status: {refund.get_status_display()}.')
        except APIException as exc:
            messages.error(request, str(exc.detail))
        return redirect('payments:operations')
    priority = Case(
        When(requires_review=True, then=Value(0)),
        When(refund__status__in=["UNKNOWN", "FAILED"], then=Value(0)),
        When(payment_status=Payment.Status.PENDING, provider_order_id__isnull=True, then=Value(1)),
        default=Value(2),
    )
    payments = Payment.objects.filter(payment_method='RAZORPAY').select_related(
        'booking', 'refund',
    ).order_by(priority, '-created_at')[:100]
    return render(request, 'payments/operations.html', {'payments': payments})
