from django.urls import path
from .checkout_views import CheckoutAPIView, VerifyAPIView, RefundAPIView, razorpay_webhook
from rest_framework.routers import DefaultRouter
from .views import PaymentViewSet

router = DefaultRouter()
router.register("", PaymentViewSet, basename="payment")
urlpatterns = [
    path('checkout/<uuid:booking_id>/', CheckoutAPIView.as_view(), name='payment-checkout'),
    path('verify/<int:payment_pk>/', VerifyAPIView.as_view(), name='payment-verify'),
    path('refund/<int:payment_pk>/', RefundAPIView.as_view(), name='payment-refund'),
    path('webhook/razorpay/', razorpay_webhook, name='razorpay-webhook'),
] + router.urls
