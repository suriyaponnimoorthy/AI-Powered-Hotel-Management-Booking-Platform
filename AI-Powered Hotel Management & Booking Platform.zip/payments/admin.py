from django.contrib import admin
from .models import Payment, Refund, WebhookEvent, PaymentAudit
from kyc.admin import ReadOnlyAuditAdmin


@admin.register(Payment)
class PaymentAdmin(ReadOnlyAuditAdmin):
    list_display = ['payment_id', 'booking', 'amount', 'payment_method', 'payment_status', 'requires_review']
    list_filter = ['payment_status', 'payment_method', 'requires_review']


@admin.register(Refund)
class RefundAdmin(ReadOnlyAuditAdmin):
    list_display = ['refund_id', 'payment', 'amount', 'status', 'created_at']


@admin.register(WebhookEvent)
class WebhookAdmin(ReadOnlyAuditAdmin):
    list_display = ['event_type', 'outcome', 'created_at']


@admin.register(PaymentAudit)
class PaymentAuditAdmin(ReadOnlyAuditAdmin):
    list_display = ['payment', 'actor', 'action', 'created_at']
