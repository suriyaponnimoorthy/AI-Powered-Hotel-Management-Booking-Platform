from uuid import UUID

from django.core.management.base import BaseCommand, CommandError
from django.db.models import F
from django.utils import timezone
from payments.models import Payment
from payments.gateway import RazorpayGateway
from payments.razorpay_services import apply_capture, apply_refund
from rest_framework.exceptions import APIException


class Command(BaseCommand):
    help = 'Read provider state to recover missed capture/refund events. Does not initiate new refunds.'

    def add_arguments(self, parser):
        parser.add_argument('--limit', type=int, default=100)
        parser.add_argument('--payment-id', type=UUID, help='Reconcile one local payment UUID.')

    def handle(self, *args, **options):
        gateway = RazorpayGateway()
        failures = checked = 0
        payments = Payment.objects.filter(payment_method='RAZORPAY', provider_order_id__isnull=False).exclude(
            payment_status=Payment.Status.REFUNDED)
        if options['payment_id']:
            payments = payments.filter(payment_id=options['payment_id'])
            if not payments.exists():
                raise CommandError('No reconcilable Razorpay payment matched the supplied UUID.')
        payments = payments.order_by(F('last_reconciled_at').asc(nulls_first=True), 'pk')[:max(1, min(1000, options['limit']))]
        for payment in payments:
            try:
                for entity in gateway.order_payments(payment.provider_order_id).get('items', []):
                    if entity.get('status') in ('captured', 'refunded'):
                        apply_capture(entity)
                payment.refresh_from_db()
                if payment.provider_payment_id:
                    # Paginate so externally-created partial refunds cannot hide a full refund.
                    skip = 0
                    while True:
                        result = gateway.request('GET', f'payments/{payment.provider_payment_id}/refunds?count=100&skip={skip}')
                        items = result.get('items', [])
                        for entity in items:
                            apply_refund(entity)
                        if len(items) < 100:
                            break
                        skip += 100
                        if skip >= 10000:
                            raise CommandError('Too many refunds; investigate provider state.')
                checked += 1
            except APIException:
                failures += 1
            finally:
                Payment.objects.filter(pk=payment.pk).update(last_reconciled_at=timezone.now())
        self.stdout.write(f'Payments checked: {checked}; failures: {failures}.')
        if failures:
            raise CommandError('Some payments could not be reconciled. Check provider configuration and retry.')
