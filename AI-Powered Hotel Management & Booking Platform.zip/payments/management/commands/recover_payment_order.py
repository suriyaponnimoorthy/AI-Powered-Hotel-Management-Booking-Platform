from uuid import UUID

from django.core.management.base import BaseCommand, CommandError
from django.db import IntegrityError, transaction
from rest_framework.exceptions import APIException

from bookings.models import Booking
from payments.gateway import RazorpayGateway, provider_id
from payments.models import Payment
from payments.razorpay_services import audit


class Command(BaseCommand):
    help = "Verify and attach an existing Razorpay order after an ambiguous checkout timeout."

    def add_arguments(self, parser):
        parser.add_argument("payment_id", type=UUID)
        parser.add_argument("provider_order_id")

    def handle(self, *args, **options):
        payment = Payment.objects.filter(
            payment_id=options["payment_id"], payment_method=Payment.Method.RAZORPAY,
        ).first()
        if payment is None:
            raise CommandError("Razorpay checkout attempt not found.")

        try:
            order_id = provider_id(options["provider_order_id"], "order")
            order = RazorpayGateway().fetch_order(order_id)
        except APIException as exc:
            raise CommandError("Could not verify the provider order.") from exc

        try:
            with transaction.atomic():
                Booking.objects.select_for_update().get(pk=payment.booking_id)
                payment = Payment.objects.select_for_update().get(pk=payment.pk)
                if (order.get("id") != order_id or order.get("receipt") != payment.payment_id.hex
                        or order.get("amount") != int(payment.amount * 100)
                        or order.get("currency") != payment.currency):
                    raise CommandError("Order receipt, amount, or currency did not match.")
                if payment.provider_order_id == order_id:
                    self.stdout.write("Provider order already attached.")
                    return
                if payment.provider_order_id or payment.payment_status != Payment.Status.PENDING:
                    raise CommandError("This checkout cannot be reattached.")
                payment.provider_order_id = order_id
                payment.save(update_fields=["provider_order_id"])
                audit(payment, "order.recovered")
        except IntegrityError as exc:
            raise CommandError("Provider order already belongs to a different payment.") from exc
        self.stdout.write("Provider order attached. Run reconciliation to recover any captured payment.")
