from django.conf import settings
from django.core.management.base import BaseCommand, CommandError


class Command(BaseCommand):
    help = 'Check payment configuration without exposing secrets or making charges.'

    def handle(self,*args,**options):
        if settings.PAYMENT_PROVIDER != 'razorpay':
            raise CommandError('Razorpay checkout is not enabled.')
        if not all([settings.RAZORPAY_KEY_ID,settings.RAZORPAY_KEY_SECRET,settings.RAZORPAY_WEBHOOK_SECRET]):
            raise CommandError('Razorpay key ID, API secret and webhook secret are required.')
        if settings.ALLOW_MOCK_PAYMENTS:
            raise CommandError('Disable mock payments before using Razorpay.')
        mode='test' if settings.RAZORPAY_KEY_ID.startswith('rzp_test_') else 'live or custom'
        self.stdout.write(f'Payment settings present ({mode} mode). Provider connectivity and live processing not tested.')
