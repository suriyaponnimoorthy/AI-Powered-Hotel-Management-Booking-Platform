from rest_framework import serializers
from .models import Payment


class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = ["id", "payment_id", "booking", "amount", "payment_method",
                  "payment_status", "transaction_id", "currency", "requires_review", "created_at"]
        read_only_fields = fields
