"""Captured funds and booking fulfilment are separate, auditable decisions."""
import hashlib
import hmac
import json
import re
from django.conf import settings
from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError, PermissionDenied
from bookings.models import Booking, BookingRoom
from bookings.services import active_reservation_query, _overlap_query
from hotels.models import Room
from notifications.models import Notification
from .models import Payment, Refund, WebhookEvent, PaymentAudit
from .gateway import RazorpayGateway, GatewayUnavailable, provider_id


def audit(payment, action, actor=None):
    PaymentAudit.objects.create(payment=payment, actor=actor, action=action)


def verify_signature(body, signature, secret):
    if not secret or not isinstance(signature, str) or not re.fullmatch(r'[a-fA-F0-9]{64}', signature):
        raise PermissionDenied('Invalid payment signature.')
    expected = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, signature.lower()):
        raise PermissionDenied('Invalid payment signature.')


def create_order(booking_id, actor):
    if settings.PAYMENT_PROVIDER != 'razorpay':
        raise ValidationError('Razorpay checkout is not enabled.')

    with transaction.atomic():
        booking = Booking.objects.select_for_update().get(pk=booking_id, user=actor)
        validate_checkout_booking(booking)
        existing = booking.payments.filter(payment_method=Payment.Method.RAZORPAY).first()
        if existing:
            if existing.amount != booking.total_amount:
                raise ValidationError('Booking price changed. Contact the hotel before paying.')
            if existing.payment_status != Payment.Status.PENDING or existing.requires_review:
                raise ValidationError('This payment requires staff review.')
            if not existing.provider_order_id:
                raise GatewayUnavailable('Checkout is in progress or needs review. Do not retry payment for this reservation.')
            return existing
        if booking.payments.filter(payment_status=Payment.Status.SUCCESS).exists():
            raise ValidationError('Booking already paid.')
        payment = Payment.objects.create(
            booking=booking, amount=booking.total_amount, currency='INR',
            payment_method=Payment.Method.RAZORPAY,
        )
        audit(payment, 'order.requested', actor)

    # The committed row claims this booking's one order attempt. Keep it even
    # after a timeout so a retry cannot create another provider order.
    order = RazorpayGateway().create_order(payment)
    if order.get('amount') != int(payment.amount * 100) or order.get('currency') != payment.currency:
        raise GatewayUnavailable('Provider order did not match the booking.')
    order_id = provider_id(order.get('id'), 'order')
    with transaction.atomic():
        booking = Booking.objects.select_for_update().get(pk=booking_id)
        payment.refresh_from_db(fields=['provider_order_id'])
        if payment.provider_order_id and payment.provider_order_id != order_id:
            raise GatewayUnavailable('Provider order conflicts with an existing attachment.')
        payment.provider_order_id = order_id
        payment.save(update_fields=['provider_order_id'])
        audit(payment, 'order.created', actor)

    validate_checkout_booking(booking)
    return payment


def validate_checkout_booking(booking):
    if booking.status != Booking.Status.PENDING or booking.hold_expired or booking.check_in < timezone.localdate():
        raise ValidationError('This booking cannot be paid. Create a new reservation.')
    if booking.total_amount <= 0:
        raise ValidationError('Booking amount must be positive.')


@transaction.atomic
def apply_capture(entity):
    """Caller must authenticate webhook or fetch this entity server-to-server."""
    order_id = provider_id(entity.get('order_id'), 'order')
    initial = Payment.objects.filter(provider_order_id=order_id).first()
    if initial is None:
        return None  # Not an order owned by this application.
    booking = Booking.objects.select_for_update().get(pk=initial.booking_id)
    payment = Payment.objects.select_for_update().get(pk=initial.pk)
    payment_id = provider_id(entity.get('id'), 'pay')
    if (entity.get('currency') != payment.currency or entity.get('amount') != int(payment.amount * 100)
            or entity.get('status') not in ('captured', 'refunded') or entity.get('captured') is not True):
        raise ValidationError('Payment is not captured or does not match the stored order.')
    if payment.provider_payment_id and payment.provider_payment_id != payment_id:
        raise ValidationError('Another payment is already linked to this order.')
    if payment.payment_status in [Payment.Status.SUCCESS, Payment.Status.REFUNDED]:
        return payment  # Never fulfil twice or regress a refunded payment.
    payment.provider_payment_id = payment_id
    payment.transaction_id = payment_id
    payment.payment_status = Payment.Status.SUCCESS
    rooms = list(Room.objects.select_for_update().filter(
        id__in=booking.booking_rooms.values('room_id')).order_by('id'))
    conflicts = BookingRoom.objects.filter(room__in=rooms).exclude(booking=booking).filter(
        active_reservation_query('booking__')).filter(_overlap_query(booking.check_in, booking.check_out)).exists()
    other_paid = booking.payments.exclude(pk=payment.pk).filter(payment_status=Payment.Status.SUCCESS).exists()
    can_fulfil = (payment.amount == booking.total_amount and entity.get('status') == 'captured' and booking.status == Booking.Status.PENDING and not booking.hold_expired
        and booking.check_in >= timezone.localdate() and rooms and not conflicts and not other_paid
        and all(r.is_available and r.status not in ('MAINTENANCE', 'INACTIVE') for r in rooms))
    if can_fulfil:
        booking.status = Booking.Status.CONFIRMED
        booking.save(update_fields=['status', 'updated_at'])
    else:
        payment.requires_review = True
    payment.save(update_fields=['provider_payment_id', 'transaction_id', 'payment_status', 'requires_review'])
    audit(payment, 'capture.review_required' if payment.requires_review else 'capture.confirmed')
    Notification.objects.create(user=booking.user, category=Notification.Category.PAYMENT_SUCCESS,
        title='Payment received', message=(f'Payment for booking {booking.booking_id} was received. '
        + ('Please contact the hotel: the reservation requires review.' if payment.requires_review else 'Your reservation is confirmed.')))
    return payment


def verify_checkout(payment, payment_id, order_id, signature):
    if order_id != payment.provider_order_id:
        raise ValidationError('Payment order mismatch.')
    provider_id(payment_id, 'pay')
    verify_signature(f'{payment.provider_order_id}|{payment_id}'.encode(), signature, settings.RAZORPAY_KEY_SECRET)
    entity = RazorpayGateway().fetch_payment(payment_id)
    if entity.get('order_id') != payment.provider_order_id or entity.get('id') != payment_id:
        raise ValidationError('Provider payment mismatch.')
    return apply_capture(entity)


@transaction.atomic
def apply_refund(entity):
    refund_id = provider_id(entity.get('id'), 'rfnd')
    # Mapping by payment id also reconciles full refunds initiated in Razorpay's dashboard.
    payment = Payment.objects.filter(provider_payment_id=entity.get('payment_id')).first()
    if payment is None:
        return None
    booking = Booking.objects.select_for_update().get(pk=payment.booking_id)
    payment = Payment.objects.select_for_update().get(pk=payment.pk)
    if entity.get('amount') != int(payment.amount * 100) or entity.get('currency') != payment.currency:
        payment.requires_review = True
        payment.save(update_fields=['requires_review'])
        audit(payment, 'refund.partial_or_mismatch_review')
        return None  # Partial/external adjustments require manual reconciliation.
    refund, _ = Refund.objects.get_or_create(payment=payment, defaults={
        'amount': payment.amount, 'reason': 'Provider refund reconciliation'})
    if refund.provider_refund_id and refund.provider_refund_id != refund_id:
        raise ValidationError('Provider refund conflict.')
    refund.provider_refund_id = refund_id
    incoming = {'processed': Refund.Status.PROCESSED, 'failed': Refund.Status.FAILED,
                'pending': Refund.Status.PENDING}.get(entity.get('status'))
    if not incoming:
        raise ValidationError('Unknown refund status.')
    if refund.status != Refund.Status.PROCESSED:
        refund.status = incoming
    refund.save(update_fields=['provider_refund_id', 'status', 'updated_at'])
    if refund.status == Refund.Status.PROCESSED and payment.payment_status != Payment.Status.REFUNDED:
        payment.payment_status = Payment.Status.REFUNDED
        payment.requires_review = False
        payment.save(update_fields=['payment_status', 'requires_review'])
        # Paid inventory must not remain confirmed after a full provider refund.
        if booking.status in [Booking.Status.PENDING, Booking.Status.CONFIRMED]:
            booking.status = Booking.Status.CANCELLED
            booking.save(update_fields=['status', 'updated_at'])
        audit(payment, 'refund.processed')
        Notification.objects.create(user=booking.user, category=Notification.Category.GENERAL,
            title='Refund processed', message=f'The refund for booking {booking.booking_id} has been processed by the payment provider.')
    return refund


def issue_refund(payment_pk, actor, reason):
    if not actor.is_active or not actor.has_perm('payments.issue_refund'):
        raise PermissionDenied('Refund approval permission is required.')
    reason = str(reason).strip()
    if not 10 <= len(reason) <= 250:
        raise ValidationError('Provide a refund reason between 10 and 250 characters.')
    # Persist the idempotency key BEFORE the provider call, including across crashes.
    with transaction.atomic():
        initial = Payment.objects.get(pk=payment_pk)
        booking = Booking.objects.select_for_update().get(pk=initial.booking_id)
        payment = Payment.objects.select_for_update().get(pk=payment_pk)
        if payment.payment_method != Payment.Method.RAZORPAY or not payment.provider_payment_id:
            raise ValidationError('Only captured Razorpay payments can be refunded here.')
        if payment.payment_status not in [Payment.Status.SUCCESS, Payment.Status.REFUNDED]:
            raise ValidationError('Payment has not been captured.')
        if booking.status != Booking.Status.CANCELLED and not payment.requires_review:
            raise ValidationError('Cancel the booking before refunding it.')
        refund, created = Refund.objects.get_or_create(payment=payment, defaults={
            'amount': payment.amount, 'reason': reason, 'requested_by': actor})
        if created:
            audit(payment, 'refund.requested', actor)
    if refund.status == Refund.Status.PROCESSED:
        return refund
    try:
        entity = (RazorpayGateway().fetch_refund(refund.provider_refund_id)
                  if refund.provider_refund_id else RazorpayGateway().refund(refund))
        if entity.get('payment_id') != refund.payment.provider_payment_id:
            raise ValidationError('Provider refund payment mismatch.')
        result = apply_refund(entity)
        if result is None:
            raise GatewayUnavailable('Refund requires provider reconciliation.')
        return result
    except (GatewayUnavailable, ValidationError):
        Refund.objects.filter(pk=refund.pk).exclude(status=Refund.Status.PROCESSED).update(status=Refund.Status.UNKNOWN)
        raise


@transaction.atomic
def process_webhook(raw_body, signature, provider_event_id=''):
    verify_signature(raw_body, signature, settings.RAZORPAY_WEBHOOK_SECRET)
    try:
        payload = json.loads(raw_body)
        kind = payload['event']
        if not isinstance(kind, str) or len(kind) > 80:
            raise ValueError()
    except (ValueError, KeyError, TypeError):
        raise ValidationError('Malformed webhook.') from None
    event, created = WebhookEvent.objects.get_or_create(body_hash=hashlib.sha256(raw_body).hexdigest(),
        defaults={'provider_event_id': provider_event_id[:100], 'event_type': kind})
    if not created:
        return 'duplicate'
    try:
        if kind == 'payment.captured':
            result = apply_capture(payload['payload']['payment']['entity'])
            event.outcome = 'processed' if result else 'unmatched_order'
        elif kind in ('refund.created', 'refund.processed', 'refund.failed'):
            result = apply_refund(payload['payload']['refund']['entity'])
            event.outcome = 'processed' if result else 'manual_review_or_unmatched'
        else:
            event.outcome = 'ignored'
    except (KeyError, TypeError):
        raise ValidationError('Malformed webhook entity.') from None
    event.save(update_fields=['outcome'])
    return event.outcome
