"""Razorpay HTTP adapter. Never expose provider errors, keys or card data."""
import re
from decimal import Decimal
import requests
from django.conf import settings
from rest_framework.exceptions import APIException


class GatewayUnavailable(APIException):
    status_code = 503
    default_detail = 'Payment provider unavailable. Check payment status before retrying.'


def provider_id(value, prefix):
    if not isinstance(value, str) or not re.fullmatch(prefix + r'_[A-Za-z0-9]{1,80}', value):
        from rest_framework.exceptions import ValidationError
        raise ValidationError('Invalid provider identifier.')
    return value


class RazorpayGateway:
    def request(self, method, path, *, data=None, headers=None):
        if not settings.RAZORPAY_KEY_ID or not settings.RAZORPAY_KEY_SECRET:
            raise GatewayUnavailable('Payment provider is not configured.')
        try:
            response = requests.request(method, 'https://api.razorpay.com/v1/' + path,
                auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET),
                json=data, headers=headers, timeout=(3.05, 15))
            response.raise_for_status()
            result = response.json()
            if not isinstance(result, dict):
                raise ValueError()
            return result
        except (requests.RequestException, ValueError):
            raise GatewayUnavailable() from None

    def create_order(self, payment):
        return self.request('POST', 'orders', data={
            'amount': int(Decimal(payment.amount) * 100), 'currency': payment.currency,
            'receipt': payment.payment_id.hex, 'partial_payment': False,
            'notes': {'booking_id': str(payment.booking.booking_id)}})

    def fetch_order(self, order_id):
        return self.request("GET", "orders/" + provider_id(order_id, "order"))

    def fetch_payment(self, payment_id):
        return self.request('GET', 'payments/' + provider_id(payment_id, 'pay'))

    def order_payments(self, order_id):
        return self.request('GET', 'orders/' + provider_id(order_id, 'order') + '/payments')

    def refund(self, refund):
        return self.request('POST', 'payments/' + provider_id(refund.payment.provider_payment_id, 'pay') + '/refund',
            headers={'X-Refund-Idempotency': str(refund.refund_id)},
            data={'amount': int(Decimal(refund.amount) * 100), 'speed': 'normal',
                  'receipt': refund.refund_id.hex,
                  'notes': {'refund_request': str(refund.refund_id)}})

    def fetch_refund(self, refund_id):
        return self.request('GET', 'refunds/' + provider_id(refund_id, 'rfnd'))
