from django.shortcuts import get_object_or_404
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.http import JsonResponse
from django.conf import settings
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.exceptions import APIException, ValidationError
from bookings.models import Booking
from .models import Payment
from .razorpay_services import create_order, verify_checkout, process_webhook, issue_refund


class CheckoutAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, booking_id):
        booking = get_object_or_404(Booking, booking_id=booking_id, user=request.user)
        payment = create_order(booking.pk, request.user)
        return Response({'payment_id': payment.pk, 'key': settings.RAZORPAY_KEY_ID,
            'order_id': payment.provider_order_id, 'amount': int(payment.amount * 100),
            'currency': payment.currency, 'name': 'ABC Hotels'})


class VerifyAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, payment_pk):
        payment = get_object_or_404(Payment, pk=payment_pk, booking__user=request.user,
                                   payment_method=Payment.Method.RAZORPAY)
        data = request.data
        for key in ('razorpay_payment_id', 'razorpay_order_id', 'razorpay_signature'):
            if not isinstance(data.get(key), str) or len(data[key]) > 150:
                raise ValidationError('Missing or invalid payment verification details.')
        payment = verify_checkout(payment, data['razorpay_payment_id'], data['razorpay_order_id'], data['razorpay_signature'])
        return Response({'status': payment.payment_status, 'requires_review': payment.requires_review})


class RefundAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, payment_pk):
        # Authorize before revealing whether a payment exists.
        if not request.user.has_perm('payments.issue_refund'):
            from rest_framework.exceptions import PermissionDenied
            raise PermissionDenied('Refund approval permission is required.')
        get_object_or_404(Payment, pk=payment_pk)
        refund = issue_refund(payment_pk, request.user, request.data.get('reason', ''))
        return Response({'refund_id': str(refund.refund_id), 'status': refund.status})


@csrf_exempt
@require_POST
def razorpay_webhook(request):
    # This sole CSRF exemption is authenticated by the provider's HMAC signature.
    try:
        if int(request.META.get('CONTENT_LENGTH') or 0) > 256 * 1024:
            return JsonResponse({'detail': 'Webhook too large.'}, status=413)
        body = request.body
        if len(body) > 256 * 1024:
            return JsonResponse({'detail': 'Webhook too large.'}, status=413)
        result = process_webhook(body, request.headers.get('X-Razorpay-Signature', ''),
                                 request.headers.get('X-Razorpay-Event-Id', ''))
        return JsonResponse({'status': result})
    except APIException as exc:
        return JsonResponse({'detail': str(exc.detail)}, status=exc.status_code)
    except ValueError:
        return JsonResponse({'detail': 'Invalid request.'}, status=400)
