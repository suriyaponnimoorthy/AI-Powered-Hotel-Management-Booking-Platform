import uuid
from django.db import models
from bookings.models import Booking


class Payment(models.Model):
    class Method(models.TextChoices):
        RAZORPAY = "RAZORPAY", "Razorpay"
        STRIPE = "STRIPE", "Stripe"
        MOCK = "MOCK", "Mock Gateway (Dev)"

    class Status(models.TextChoices):
        PENDING = "PENDING", "Pending"
        SUCCESS = "SUCCESS", "Success"
        FAILED = "FAILED", "Failed"
        REFUNDED = "REFUNDED", "Refunded"

    payment_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name="payments")
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_method = models.CharField(max_length=15, choices=Method.choices, default=Method.MOCK)
    payment_status = models.CharField(max_length=15, choices=Status.choices, default=Status.PENDING)
    transaction_id = models.CharField(max_length=100, blank=True)
    currency = models.CharField(max_length=3, default='INR')
    provider_order_id = models.CharField(max_length=100, unique=True, null=True, blank=True)
    provider_payment_id = models.CharField(max_length=100, unique=True, null=True, blank=True)
    requires_review = models.BooleanField(default=False)
    last_reconciled_at = models.DateTimeField(null=True, blank=True, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Payment {str(self.payment_id)[:8]} - {self.payment_status}"


class Refund(models.Model):
    """One full refund per payment; UUID is reused for provider idempotency."""
    class Status(models.TextChoices):
        REQUESTED = 'REQUESTED', 'Requested'
        PENDING = 'PENDING', 'Pending at provider'
        PROCESSED = 'PROCESSED', 'Processed'
        FAILED = 'FAILED', 'Failed'
        UNKNOWN = 'UNKNOWN', 'Needs reconciliation'

    refund_id = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    payment = models.OneToOneField(Payment, on_delete=models.PROTECT, related_name='refund')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    reason = models.CharField(max_length=250)
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.REQUESTED)
    provider_refund_id = models.CharField(max_length=100, unique=True, null=True, blank=True)
    requested_by = models.ForeignKey('accounts.User', null=True, on_delete=models.SET_NULL)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        permissions = [('issue_refund', 'Approve and issue full payment refunds')]


class WebhookEvent(models.Model):
    body_hash = models.CharField(max_length=64, unique=True)
    provider_event_id = models.CharField(max_length=100, blank=True)
    event_type = models.CharField(max_length=80)
    outcome = models.CharField(max_length=80, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)


class PaymentAudit(models.Model):
    payment = models.ForeignKey(Payment, on_delete=models.PROTECT, related_name='audit_events')
    actor = models.ForeignKey('accounts.User', null=True, blank=True, on_delete=models.SET_NULL)
    action = models.CharField(max_length=80)
    created_at = models.DateTimeField(auto_now_add=True)
