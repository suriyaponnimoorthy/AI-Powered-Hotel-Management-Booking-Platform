import hashlib
import hmac
import json
from datetime import timedelta
from unittest.mock import patch
from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.utils import timezone
from rest_framework.test import APIClient
from rest_framework.exceptions import ValidationError, PermissionDenied
from hotels.models import RoomType, Room
from bookings.models import Booking, BookingRoom
from .models import Payment, Refund, WebhookEvent, PaymentAudit
from .gateway import GatewayUnavailable
from .razorpay_services import create_order, verify_checkout, apply_capture, issue_refund, process_webhook, apply_refund


@override_settings(PAYMENT_PROVIDER='razorpay', RAZORPAY_KEY_ID='rzp_test_example',
    RAZORPAY_KEY_SECRET='test_secret', RAZORPAY_WEBHOOK_SECRET='webhook_secret')
class LiveGatewayTests(TestCase):
    def setUp(self):
        User = get_user_model()
        self.user = User.objects.create_user(username='payer')
        self.other = User.objects.create_user(username='other')
        self.admin = User.objects.create_superuser(username='finance', password='unused', email='finance@example.com')
        room_type = RoomType.objects.create(name='Suite', base_price=1000, max_guests=2)
        self.room = Room.objects.create(room_number='101', room_type=room_type, price_per_night=1000)
        self.booking = Booking.objects.create(user=self.user, check_in=timezone.localdate()+timedelta(days=1),
            check_out=timezone.localdate()+timedelta(days=2), total_amount='1120.00')
        BookingRoom.objects.create(booking=self.booking, room=self.room, price_at_booking=1000)
        self.payment = Payment.objects.create(booking=self.booking, amount='1120.00', currency='INR',
            payment_method='RAZORPAY', provider_order_id='order_abc123')
        self.entity = {'id':'pay_abc123', 'order_id':'order_abc123', 'amount':112000,
            'currency':'INR', 'status':'captured', 'captured':True}

    def test_checkout_signature_and_server_capture_confirm_once(self):
        signature = hmac.new(b'test_secret', b'order_abc123|pay_abc123', hashlib.sha256).hexdigest()
        with patch('payments.razorpay_services.RazorpayGateway.fetch_payment', return_value=self.entity):
            verify_checkout(self.payment, 'pay_abc123', 'order_abc123', signature)
            verify_checkout(self.payment, 'pay_abc123', 'order_abc123', signature)
        self.booking.refresh_from_db()
        self.assertEqual(self.booking.status, 'CONFIRMED')
        self.assertEqual(PaymentAudit.objects.filter(action='capture.confirmed').count(), 1)

    def test_rejects_forged_signature_before_network(self):
        with patch('payments.razorpay_services.RazorpayGateway.fetch_payment') as fetch:
            with self.assertRaises(PermissionDenied):
                verify_checkout(self.payment, 'pay_abc123', 'order_abc123', '0'*64)
            fetch.assert_not_called()

    def test_rejects_wrong_amount_currency_and_uncaptured(self):
        for change in [{'amount':1}, {'currency':'USD'}, {'captured':False}, {'status':'authorized'}]:
            with self.assertRaises(ValidationError):
                apply_capture(dict(self.entity, **change))
        self.payment.refresh_from_db()
        self.assertEqual(self.payment.payment_status, 'PENDING')

    def test_late_capture_does_not_confirm_expired_inventory(self):
        Booking.objects.filter(pk=self.booking.pk).update(created_at=timezone.now()-timedelta(hours=1))
        payment = apply_capture(self.entity)
        self.booking.refresh_from_db()
        self.assertTrue(payment.requires_review)
        self.assertEqual(payment.payment_status, 'SUCCESS')
        self.assertEqual(self.booking.status, 'PENDING')

    def test_capture_after_cancellation_requires_review(self):
        self.booking.status='CANCELLED'; self.booking.save()
        self.assertTrue(apply_capture(self.entity).requires_review)

    def test_provider_returned_other_order_not_accepted(self):
        signature = hmac.new(b'test_secret', b'order_abc123|pay_abc123', hashlib.sha256).hexdigest()
        with patch('payments.razorpay_services.RazorpayGateway.fetch_payment', return_value=dict(self.entity, order_id='order_other')):
            with self.assertRaises(ValidationError):
                verify_checkout(self.payment, 'pay_abc123', 'order_abc123', signature)

    def test_webhook_signature_raw_body_and_duplicate_delivery(self):
        body = json.dumps({'event':'payment.captured', 'payload':{'payment':{'entity':self.entity}}}).encode()
        signature = hmac.new(b'webhook_secret', body, hashlib.sha256).hexdigest()
        self.assertEqual(process_webhook(body, signature, 'evt_1'), 'processed')
        self.assertEqual(process_webhook(body, signature, 'evt_1'), 'duplicate')
        self.assertEqual(WebhookEvent.objects.count(), 1)
        with self.assertRaises(PermissionDenied):
            process_webhook(body+b' ', signature)

    def test_owner_only_checkout_and_verification_api(self):
        client=APIClient(); client.force_authenticate(self.other)
        self.assertEqual(client.post(f'/api/payments/checkout/{self.booking.booking_id}/', {}).status_code, 404)
        self.assertEqual(client.post(f'/api/payments/verify/{self.payment.pk}/', {}).status_code, 404)
        self.assertEqual(client.post(f'/api/payments/refund/{self.payment.pk}/', {'reason':'not authorized'}).status_code,403)

    def test_existing_order_reused_without_provider_request(self):
        with patch('payments.razorpay_services.RazorpayGateway.create_order') as create:
            self.assertEqual(create_order(self.booking.pk,self.user).pk,self.payment.pk)
            create.assert_not_called()

    def test_refund_survives_network_timeout_and_reuses_idempotency(self):
        apply_capture(self.entity)
        self.booking.status='CANCELLED'; self.booking.save()
        with patch('payments.razorpay_services.RazorpayGateway.refund', side_effect=GatewayUnavailable()):
            with self.assertRaises(GatewayUnavailable):
                issue_refund(self.payment.pk,self.admin,'Customer cancelled reservation')
        refund=Refund.objects.get(payment=self.payment)
        original_key=refund.refund_id
        self.assertEqual(refund.status,'UNKNOWN')
        entity={'id':'rfnd_abc123','payment_id':'pay_abc123','amount':112000,'currency':'INR','status':'processed'}
        with patch('payments.razorpay_services.RazorpayGateway.refund',return_value=entity) as gateway:
            result=issue_refund(self.payment.pk,self.admin,'Retry the original refund')
            self.assertEqual(gateway.call_args.args[0].refund_id, original_key)
        self.assertEqual(result.status,'PROCESSED')
        with patch('payments.razorpay_services.RazorpayGateway.refund') as gateway:
            issue_refund(self.payment.pk,self.admin,'Retry the original refund')
            gateway.assert_not_called()
        self.payment.refresh_from_db(); self.assertEqual(self.payment.payment_status,'REFUNDED')
        apply_capture(self.entity)
        self.payment.refresh_from_db(); self.assertEqual(self.payment.payment_status,'REFUNDED')

    def test_refund_pending_not_reported_as_processed_and_status_never_regresses(self):
        apply_capture(self.entity)
        self.booking.status='CANCELLED';self.booking.save()
        entity={'id':'rfnd_abc123','payment_id':'pay_abc123','amount':112000,'currency':'INR','status':'pending'}
        with patch('payments.razorpay_services.RazorpayGateway.refund',return_value=entity):
            result=issue_refund(self.payment.pk,self.admin,'Customer cancelled reservation')
        self.assertEqual(result.status,'PENDING')
        self.payment.refresh_from_db();self.assertEqual(self.payment.payment_status,'SUCCESS')
        apply_refund(dict(entity,status='processed'))
        apply_refund(entity)
        self.assertEqual(Refund.objects.get(payment=self.payment).status,'PROCESSED')

    def test_partial_refund_flagged_for_review(self):
        apply_capture(self.entity)
        apply_refund({'id':'rfnd_partial','payment_id':'pay_abc123','amount':100,'currency':'INR','status':'processed'})
        self.payment.refresh_from_db()
        self.assertTrue(self.payment.requires_review)
        self.assertEqual(self.payment.payment_status,'SUCCESS')

    def test_unsigned_webhook_rejected_and_no_events_created(self):
        client=APIClient()
        response=client.post('/api/payments/webhook/razorpay/', {'event':'payment.captured'},format='json')
        self.assertEqual(response.status_code,403)
        self.assertEqual(WebhookEvent.objects.count(),0)

    def test_gateway_refund_sends_stable_key_and_fixed_amount(self):
        from .gateway import RazorpayGateway
        self.payment.provider_payment_id='pay_abc123';self.payment.save()
        refund=Refund.objects.create(payment=self.payment,amount=self.payment.amount,reason='Customer requested cancellation')
        with patch('payments.gateway.RazorpayGateway.request',return_value={}) as request:
            RazorpayGateway().refund(refund)
        self.assertEqual(request.call_args.kwargs['headers']['X-Refund-Idempotency'],str(refund.refund_id))
        self.assertEqual(request.call_args.kwargs['data']['amount'],112000)


    def test_reconciliation_recovers_refund_delivered_before_capture(self):
        from django.core.management import call_command
        from io import StringIO
        refunded_entity=dict(self.entity,status='refunded')
        refund={'id':'rfnd_early','payment_id':'pay_abc123','amount':112000,'currency':'INR','status':'processed'}
        with patch('payments.gateway.RazorpayGateway.order_payments',return_value={'items':[refunded_entity]}), patch(
            'payments.gateway.RazorpayGateway.request',return_value={'items':[refund]}):
            call_command('reconcile_payments',stdout=StringIO())
        self.payment.refresh_from_db();self.booking.refresh_from_db()
        self.assertEqual(self.payment.payment_status,'REFUNDED')
        self.assertEqual(self.booking.status,'CANCELLED')
        self.assertIsNotNone(self.payment.last_reconciled_at)

    def test_checkout_after_staff_price_change_is_blocked(self):
        Booking.objects.filter(pk=self.booking.pk).update(total_amount=2000)
        with self.assertRaises(ValidationError):create_order(self.booking.pk,self.user)
        payment=apply_capture(self.entity)
        self.assertTrue(payment.requires_review)

    def test_mock_endpoint_cannot_bypass_razorpay_even_if_enabled(self):
        from payments.services import confirm_mock_payment
        with override_settings(ALLOW_MOCK_PAYMENTS=True):
            with self.assertRaises(ValidationError):confirm_mock_payment(self.booking.pk)


from concurrent.futures import ThreadPoolExecutor
from threading import Barrier
from django.db import close_old_connections, connections
from django.test import TransactionTestCase, skipUnlessDBFeature


@skipUnlessDBFeature('has_select_for_update')
@override_settings(PAYMENT_PROVIDER='razorpay')
class ConcurrentCaptureTests(TransactionTestCase):
    def test_duplicate_capture_across_connections_fulfils_once(self):
        user=get_user_model().objects.create_user(username='concurrent')
        rt=RoomType.objects.create(name='Concurrent',base_price=1000)
        room=Room.objects.create(room_number='301',room_type=rt,price_per_night=1000)
        booking=Booking.objects.create(user=user,check_in=timezone.localdate()+timedelta(days=1),
            check_out=timezone.localdate()+timedelta(days=2),total_amount=1000)
        BookingRoom.objects.create(booking=booking,room=room,price_at_booking=1000)
        payment=Payment.objects.create(booking=booking,amount=1000,payment_method='RAZORPAY',provider_order_id='order_race')
        entity={'id':'pay_race','order_id':'order_race','amount':100000,'currency':'INR','status':'captured','captured':True}
        barrier=Barrier(2)
        def capture():
            close_old_connections()
            try:
                barrier.wait(timeout=10)
                return apply_capture(entity).payment_status
            finally:
                connections["default"].close()
        with ThreadPoolExecutor(max_workers=2) as pool:
            self.assertEqual(list(pool.map(lambda _:capture(),range(2))),['SUCCESS','SUCCESS'])
        self.assertEqual(PaymentAudit.objects.filter(payment=payment,action='capture.confirmed').count(),1)
        booking.refresh_from_db();self.assertEqual(booking.status,'CONFIRMED')
