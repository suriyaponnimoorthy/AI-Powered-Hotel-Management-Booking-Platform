"""
AI provider communication + lightweight NL parsing to ground the assistant
in real hotel data before calling the LLM. The API key is read from
settings (which loads it from .env) and is NEVER sent to the frontend.
"""
import re
import json
import logging
from datetime import date

import requests
from django.conf import settings
from django.utils import timezone

from hotels.models import Room, HotelPolicy, NearbyAttraction, HotelService
from .prompts import SYSTEM_PROMPT, PLAN_MY_STAY_PROMPT, build_context_block


# ---------------------------------------------------------------------------
# Step 1: extract structured search criteria from free-text guest messages
# ---------------------------------------------------------------------------
def extract_criteria(message: str) -> dict:
    text = message.lower()
    criteria = {"guests": None, "budget": None, "preferences": []}

    guests_match = re.search(r"(\d+)\s*(people|guests|persons|adults)", text)
    if guests_match:
        criteria["guests"] = int(guests_match.group(1))
    elif "family of four" in text or "family of 4" in text:
        criteria["guests"] = 4
    elif "two people" in text or "couple" in text:
        criteria["guests"] = 2

    budget_match = re.search(r"(?:under|below|less than|within)\s*₹?\s*([\d,]+)", text)
    if budget_match:
        criteria["budget"] = int(budget_match.group(1).replace(",", ""))

    for pref, keyword in [
        ("breakfast", "breakfast"), ("balcony", "balcony"), ("wifi", "wi-fi"),
        ("wifi", "wifi"), ("pool", "pool"), ("spa", "spa"), ("gym", "gym"),
        ("parking", "parking"), ("luxury", "luxury"), ("airport transfer", "airport"),
    ]:
        if keyword in text and pref not in criteria["preferences"]:
            criteria["preferences"].append(pref)

    dates = re.findall(r'\b\d{4}-\d{2}-\d{2}\b', text)
    if dates:
        if len(dates) != 2:
            raise ValueError('Please provide two dates: YYYY-MM-DD to YYYY-MM-DD.')
        start, end = (date.fromisoformat(d) for d in dates)
        if start < timezone.localdate() or end <= start:
            raise ValueError('Choose a current or future check-in and a later check-out.')
        criteria.update(check_in=start, check_out=end)
    return criteria


def find_matching_rooms(criteria: dict, limit=5):
    qs = Room.objects.filter(is_available=True, status=Room.Status.AVAILABLE).select_related(
        "room_type").prefetch_related("amenities")

    if criteria.get("guests"):
        qs = qs.filter(room_type__max_guests__gte=criteria["guests"])
    if criteria.get("budget"):
        qs = qs.filter(price_per_night__lte=criteria["budget"])
    if criteria.get('check_in') and criteria.get('check_out'):
        from bookings.services import available_rooms_queryset
        qs = available_rooms_queryset(criteria['check_in'], criteria['check_out'],
            Room.objects.filter(is_available=True).select_related('room_type').prefetch_related('amenities'))
        if criteria.get('guests'):
            qs = qs.filter(room_type__max_guests__gte=criteria['guests'])
        if criteria.get('budget'):
            qs = qs.filter(price_per_night__lte=criteria['budget'])
    if "balcony" in criteria.get("preferences", []):
        qs = qs.filter(has_balcony=True)
    if "luxury" in criteria.get("preferences", []):
        qs = qs.filter(room_type__name__icontains="suite")

    for pref in criteria.get("preferences", []):
        if pref in ("breakfast", "wifi", "pool", "spa", "gym", "parking"):
            qs = qs.filter(amenities__name__icontains=pref)

    return qs.distinct().order_by("price_per_night")[:limit]


# ---------------------------------------------------------------------------
# Step 2: call the configured LLM provider with grounded context
# ---------------------------------------------------------------------------
def _call_anthropic(system_prompt, user_message, history=None):
    api_key = settings.AI_API_KEY
    if not api_key:
        return _mock_response(user_message)

    messages = list(history or [])
    messages.append({"role": "user", "content": user_message})

    resp = requests.post(
        "https://api.anthropic.com/v1/messages",
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        json={
            "model": settings.AI_MODEL,
            "max_tokens": 700,
            "system": system_prompt,
            "messages": messages,
        },
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    return "".join(block.get("text", "") for block in data.get("content", []) if block.get("type") == "text")


def _mock_response(user_message):
    """Deterministic offline fallback used when no AI_API_KEY is configured,
    so the concierge still works out-of-the-box for demos/local dev."""
    return (
        "Thanks for reaching out to the ABC AI Concierge! "
        "(Running in offline demo mode — add AI_API_KEY in your .env to enable "
        "live AI responses.) Based on the rooms and policies on file, please "
        "check the room list below, or contact our front desk for further help."
    )


def _dispatch(system_prompt, user_message, history=None):
    provider = settings.AI_PROVIDER
    if provider == "mock" or not settings.AI_API_KEY:
        return _mock_response(user_message)
    if provider == "anthropic":
        return _call_anthropic(system_prompt, user_message, history=history)
    raise NotImplementedError(f"AI_PROVIDER '{provider}' is not implemented yet.")


def get_ai_reply(user_message: str, history=None) -> dict:
    """
    Main entry point used by the chat view.
    Returns {"reply": str, "matched_rooms": [Room, ...]}
    """
    from .recommendations import recommend_rooms
    criteria = {"preferences": []}
    for item in (history or []) + [{"role": "user", "content": user_message}]:
        if item['role'] == 'user':
            parsed = extract_criteria(item['content'])
            criteria.update({k: v for k, v in parsed.items() if v})
    ranked = recommend_rooms(criteria, limit=5)
    matched_rooms = [item['room'] for item in ranked]
    policies = list(HotelPolicy.objects.all())
    services = list(HotelService.objects.filter(is_active=True)[:8])
    attractions = list(NearbyAttraction.objects.all()[:6])
    context_block = build_context_block(
        rooms=matched_rooms, policies=policies, services=services, attractions=attractions)
    availability = ('Dates checked against active reservations.' if criteria.get('check_in')
                    else 'No dates supplied: room suggestions are NOT confirmed date availability. Ask for YYYY-MM-DD to YYYY-MM-DD.')
    system_prompt = SYSTEM_PROMPT.format(today=timezone.localdate().isoformat()) + "\n\n" + availability + "\n" + context_block
    fallback = offline_reply(user_message, ranked, policies, services, availability)
    reply, mode = safe_dispatch(system_prompt, user_message, history, fallback)
    return {"reply": reply, "matched_rooms": matched_rooms, "mode": mode}


def safe_dispatch(system_prompt, message, history=None, fallback='Please contact the front desk.'):
    if settings.AI_PROVIDER == 'mock' or not settings.AI_API_KEY:
        return fallback, 'offline'
    try:
        reply = _dispatch(system_prompt, message, history=history)
        if not isinstance(reply, str) or not reply.strip():
            raise ValueError('Empty provider reply')
        return reply, 'live'
    except (requests.RequestException, ValueError, KeyError, TypeError, NotImplementedError):
        logging.getLogger(__name__).warning('AI provider unavailable; using grounded offline response')
        return fallback, 'offline'


def offline_reply(message, ranked, policies, services, availability):
    text = message.lower()
    if any(word in text for word in ['policy', 'check-in', 'check-out', 'cancel', 'pet', 'smoking']):
        facts = '\n'.join(f'{p.title}: {p.value}' for p in policies)
        return 'Offline concierge.\n' + (facts or 'No hotel policies are recorded. Please contact the front desk.')
    if any(word in text for word in ['service', 'airport', 'spa']):
        facts = '\n'.join(f'{s.name}: ₹{s.price} — {s.description}' for s in services)
        return 'Offline concierge.\n' + (facts or 'No services are recorded. Please contact the front desk.')
    lines = ['Offline concierge — matching rooms using hotel records.']
    for item in ranked[:3]:
        room = item['room']
        lines.append(f'Room {room.room_number} ({room.room_type.name}): ' + '; '.join(item['reasons']))
        if item['missing_preferences']:
            lines.append('Unmatched preferences: ' + ', '.join(item['missing_preferences']))
    if not ranked:
        lines.append('No rooms fit your guest count and nightly budget. Try changing either.')
    lines.extend([availability, 'Tell me your guest count, budget per room per night, and preferred amenities. Select View room to continue booking.'])
    return '\n'.join(lines)


def why_this_room(room, criteria: dict) -> str:
    """
    Powers the "✨ Why ABC AI recommends this" feature on room detail pages.
    Grounded entirely in the room's real data vs. the guest's stated criteria.
    """
    reasons = []
    if criteria.get("guests") and room.room_type.max_guests >= criteria["guests"]:
        reasons.append(f"accommodates {criteria['guests']}+ guests")
    if criteria.get("budget") and room.price_per_night <= criteria["budget"]:
        reasons.append(f"fits your ₹{criteria['budget']} budget at ₹{room.price_per_night}/night")
    for pref in criteria.get("preferences", []):
        if pref == "balcony" and room.has_balcony:
            reasons.append("has a balcony")
        elif room.amenities.filter(name__icontains=pref).exists():
            reasons.append(f"includes {pref}")

    if not reasons:
        return f"The {room.room_type.name} is one of our available rooms matching your search."
    return f"This room matches your preferences: it {', '.join(reasons)}."


def plan_my_stay(days: int, guests: int, budget, trip_type: str = "", interests=None) -> dict:
    """
    Signature "✨ Plan My Stay" feature — builds a day-by-day plan grounded
    entirely in real rooms/services/attractions, never invented data.
    """
    criteria = {"guests": guests, "budget": budget, "preferences": interests or []}
    matched_rooms = find_matching_rooms(criteria, limit=3)
    policies = HotelPolicy.objects.all()
    services = HotelService.objects.filter(is_active=True)
    attractions = NearbyAttraction.objects.all()

    context_block = build_context_block(
        rooms=matched_rooms, policies=policies, services=services, attractions=attractions,
    )
    system_prompt = PLAN_MY_STAY_PROMPT.format(today=timezone.localdate().isoformat()) + "\n\n" + context_block

    user_message = (
        f"Plan a {days}-day stay for {guests} guest(s), budget ₹{budget or 'unspecified'}, "
        f"trip type: {trip_type or 'general'}, interests: {', '.join(interests or []) or 'none specified'}."
    )
    fallback = 'Offline stay planner.\n'
    fallback += ('Suggested room: ' + matched_rooms[0].room_number + '.\n') if matched_rooms else 'No room matches your criteria.\n'
    for day in range(1, days + 1):
        attraction = list(attractions)[(day - 1) % len(attractions)] if attractions else None
        fallback += f"Day {day}: " + (f"Consider {attraction.name}; confirm opening hours with the front desk." if attraction else 'Ask the front desk for local activities.') + '\n'
    fallback += 'Room subtotal only, before tax and extras. Dates have not been checked.'
    plan_text, _ = safe_dispatch(system_prompt, user_message, fallback=fallback)

    estimated_cost = None
    if matched_rooms:
        best_room = matched_rooms[0]
        estimated_cost = best_room.price_per_night * days

    return {
        "plan": plan_text,
        "recommended_room": matched_rooms[0] if matched_rooms else None,
        "matched_rooms": list(matched_rooms),
        "estimated_cost": estimated_cost,
    }
