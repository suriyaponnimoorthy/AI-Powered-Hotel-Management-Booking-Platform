from decimal import Decimal
from django.test import TestCase
from rest_framework.test import APIClient

from accounts.models import User
from hotels.models import RoomType, Room, Amenity
from .models import AIConversation, AIMessage


class PlanMyStayTests(TestCase):
    def setUp(self):
        rt = RoomType.objects.create(name="Suite", base_price=Decimal("12000"), max_guests=4)
        self.room = Room.objects.create(room_number="701", room_type=rt, price_per_night=Decimal("12000"))
        breakfast = Amenity.objects.create(name="Breakfast")
        self.room.amenities.add(breakfast)
        self.client = APIClient()

    def test_plan_my_stay_returns_recommended_room_and_cost(self):
        resp = self.client.post("/api/ai/plan-stay/", {
            "days": 3, "guests": 4, "budget": 15000, "trip_type": "family", "interests": ["breakfast"],
        }, format="json")
        self.assertEqual(resp.status_code, 200, resp.data)
        self.assertIsNotNone(resp.data["recommended_room"])
        self.assertEqual(resp.data["recommended_room"]["room_number"], "701")
        self.assertEqual(Decimal(str(resp.data["estimated_cost"])), Decimal("36000"))  # 12000 x 3 nights

    def test_plan_my_stay_no_match_still_responds(self):
        resp = self.client.post("/api/ai/plan-stay/", {
            "days": 2, "guests": 4, "budget": 500,  # unreasonably low budget
        }, format="json")
        self.assertEqual(resp.status_code, 200)
        self.assertIsNone(resp.data["recommended_room"])

    def test_plan_my_stay_validates_days_range(self):
        resp = self.client.post("/api/ai/plan-stay/", {"days": 30, "guests": 2}, format="json")
        self.assertEqual(resp.status_code, 400)


class AIConversationHistoryTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="chatter", password="pass1234!")
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)

    def test_chat_persists_conversation_for_authenticated_user(self):
        resp = self.client.post("/api/ai/chat/", {"message": "What time is check-in?"}, format="json")
        self.assertEqual(resp.status_code, 200)
        conv_id = resp.data["conversation_id"]
        self.assertIsNotNone(conv_id)
        conversation = AIConversation.objects.get(id=conv_id, user=self.user)
        self.assertEqual(conversation.messages.count(), 2)  # user + AI

    def test_anonymous_chat_does_not_persist(self):
        anon = APIClient()
        resp = anon.post("/api/ai/chat/", {"message": "Do you have a pool?"}, format="json")
        self.assertEqual(resp.status_code, 200)
        self.assertIsNone(resp.data["conversation_id"])
        self.assertEqual(AIConversation.objects.count(), 0)

    def test_conversation_scoped_to_owner(self):
        other = User.objects.create_user(username="otherchatter", password="pass1234!")
        conv = AIConversation.objects.create(user=other, title="Not yours")
        resp = self.client.get(f"/api/ai/conversations/{conv.id}/")
        self.assertEqual(resp.status_code, 404)

    def test_list_own_conversations(self):
        self.client.post("/api/ai/chat/", {"message": "Hello"}, format="json")
        resp = self.client.get("/api/ai/conversations/")
        results = resp.data.get("results", resp.data)
        self.assertEqual(len(results), 1)
