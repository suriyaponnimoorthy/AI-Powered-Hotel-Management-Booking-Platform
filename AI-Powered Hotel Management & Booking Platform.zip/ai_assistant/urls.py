from django.urls import path
from .views import (
    ChatAPIView, RecommendAPIView, PlanMyStayAPIView,
    ConversationListAPIView, ConversationDetailAPIView,
)

urlpatterns = [
    path("chat/", ChatAPIView.as_view(), name="ai-chat"),
    path("recommend/", RecommendAPIView.as_view(), name="ai-recommend"),
    path("plan-stay/", PlanMyStayAPIView.as_view(), name="ai-plan-stay"),
    path("conversations/", ConversationListAPIView.as_view(), name="ai-conversations"),
    path("conversations/<int:pk>/", ConversationDetailAPIView.as_view(), name="ai-conversation-detail"),
]
