"""Explainable content-based ranking. No model training or behavioural tracking."""
from bookings.services import available_rooms_queryset
from hotels.models import Room


def recommend_rooms(criteria, limit=10):
    qs = Room.objects.filter(is_available=True).exclude(
        status__in=[Room.Status.MAINTENANCE, Room.Status.INACTIVE]
    ).select_related('room_type').prefetch_related('amenities')
    if criteria.get('check_in') and criteria.get('check_out'):
        qs = available_rooms_queryset(criteria['check_in'], criteria['check_out'], qs)
    else:
        qs = qs.filter(status=Room.Status.AVAILABLE)
    if criteria.get('guests'):
        qs = qs.filter(room_type__max_guests__gte=criteria['guests'])
    if criteria.get('budget') is not None:
        qs = qs.filter(price_per_night__lte=criteria['budget'])

    preferences = list(dict.fromkeys(p.lower().strip() for p in criteria.get('preferences', []) if p.strip()))
    ranked = []
    # Suitable for a small hotel's inventory; move ranking into DB/search at scale.
    for room in qs:
        amenities = [a.name.lower().replace('-', '') for a in room.amenities.all()]
        matched = [p for p in preferences if (
            (p == 'balcony' and room.has_balcony) or
            (p == 'luxury' and 'suite' in room.room_type.name.lower()) or
            any(p.replace('-', '') in a for a in amenities)
        )]
        missing = [p for p in preferences if p not in matched]
        score = round(100 * len(matched) / len(preferences)) if preferences else 0
        reasons = [f'Sleeps up to {room.room_type.max_guests} guests',
                   f'₹{room.price_per_night} per room per night before tax and extras']
        if matched:
            reasons.append('Matches: ' + ', '.join(matched))
        if criteria.get('check_in'):
            reasons.append('No active reservation overlaps your selected dates; rechecked at booking')
        ranked.append({'room': room, 'preference_score': score,
                       'reasons': reasons, 'missing_preferences': missing})
    return sorted(ranked, key=lambda r: (-r['preference_score'], r['room'].price_per_night, r['room'].id))[:limit]
