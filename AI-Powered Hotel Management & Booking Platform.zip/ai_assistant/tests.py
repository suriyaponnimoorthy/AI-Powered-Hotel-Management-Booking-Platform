from decimal import Decimal
from django.test import TestCase
from hotels.models import RoomType, Room, Amenity
from .services import extract_criteria, find_matching_rooms


class AIConciergeParsingTests(TestCase):
    def setUp(self):
        rt = RoomType.objects.create(name="Deluxe Room", base_price=Decimal("6500"), max_guests=2)
        self.room = Room.objects.create(room_number="401", room_type=rt, price_per_night=Decimal("6500"))
        breakfast = Amenity.objects.create(name="Breakfast")
        self.room.amenities.add(breakfast)

    def test_extracts_guest_count_and_budget(self):
        criteria = extract_criteria("I need a room for 2 people under ₹8000 with breakfast")
        self.assertEqual(criteria["guests"], 2)
        self.assertEqual(criteria["budget"], 8000)
        self.assertIn("breakfast", criteria["preferences"])

    def test_extracts_family_of_four(self):
        criteria = extract_criteria("Recommend a room for a family of four")
        self.assertEqual(criteria["guests"], 4)

    def test_find_matching_rooms_respects_budget(self):
        criteria = {"guests": 2, "budget": 5000, "preferences": []}
        rooms = find_matching_rooms(criteria)
        self.assertEqual(len(rooms), 0)  # room costs 6500, over budget

    def test_find_matching_rooms_within_budget(self):
        criteria = {"guests": 2, "budget": 7000, "preferences": ["breakfast"]}
        rooms = find_matching_rooms(criteria)
        self.assertEqual(len(rooms), 1)
        self.assertEqual(rooms[0].room_number, "401")
