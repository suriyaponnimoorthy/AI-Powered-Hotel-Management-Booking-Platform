from rest_framework import permissions, status
from rest_framework.throttling import ScopedRateThrottle
from django.shortcuts import get_object_or_404
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import generics

from .serializers import (
    ChatRequestSerializer, ChatResponseSerializer, RecommendRequestSerializer,
    PlanMyStayRequestSerializer, AIConversationSerializer,
)
from .services import get_ai_reply, find_matching_rooms, plan_my_stay
from .models import AIConversation, AIMessage
from hotels.serializers import RoomSerializer


class PublicAIAPIView(APIView):
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'ai'


class ChatAPIView(PublicAIAPIView):
    """
    POST /api/ai/chat/  — the ABC AI Concierge chat endpoint.
    For authenticated users, the conversation is persisted so it can be
    resumed later (never exposed to other users).
    """
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = ChatRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        conversation = None
        history = data.get('history', [])
        if data.get('conversation_id'):
            if not request.user.is_authenticated:
                return Response({'detail': 'Sign in to resume a conversation.'}, status=401)
            conversation = get_object_or_404(AIConversation, id=data['conversation_id'], user=request.user)
            stored = list(conversation.messages.order_by('-created_at', '-id')[:12])
            history = [{'role': 'user' if m.sender == 'USER' else 'assistant', 'content': m.message}
                       for m in reversed(stored)]
        try:
            result = get_ai_reply(data['message'], history=history)
        except ValueError as exc:
            return Response({'detail': str(exc)}, status=400)

        conversation_id = None
        if request.user.is_authenticated:
            if conversation is None:
                conversation = AIConversation.objects.create(
                    user=request.user, title=data["message"][:60])
            AIMessage.objects.create(conversation=conversation, sender=AIMessage.Sender.USER,
                                      message=data["message"])
            AIMessage.objects.create(conversation=conversation, sender=AIMessage.Sender.AI,
                                      message=result["reply"])
            conversation.save(update_fields=["updated_at"])
            conversation_id = conversation.id

        payload = {**result, "conversation_id": conversation_id}
        return Response(ChatResponseSerializer(payload).data)


class RecommendAPIView(PublicAIAPIView):
    """POST /api/ai/recommend/ — structured room recommendation."""
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = RecommendRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        criteria = {
            "guests": data.get("guests"),
            "budget": data.get("budget"),
            "preferences": data.get("preferences", []),
            "check_in": data.get("check_in"),
            "check_out": data.get("check_out"),
        }
        from .recommendations import recommend_rooms
        ranked = recommend_rooms(criteria, limit=10)
        rooms = [item['room'] for item in ranked]

        if rooms:
            best = rooms[0]
            summary = (
                f"I found {len(rooms)} room suggestion(s) within your guest count and nightly budget. "
                f"The {best.room_type.name} (Room {best.room_number}) is a great match — "
                f"it sleeps {best.room_type.max_guests}, and costs ₹{best.price_per_night} per night."
            )
        else:
            summary = "I couldn't find rooms matching all of those criteria — try adjusting your budget or guest count."

        return Response({
            "summary": summary,
            "method": "content_based",
            "availability_checked": bool(criteria.get('check_in')),
            "recommendations": [{**RoomSerializer(item['room']).data,
                'preference_score': item['preference_score'], 'reasons': item['reasons'],
                'missing_preferences': item['missing_preferences']} for item in ranked],
            "rooms": RoomSerializer(rooms, many=True).data,
        }, status=status.HTTP_200_OK)


class PlanMyStayAPIView(PublicAIAPIView):
    """POST /api/ai/plan-stay/ — the signature 'Plan My Stay' feature."""
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = PlanMyStayRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        result = plan_my_stay(
            days=data["days"], guests=data["guests"], budget=data.get("budget"),
            trip_type=data.get("trip_type", ""), interests=data.get("interests", []),
        )
        return Response({
            "plan": result["plan"],
            "recommended_room": RoomSerializer(result["recommended_room"]).data if result["recommended_room"] else None,
            "matched_rooms": RoomSerializer(result["matched_rooms"], many=True).data,
            "estimated_cost": result["estimated_cost"],
        })


class ConversationListAPIView(generics.ListAPIView):
    """GET /api/ai/conversations/ — resume previous AI Concierge chats."""
    serializer_class = AIConversationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return AIConversation.objects.filter(user=self.request.user)


class ConversationDetailAPIView(generics.RetrieveAPIView):
    serializer_class = AIConversationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return AIConversation.objects.filter(user=self.request.user)
