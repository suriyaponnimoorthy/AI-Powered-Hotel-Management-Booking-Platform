from rest_framework import serializers
from hotels.serializers import RoomSerializer
from .models import AIConversation, AIMessage


class HistoryMessageSerializer(serializers.Serializer):
    role = serializers.ChoiceField(choices=['user', 'assistant'])
    content = serializers.CharField(max_length=4000)


class ChatRequestSerializer(serializers.Serializer):
    message = serializers.CharField(max_length=2000)
    history = HistoryMessageSerializer(many=True, required=False, default=list)
    conversation_id = serializers.IntegerField(required=False, allow_null=True, min_value=1)

    def validate_history(self, value):
        if len(value) > 12:
            raise serializers.ValidationError('Send at most 12 history messages.')
        return value


class ChatResponseSerializer(serializers.Serializer):
    reply = serializers.CharField()
    mode = serializers.CharField(required=False)
    matched_rooms = RoomSerializer(many=True)
    conversation_id = serializers.IntegerField(required=False, allow_null=True)


class RecommendRequestSerializer(serializers.Serializer):
    guests = serializers.IntegerField(required=False, min_value=1, max_value=100)
    budget = serializers.IntegerField(required=False, min_value=1)
    preferences = serializers.ListField(child=serializers.CharField(max_length=60), max_length=20, required=False, default=list)


    check_in = serializers.DateField(required=False)
    check_out = serializers.DateField(required=False)

    def validate(self, data):
        from django.utils import timezone
        start, end = data.get('check_in'), data.get('check_out')
        if bool(start) != bool(end):
            raise serializers.ValidationError('Provide both check-in and check-out dates.')
        if start and (start < timezone.localdate() or end <= start):
            raise serializers.ValidationError('Choose a future or current check-in and a later check-out.')
        return data


class PlanMyStayRequestSerializer(serializers.Serializer):
    days = serializers.IntegerField(min_value=1, max_value=14)
    guests = serializers.IntegerField(min_value=1)
    budget = serializers.IntegerField(required=False, min_value=1)
    trip_type = serializers.CharField(required=False, allow_blank=True, default="")
    interests = serializers.ListField(child=serializers.CharField(max_length=60), max_length=20, required=False, default=list)


class AIMessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = AIMessage
        fields = ["id", "sender", "message", "created_at"]


class AIConversationSerializer(serializers.ModelSerializer):
    messages = AIMessageSerializer(many=True, read_only=True)

    class Meta:
        model = AIConversation
        fields = ["id", "title", "created_at", "updated_at", "messages"]
