from django import forms
from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST
from rest_framework.exceptions import APIException
from .models import Document
from .api_views import private_response
from . import services


class UploadForm(forms.Form):
    kind = forms.ChoiceField(label='Document type', choices=Document.Kind.choices)
    file = forms.FileField(label='Identity document (JPEG, PNG or PDF; maximum 5 MB)',
        widget=forms.ClearableFileInput(attrs={'accept': '.jpg,.jpeg,.png,.pdf'}))
    consent = forms.BooleanField(label='I consent to hotel identity verification and the retention period shown below.')


@login_required
def portal(request):
    form = UploadForm(request.POST or None, request.FILES or None)
    if request.method == 'POST' and form.is_valid():
        try:
            services.upload_document(request.user, **{'uploaded': form.cleaned_data['file'],
                'kind': form.cleaned_data['kind'], 'consent': form.cleaned_data['consent']})
            messages.success(request, 'Document securely uploaded and scanned. Hotel review is pending.')
            return redirect('kyc:portal')
        except APIException as exc:
            form.add_error(None, str(exc.detail))
    docs = Document.objects.filter(owner=request.user)[:50]
    return render(request, 'kyc/portal.html', {'form': form, 'documents': docs,
        'retention_days': settings.KYC_RETENTION_DAYS, 'enabled': settings.KYC_ENABLED})


@login_required
@require_POST
def download(request, doc_id):
    get_object_or_404(Document, pk=doc_id)
    try:
        return private_response(*services.download_document(doc_id, request.user, request.POST.get('reason', '')))
    except APIException as exc:
        messages.error(request, str(exc.detail))
        return redirect('kyc:portal')


@login_required
@require_POST
def delete(request, doc_id):
    get_object_or_404(Document, pk=doc_id)
    try:
        services.delete_document(doc_id, request.user)
        messages.success(request, 'Document deleted.')
    except APIException as exc:
        messages.error(request, str(exc.detail))
    return redirect('kyc:portal')


@login_required
def review_queue(request):
    if not services.reviewer(request.user):
        from django.core.exceptions import PermissionDenied
        raise PermissionDenied()
    if request.method == 'POST':
        from uuid import UUID
        try:
            doc_id = UUID(request.POST.get('document_id', ''))
        except (ValueError, TypeError):
            from django.http import HttpResponseBadRequest
            return HttpResponseBadRequest('Invalid document.')
        get_object_or_404(Document, pk=doc_id)
        try:
            services.review_document(doc_id, request.user, request.POST.get('status'), request.POST.get('note', ''))
            messages.success(request, 'Identity document review saved.')
        except APIException as exc:
            messages.error(request, str(exc.detail))
        return redirect('kyc:review')
    from django.utils import timezone
    return render(request, 'kyc/review.html', {'documents': Document.objects.filter(
        status=Document.Status.PENDING, expires_at__gt=timezone.now()).select_related('owner')[:100]})
