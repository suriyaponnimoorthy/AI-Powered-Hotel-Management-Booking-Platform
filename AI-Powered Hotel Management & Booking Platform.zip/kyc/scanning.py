"""ClamAV INSTREAM scanning. Errors fail closed; no shell commands or filenames."""
import socket
import struct
from django.conf import settings
from rest_framework.exceptions import ValidationError
from .storage import PrivateStorageUnavailable


def scan(data):
    if settings.KYC_SCANNER == 'disabled' and settings.DEBUG:
        return
    if settings.KYC_SCANNER != 'clamd':
        raise PrivateStorageUnavailable('Document scanning is not configured.')
    try:
        with socket.create_connection((settings.CLAMD_HOST, settings.CLAMD_PORT), timeout=10) as conn:
            conn.settimeout(20)
            conn.sendall(b'zINSTREAM\0')
            for offset in range(0, len(data), 65536):
                chunk = data[offset:offset + 65536]
                conn.sendall(struct.pack('!I', len(chunk)) + chunk)
            conn.sendall(struct.pack('!I', 0))
            result = bytearray()
            while len(result) < 4096:
                chunk = conn.recv(1024)
                if not chunk:
                    break
                result.extend(chunk)
                if b'\0' in chunk or b'\n' in chunk:
                    break
    except OSError:
        raise PrivateStorageUnavailable('Document scanner unavailable. Your upload was not accepted.') from None
    if b' FOUND' in result:
        raise ValidationError('The document failed the security scan.')
    if bytes(result).rstrip(b'\0\r\n') != b'stream: OK':
        raise PrivateStorageUnavailable('Document scanner returned an invalid result.')
