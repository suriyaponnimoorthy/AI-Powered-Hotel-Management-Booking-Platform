from django.core.exceptions import SuspiciousOperation
from .upload_handlers import PrivateMemoryUploadHandler


class PrivateUploadMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.method == 'POST' and (request.path.startswith('/identity/') or request.path.startswith('/api/identity/')):
            try:
                length = int(request.META.get('CONTENT_LENGTH') or 0)
            except ValueError:
                raise SuspiciousOperation('Invalid content length.') from None
            if length > 6 * 1024 * 1024:
                raise SuspiciousOperation('Identity upload exceeds the request limit.')
            request.upload_handlers = [PrivateMemoryUploadHandler(request)]
        return self.get_response(request)
