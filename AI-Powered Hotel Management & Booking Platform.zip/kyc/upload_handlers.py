"""Bounded memory uploads: avoid plaintext identity files in Django temp storage."""
import io
from django.conf import settings
from django.core.exceptions import SuspiciousOperation
from django.core.files.uploadhandler import FileUploadHandler
from django.core.files.uploadedfile import InMemoryUploadedFile


class PrivateMemoryUploadHandler(FileUploadHandler):
    def __init__(self, request=None):
        super().__init__(request)
        self.total = 0
        self.files = 0

    def new_file(self, *args, **kwargs):
        super().new_file(*args, **kwargs)
        self.files += 1
        if self.files > 1:
            raise SuspiciousOperation('Only one identity document may be uploaded at a time.')
        self.buffer = io.BytesIO()

    def receive_data_chunk(self, raw_data, start):
        self.total += len(raw_data)
        if self.total > settings.KYC_MAX_BYTES:
            raise SuspiciousOperation('Identity upload exceeds the maximum size.')
        self.buffer.write(raw_data)
        return None

    def file_complete(self, file_size):
        self.buffer.seek(0)
        return InMemoryUploadedFile(self.buffer, self.field_name, self.file_name,
            self.content_type, file_size, self.charset)
