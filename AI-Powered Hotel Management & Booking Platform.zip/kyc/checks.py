from pathlib import Path
from urllib.parse import urlsplit
from cryptography.fernet import Fernet
from django.conf import settings
from django.core.checks import Error, register, Tags


@register(Tags.security)
def identity_configuration(app_configs, **kwargs):
    if not settings.KYC_ENABLED:
        return []
    errors=[]
    try:
        if not settings.KYC_ENCRYPTION_KEYS:
            raise ValueError()
        for key in settings.KYC_ENCRYPTION_KEYS:
            Fernet(key.encode())
    except (ValueError, TypeError):
        errors.append(Error('Set valid KYC_ENCRYPTION_KEYS before enabling identity uploads.',id='kyc.E001'))
    if not settings.DEBUG:
        if not settings.PRIVATE_UPLOADS_USE_S3 or not settings.KYC_S3_BUCKET:
            errors.append(Error('Production identity uploads require a separate private S3 bucket.',id='kyc.E002'))
        media_bucket = settings.STORAGES["default"].get("OPTIONS", {}).get("bucket_name")
        if media_bucket and media_bucket == settings.KYC_S3_BUCKET:
            errors.append(Error('Use distinct buckets for identity documents and ordinary media.', id='kyc.E005'))
        if settings.KYC_S3_ENDPOINT:
            endpoint = urlsplit(settings.KYC_S3_ENDPOINT)
            if endpoint.scheme != "https" or not endpoint.hostname:
                errors.append(Error('Production identity storage requires an HTTPS endpoint.', id='kyc.E006'))
        if settings.KYC_SCANNER != 'clamd':
            errors.append(Error('Production identity uploads require malware scanning.',id='kyc.E003'))
    root=Path(settings.PRIVATE_UPLOAD_ROOT).resolve()
    if root.is_relative_to(settings.MEDIA_ROOT.resolve()) or root.is_relative_to(settings.STATIC_ROOT.resolve()):
        errors.append(Error('Private documents must not be stored under public media/static paths.',id='kyc.E004'))
    return errors
