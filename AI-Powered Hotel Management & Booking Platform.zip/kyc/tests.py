import io
import tempfile
from datetime import timedelta
from unittest.mock import patch
from PIL import Image
from pypdf import PdfWriter
from cryptography.fernet import Fernet
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.management import call_command
from django.test import TestCase, override_settings, Client
from django.utils import timezone
from rest_framework.test import APIClient
from rest_framework.exceptions import ValidationError, PermissionDenied
from .models import Document, DocumentAudit
from .services import upload_document, download_document, review_document, delete_document, clean_document, set_hold
from .storage import private_storage, PrivateStorageUnavailable
from .scanning import scan


def image_upload():
    data=io.BytesIO();Image.new('RGB',(20,20),'white').save(data,format='PNG')
    return SimpleUploadedFile('../../identity.html', data.getvalue(), content_type='text/html')


class IdentityTests(TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.settings=override_settings(DEBUG=True,KYC_ENABLED=True,KYC_ENCRYPTION_KEYS=[Fernet.generate_key().decode()],
            KYC_SCANNER='disabled',PRIVATE_UPLOADS_USE_S3=False,PRIVATE_UPLOAD_ROOT=self.tmp.name)
        self.settings.enable();self.addCleanup(self.settings.disable)
        User=get_user_model()
        self.owner=User.objects.create_user(username='guest')
        self.other=User.objects.create_user(username='other')
        self.staff=User.objects.create_user(username='staff',role='STAFF')
        self.admin=User.objects.create_superuser(username='reviewer',password='unused',email='review@example.com')

    def upload(self):
        return upload_document(self.owner,image_upload(),'PASSPORT',True)

    def test_encrypted_random_storage_no_public_url_in_response(self):
        doc=self.upload()
        self.assertNotIn('identity',doc.storage_key)
        with private_storage().open(doc.storage_key,'rb') as blob:
            encrypted=blob.read()
        self.assertFalse(encrypted.startswith(b'\xff\xd8'))
        data,ctype,name=download_document(doc.pk,self.owner)
        self.assertTrue(data.startswith(b'\xff\xd8'))
        self.assertEqual(ctype,'image/jpeg')
        client=APIClient();client.force_authenticate(self.owner)
        response=client.get('/api/identity/')
        self.assertNotIn('storage_key',response.content.decode())
        self.assertNotIn('content_hash',response.content.decode())

    def test_other_user_and_unprivileged_staff_cannot_download(self):
        doc=self.upload()
        for actor in [self.other,self.staff]:
            with self.assertRaises(PermissionDenied): download_document(doc.pk,actor,'Hotel identity verification')
        self.assertEqual(DocumentAudit.objects.filter(action='download.denied').count(),2)

    def test_separate_review_and_download_permissions(self):
        doc=self.upload()
        self.staff.user_permissions.add(Permission.objects.get(codename='review_document'))
        with self.assertRaises(PermissionDenied):download_document(doc.pk,self.staff,'Hotel identity verification')
        reviewed=review_document(doc.pk,self.staff,'APPROVED','Identity matches the arriving guest')
        self.assertEqual(reviewed.status,'APPROVED')

    def test_reviewer_download_requires_reason(self):
        doc=self.upload()
        with self.assertRaises(ValidationError):download_document(doc.pk,self.admin)
        download_document(doc.pk,self.admin,'Hotel identity verification')
        self.assertTrue(DocumentAudit.objects.filter(action='downloaded',actor=self.admin).exists())

    def test_reviewer_cannot_approve_own_document(self):
        doc=upload_document(self.admin,image_upload(),'PASSPORT',True)
        with self.assertRaises(PermissionDenied):review_document(doc.pk,self.admin,'APPROVED','Identity matches guest record')

    def test_reject_arbitrary_content_and_missing_consent(self):
        with self.assertRaises(ValidationError):
            upload_document(self.owner,SimpleUploadedFile('photo.jpg',b'<script>alert(1)</script>'),'PASSPORT',True)
        with self.assertRaises(ValidationError):upload_document(self.owner,image_upload(),'PASSPORT',False)
        self.assertFalse(Document.objects.exists())

    def test_missing_encryption_key_and_scanner_fail_closed(self):
        with override_settings(KYC_ENCRYPTION_KEYS=[]):
            with self.assertRaises(PrivateStorageUnavailable):self.upload()
        with override_settings(KYC_SCANNER='clamd'),patch('kyc.scanning.socket.create_connection',side_effect=OSError()):
            with self.assertRaises(PrivateStorageUnavailable):self.upload()
        self.assertFalse(Document.objects.exists())

    def test_disabled_scanner_forbidden_in_production(self):
        with override_settings(DEBUG=False,KYC_SCANNER='disabled'):
            with self.assertRaises(PrivateStorageUnavailable):scan(b'file')

    def test_malware_rejected_without_storage(self):
        with patch('kyc.services.scan',side_effect=ValidationError('Malware detected')):
            with self.assertRaises(ValidationError):self.upload()
        self.assertFalse(Document.objects.exists())

    def test_clean_pdf_accepted_active_pdf_rejected(self):
        pdf=PdfWriter();pdf.add_blank_page(width=100,height=100)
        buf=io.BytesIO();pdf.write(buf)
        self.assertEqual(clean_document(buf.getvalue())[1],'application/pdf')
        pdf.add_js('app.alert("unsafe")');buf=io.BytesIO();pdf.write(buf)
        with self.assertRaises(ValidationError):clean_document(buf.getvalue())

    def test_delete_removes_blob_and_retains_minimal_audit(self):
        doc=self.upload();key=doc.storage_key
        delete_document(doc.pk,self.owner)
        doc.refresh_from_db()
        self.assertEqual(doc.status,'DELETED');self.assertEqual(doc.storage_key,'')
        self.assertFalse(private_storage().exists(key))
        self.assertTrue(DocumentAudit.objects.filter(document_id=doc.pk,action='deleted').exists())
        with self.assertRaises(ValidationError):download_document(doc.pk,self.owner)

    def test_expiration_denies_access_before_cleanup_and_hold_prevents_purge(self):
        doc=self.upload()
        Document.objects.filter(pk=doc.pk).update(expires_at=timezone.now()-timedelta(seconds=1))
        with self.assertRaises(ValidationError):download_document(doc.pk,self.owner)
        set_hold(doc.pk,self.admin,True,'Retention required for open dispute')
        call_command('purge_expired_documents',stdout=io.StringIO())
        doc.refresh_from_db();self.assertNotEqual(doc.status,'DELETED')
        set_hold(doc.pk,self.admin,False,'Dispute resolved; release retention')
        call_command('purge_expired_documents',stdout=io.StringIO())
        doc.refresh_from_db();self.assertEqual(doc.status,'DELETED')

    def test_failed_storage_delete_blocks_access_and_cleanup_retries(self):
        doc=self.upload()
        with patch('kyc.services.private_storage') as storage:
            storage.return_value.delete.side_effect=OSError()
            with self.assertRaises(PrivateStorageUnavailable):delete_document(doc.pk,self.owner)
        doc.refresh_from_db();self.assertEqual(doc.status,'DELETE_PENDING')
        with self.assertRaises(ValidationError):download_document(doc.pk,self.owner)
        call_command('purge_expired_documents',stdout=io.StringIO())
        doc.refresh_from_db();self.assertEqual(doc.status,'DELETED')

    def test_no_get_download_and_sensitive_response_not_cached(self):
        doc=self.upload();client=APIClient();client.force_authenticate(self.owner)
        path=f'/api/identity/{doc.pk}/download/'
        self.assertEqual(client.get(path).status_code,405)
        response=client.post(path,{})
        self.assertEqual(response.status_code,200)
        self.assertIn('no-store',response['Cache-Control'])
        self.assertIn('attachment',response['Content-Disposition'])
        self.assertTrue(b"".join(response.streaming_content))

    def test_csrf_required_for_browser_document_download(self):
        doc=self.upload();client=Client(enforce_csrf_checks=True);client.force_login(self.owner)
        self.assertEqual(client.post(f'/identity/{doc.pk}/download/').status_code,403)

    def test_private_pages_and_review_permissions(self):
        self.client.force_login(self.owner)
        self.assertEqual(self.client.get('/identity/').status_code,200)
        self.assertEqual(self.client.get('/identity/review/').status_code,403)
        self.client.force_login(self.admin)
        self.assertEqual(self.client.get('/identity/review/').status_code,200)
        self.assertEqual(self.client.get('/payment-operations/').status_code,200)

    def test_old_encryption_key_retained_for_rotation(self):
        doc=self.upload()
        from django.conf import settings
        old=settings.KYC_ENCRYPTION_KEYS[0]
        with override_settings(KYC_ENCRYPTION_KEYS=[Fernet.generate_key().decode(),old]):
            self.assertTrue(download_document(doc.pk,self.owner)[0])

    def test_upload_cap(self):
        for _ in range(5):self.upload()
        with self.assertRaises(ValidationError):self.upload()
        self.assertEqual(Document.objects.count(),5)

    def test_api_upload_uses_bounded_memory_handler_and_rejects_bad_ids(self):
        from django.core.cache import cache
        cache.clear()
        client=APIClient();client.force_authenticate(self.owner)
        with patch('kyc.services.scan') as scanner:
            response=client.post('/api/identity/', {'file':image_upload(),'kind':'PASSPORT','consent':'true'},format='multipart')
        self.assertEqual(response.status_code,201,response.content)
        scanner.assert_called_once()
        self.assertEqual(client.post('/api/identity/not-a-uuid/download/',{}).status_code,404)
        self.assertEqual(Document.objects.count(),1)

    def test_multiple_files_rejected_by_upload_handler(self):
        from django.core.cache import cache
        cache.clear()
        client=APIClient();client.force_authenticate(self.owner)
        response=client.post('/api/identity/', {'file':image_upload(),'extra':image_upload(),'kind':'PASSPORT','consent':'true'},format='multipart')
        self.assertEqual(response.status_code,400)
        self.assertEqual(Document.objects.count(),0)

    def test_scanner_protocol_clean_and_infected(self):
        with override_settings(KYC_SCANNER='clamd'),patch('kyc.scanning.socket.create_connection') as connection:
            stream=connection.return_value.__enter__.return_value
            stream.recv.return_value=b'stream: OK\0'
            scan(b'test document')
            self.assertEqual(stream.sendall.call_args_list[0].args[0],b'zINSTREAM\0')
            stream.recv.return_value=b'stream: Eicar-Test-Signature FOUND\0'
            with self.assertRaises(ValidationError):scan(b'test sample')

    def test_production_configuration_checks_require_storage_and_scanning(self):
        from kyc.checks import identity_configuration
        with override_settings(DEBUG=False,KYC_SCANNER='disabled',PRIVATE_UPLOADS_USE_S3=False):
            errors=identity_configuration(None)
        self.assertTrue({'kyc.E002','kyc.E003'}.issubset({error.id for error in errors}))
