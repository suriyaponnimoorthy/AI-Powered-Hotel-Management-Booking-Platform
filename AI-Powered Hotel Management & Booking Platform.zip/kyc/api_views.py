import io
from django.http import FileResponse
from django.shortcuts import get_object_or_404
from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.throttling import ScopedRateThrottle
from .models import Document, DocumentAudit
from .serializers import DocumentSerializer, UploadSerializer
from . import services


def private_response(data, content_type, filename):
    response = FileResponse(io.BytesIO(data), content_type=content_type, as_attachment=True, filename=filename)
    response['Cache-Control'] = 'private, no-store, max-age=0'
    response['Pragma'] = 'no-cache'
    response['X-Content-Type-Options'] = 'nosniff'
    response['Content-Security-Policy'] = "sandbox; default-src 'none'"
    response['Referrer-Policy'] = 'no-referrer'
    return response


class DocumentViewSet(viewsets.GenericViewSet):
    permission_classes = [permissions.IsAuthenticated]
    lookup_value_regex = r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}'
    serializer_class = DocumentSerializer
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = 'kyc'

    def get_queryset(self):
        if getattr(self, 'swagger_fake_view', False):
            return Document.objects.none()
        qs = Document.objects.all()
        return qs if services.reviewer(self.request.user) else qs.filter(owner=self.request.user)

    def list(self, request):
        page = self.paginate_queryset(self.get_queryset())
        return self.get_paginated_response(DocumentSerializer(page, many=True).data)

    def create(self, request):
        serializer = UploadSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        doc = services.upload_document(request.user, data['file'], data['kind'], data['consent'])
        return Response(DocumentSerializer(doc).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=['post'])
    def download(self, request, pk=None):
        get_object_or_404(Document, pk=pk)
        data = services.download_document(pk, request.user, str(request.data.get('reason', '')))
        return private_response(*data)

    @action(detail=True, methods=['post'])
    def review(self, request, pk=None):
        get_object_or_404(Document, pk=pk)
        doc = services.review_document(pk, request.user, request.data.get('status'), str(request.data.get('note', '')))
        return Response(DocumentSerializer(doc).data)

    @action(detail=True, methods=['post'])
    def delete_file(self, request, pk=None):
        get_object_or_404(Document, pk=pk)
        services.delete_document(pk, request.user)
        return Response({'status': 'DELETED'})

    @action(detail=True, methods=['post'])
    def hold(self, request, pk=None):
        get_object_or_404(Document, pk=pk)
        doc = services.set_hold(pk, request.user, request.data.get('enabled'), str(request.data.get('reason', '')))
        return Response(DocumentSerializer(doc).data)

    @action(detail=True, methods=['get'])
    def audit(self, request, pk=None):
        doc = self.get_object()
        rows = DocumentAudit.objects.filter(document_id=doc.pk).values('action', 'reason', 'created_at')[:100]
        return Response(list(rows))
