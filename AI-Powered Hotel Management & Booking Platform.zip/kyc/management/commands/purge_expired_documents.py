from django.core.management.base import BaseCommand, CommandError
from django.utils import timezone
from django.db.models import F, Q
from rest_framework.exceptions import APIException
from kyc.models import Document
from kyc.services import delete_document


class Command(BaseCommand):
    help = 'Purge expired identity files, retry pending deletion, and honor retention holds.'

    def add_arguments(self, parser):
        parser.add_argument('--limit', type=int, default=100)

    def handle(self, *args, **options):
        limit = options['limit']
        if not 1 <= limit <= 1000:
            raise CommandError('--limit must be between 1 and 1000.')
        ids = Document.objects.filter(legal_hold=False).exclude(status=Document.Status.DELETED).filter(
            Q(expires_at__lte=timezone.now()) | Q(status=Document.Status.DELETE_PENDING)).order_by(F('last_purge_attempt_at').asc(nulls_first=True), 'expires_at', 'pk').values_list('pk', flat=True)[:limit]
        deleted = failed = 0
        for pk in list(ids):
            try:
                deleted += bool(delete_document(pk, expired_only=True))
            except Document.DoesNotExist:
                continue
            except APIException:
                failed += 1
            finally:
                Document.objects.filter(pk=pk).update(last_purge_attempt_at=timezone.now())
        self.stdout.write(f'Documents purged: {deleted}; cleanup failures: {failed}.')
        if failed:
            raise CommandError('Some documents require storage cleanup. Retry after checking storage.')
