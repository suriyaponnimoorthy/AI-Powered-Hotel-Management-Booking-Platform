from rest_framework import serializers
from .models import Document


class DocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Document
        fields = ['id', 'kind', 'status', 'size', 'content_type', 'created_at', 'expires_at',
                  'review_note', 'legal_hold']
        read_only_fields = fields


class UploadSerializer(serializers.Serializer):
    file = serializers.FileField()
    kind = serializers.ChoiceField(choices=Document.Kind.choices)
    consent = serializers.BooleanField()
