from django.urls import path
from . import views
app_name = 'kyc'
urlpatterns = [path('', views.portal, name='portal'), path('review/', views.review_queue, name='review'),
    path('<uuid:doc_id>/download/', views.download, name='download'),
    path('<uuid:doc_id>/delete/', views.delete, name='delete')]
