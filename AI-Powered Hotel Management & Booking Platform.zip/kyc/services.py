import hashlib
import io
import uuid
import warnings
from datetime import timedelta
from PIL import Image, UnidentifiedImageError
from pypdf import PdfReader
from cryptography.fernet import InvalidToken
from django.conf import settings
from django.core.files.base import ContentFile
from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import PermissionDenied, ValidationError, APIException, Throttled
from .models import Document, DocumentAudit
from .storage import private_storage, cipher, decrypt, PrivateStorageUnavailable
from .scanning import scan


def audit(doc, actor, action, reason=''):
    DocumentAudit.objects.create(document_id=doc.pk, actor=actor, action=action, reason=reason[:250])


def reviewer(user):
    return user.is_active and user.has_perm('kyc.review_document')


def clean_document(raw):
    """Validate actual content, reject active PDFs, strip image metadata."""
    if raw.startswith(b'%PDF-'):
        try:
            pdf = PdfReader(io.BytesIO(raw), strict=True)
            if pdf.is_encrypted or not 1 <= len(pdf.pages) <= 10:
                raise ValueError()
            forbidden = {'/JS', '/JavaScript', '/OpenAction', '/AA', '/Launch', '/EmbeddedFiles',
                         '/RichMedia', '/XFA', '/AcroForm', '/SubmitForm', '/GoToR', '/URI'}
            from pypdf.generic import DictionaryObject, ArrayObject, IndirectObject
            seen = set()
            budget = [2000]
            def inspect(obj, depth=0):
                budget[0] -= 1
                if budget[0] < 0 or depth > 25:
                    raise ValueError()
                if isinstance(obj, IndirectObject):
                    identity = (obj.idnum, obj.generation)
                    if identity in seen:
                        return
                    seen.add(identity)
                    obj = obj.get_object()
                if isinstance(obj, DictionaryObject):
                    if forbidden.intersection(obj.keys()):
                        raise ValueError()
                    for value in obj.values():
                        inspect(value, depth + 1)
                elif isinstance(obj, ArrayObject):
                    for value in obj:
                        inspect(value, depth + 1)
            # Inspect all indirect objects, including unattached objects.
            for generation, offsets in pdf.xref.items():
                if generation == 65535:
                    continue
                for object_id in offsets:
                    if object_id:
                        inspect(IndirectObject(object_id, generation, pdf))
            inspect(pdf.trailer)
            return raw, 'application/pdf'
        except Exception:
            raise ValidationError('Use a simple, unencrypted PDF of 1–10 pages without forms, links or active content.') from None
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error', Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(raw)) as image:
                if image.format not in ('JPEG', 'PNG') or image.width * image.height > 20_000_000:
                    raise ValueError()
                image.verify()
            with Image.open(io.BytesIO(raw)) as image:
                image.load()
                output = io.BytesIO()
                image.convert('RGB').save(output, format='JPEG', quality=92)
                if output.tell() > settings.KYC_MAX_BYTES:
                    raise ValueError()
                return output.getvalue(), 'image/jpeg'
    except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombWarning, Image.DecompressionBombError):
        raise ValidationError('Upload a valid JPEG, PNG or PDF within the size and page limits.') from None


def upload_document(user, uploaded, kind, consent):
    if not user.is_authenticated or not user.is_active:
        raise PermissionDenied('An active account is required.')
    if not settings.KYC_ENABLED:
        raise PrivateStorageUnavailable('Identity uploads are not enabled yet.')
    if consent is not True:
        raise ValidationError('Consent to identity verification and the retention period is required.')
    if kind not in Document.Kind.values:
        raise ValidationError('Choose a valid document type.')
    if uploaded is None or uploaded.size > settings.KYC_MAX_BYTES:
        raise ValidationError('Select a document no larger than 5 MB.')
    raw = uploaded.read(settings.KYC_MAX_BYTES + 1)
    if not raw or len(raw) > settings.KYC_MAX_BYTES:
        raise ValidationError('Empty or oversized document.')
    encryptor = cipher()
    storage = private_storage()
    doc_id = uuid.uuid4()
    with transaction.atomic():
        from accounts.models import User
        User.objects.select_for_update().get(pk=user.pk)
        if DocumentAudit.objects.filter(actor=user, action='upload.attempt',
                created_at__gte=timezone.now()-timedelta(hours=1)).count() >= 10:
            raise Throttled(wait=3600, detail='Identity upload limit reached. Please try again later.')
        DocumentAudit.objects.create(document_id=doc_id, actor=user, action='upload.attempt')
    scan(raw)
    data, content_type = clean_document(raw)
    key = None
    try:
        key = storage.save(f'{doc_id.hex}/{uuid.uuid4().hex}.enc', ContentFile(encryptor.encrypt(data)))
        with transaction.atomic():
            # Serialize uploads per owner to enforce the cap under concurrency.
            from accounts.models import User
            User.objects.select_for_update().get(pk=user.pk)
            if Document.objects.filter(owner=user).exclude(status=Document.Status.DELETED).count() >= 5:
                raise ValidationError('Delete an older document before uploading another (maximum five).')
            doc = Document.objects.create(id=doc_id, owner=user, kind=kind,
                storage_key=key, content_type=content_type, content_hash=hashlib.sha256(data).hexdigest(),
                size=len(data), scanned_at=timezone.now(), consent_at=timezone.now(),
                expires_at=timezone.now() + timedelta(days=settings.KYC_RETENTION_DAYS))
            audit(doc, user, 'uploaded')
        return doc
    except Exception as exc:
        if key:
            try:
                storage.delete(key)
            except Exception:
                # Ciphertext is still protected; record the orphan for operations.
                DocumentAudit.objects.create(document_id=doc_id, actor=user, action='storage.cleanup_required')
        if isinstance(exc, APIException):
            raise
        raise PrivateStorageUnavailable() from None


def download_document(doc_id, actor, reason=''):
    # Serialize with deletion/review; do not let a concurrent delete bypass authorization.
    with transaction.atomic():
        doc = Document.objects.select_for_update().get(pk=doc_id)
        own = doc.owner_id == actor.pk
        allowed = actor.is_active and (own or actor.has_perm('kyc.download_private_document'))
        if not allowed:
            audit(doc, actor, 'download.denied')
            denied = True
        else:
            denied = False
            if not own and not 10 <= len(reason.strip()) <= 250:
                raise ValidationError('Provide an access reason between 10 and 250 characters.')
            if doc.status in [Document.Status.DELETED, Document.Status.DELETE_PENDING] or doc.expires_at <= timezone.now():
                raise ValidationError('This document is deleted or expired.')
            try:
                with private_storage().open(doc.storage_key, 'rb') as blob:
                    encrypted = blob.read(settings.KYC_MAX_BYTES * 2 + 4096)
                data = decrypt(encrypted)
            except (OSError, InvalidToken):
                raise PrivateStorageUnavailable() from None
            audit(doc, actor, 'downloaded', reason if not own else '')
    if denied:
        raise PermissionDenied('Document access denied.')
    extension = 'pdf' if doc.content_type == 'application/pdf' else 'jpg'
    return data, doc.content_type, f'identity-document.{extension}'


@transaction.atomic
def review_document(doc_id, actor, status, note):
    if not reviewer(actor):
        raise PermissionDenied('Identity review permission is required.')
    doc = Document.objects.select_for_update().get(pk=doc_id)
    if doc.owner_id == actor.pk:
        raise PermissionDenied('You cannot review your own identity document.')
    if doc.status != Document.Status.PENDING or doc.expires_at <= timezone.now():
        raise ValidationError('Only an unexpired pending document can be reviewed.')
    if status not in [Document.Status.APPROVED, Document.Status.REJECTED]:
        raise ValidationError('Choose APPROVED or REJECTED.')
    note = note.strip()
    if not 10 <= len(note) <= 250:
        raise ValidationError('Provide a review note between 10 and 250 characters; do not enter ID numbers.')
    doc.status, doc.review_note, doc.reviewed_by, doc.reviewed_at = status, note, actor, timezone.now()
    doc.save(update_fields=['status', 'review_note', 'reviewed_by', 'reviewed_at'])
    audit(doc, actor, 'review.' + status.lower(), note)
    return doc


def delete_document(doc_id, actor=None, expired_only=False):
    with transaction.atomic():
        doc = Document.objects.select_for_update().get(pk=doc_id)
        if actor and doc.owner_id != actor.pk:
            raise PermissionDenied('Only the document owner can request deletion.')
        if doc.legal_hold:
            if actor:
                raise ValidationError('A retention hold prevents deletion. Contact the hotel.')
            return False
        if doc.status == Document.Status.DELETED:
            return True
        if expired_only and doc.expires_at > timezone.now() and doc.status != Document.Status.DELETE_PENDING:
            return False
        key = doc.storage_key
        doc.status = Document.Status.DELETE_PENDING
        doc.save(update_fields=['status'])
        audit(doc, actor, 'deletion.requested')
    # If deletion fails, DELETE_PENDING denies downloads and the job retries.
    try:
        private_storage().delete(key)
    except Exception:
        raise PrivateStorageUnavailable('Deletion queued. Storage cleanup will be retried.') from None
    with transaction.atomic():
        doc = Document.objects.select_for_update().get(pk=doc_id)
        doc.storage_key, doc.content_hash, doc.review_note = '', '', ''
        doc.size, doc.status = 0, Document.Status.DELETED
        doc.save(update_fields=['storage_key', 'content_hash', 'review_note', 'size', 'status'])
        audit(doc, actor, 'deleted')
    return True


@transaction.atomic
def set_hold(doc_id, actor, enabled, reason):
    if not actor.is_active or not actor.has_perm('kyc.manage_document_hold'):
        raise PermissionDenied('Retention hold permission is required.')
    if type(enabled) is not bool or not 10 <= len(reason.strip()) <= 250:
        raise ValidationError('Provide a boolean hold and a reason between 10 and 250 characters.')
    doc = Document.objects.select_for_update().get(pk=doc_id)
    if doc.status in [Document.Status.DELETE_PENDING, Document.Status.DELETED]:
        raise ValidationError('Deleted documents cannot be placed on hold.')
    doc.legal_hold = enabled
    doc.save(update_fields=['legal_hold'])
    audit(doc, actor, 'hold.placed' if enabled else 'hold.released', reason)
    return doc
