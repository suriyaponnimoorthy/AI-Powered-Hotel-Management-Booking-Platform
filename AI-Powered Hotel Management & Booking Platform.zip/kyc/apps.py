from django.apps import AppConfig


class KycConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kyc'
    verbose_name = 'Private identity documents'

    def ready(self):
        from . import checks  # noqa: F401
