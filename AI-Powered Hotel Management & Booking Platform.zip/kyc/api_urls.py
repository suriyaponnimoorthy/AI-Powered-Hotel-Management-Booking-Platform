from rest_framework.routers import DefaultRouter
from .api_views import DocumentViewSet
router = DefaultRouter()
router.register('', DocumentViewSet, basename='identity-document')
urlpatterns = router.urls
