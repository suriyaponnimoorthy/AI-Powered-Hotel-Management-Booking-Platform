import uuid
from django.conf import settings
from django.db import models


class Document(models.Model):
    class Kind(models.TextChoices):
        PASSPORT = 'PASSPORT', 'Passport'
        DRIVING_LICENCE = 'DRIVING_LICENCE', 'Driving licence'
        OTHER_ID = 'OTHER_ID', 'Other government ID (mask unnecessary details)'

    class Status(models.TextChoices):
        PENDING = 'PENDING', 'Awaiting review'
        APPROVED = 'APPROVED', 'Approved'
        REJECTED = 'REJECTED', 'Rejected'
        DELETE_PENDING = 'DELETE_PENDING', 'Deletion in progress'
        DELETED = 'DELETED', 'Deleted'

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name='kyc_documents')
    kind = models.CharField(max_length=20, choices=Kind.choices)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    storage_key = models.CharField(max_length=250, blank=True)
    content_type = models.CharField(max_length=50)
    content_hash = models.CharField(max_length=64, blank=True)
    size = models.PositiveIntegerField()
    scanned_at = models.DateTimeField()
    consent_at = models.DateTimeField()
    expires_at = models.DateTimeField(db_index=True)
    last_purge_attempt_at = models.DateTimeField(null=True, blank=True, db_index=True)
    legal_hold = models.BooleanField(default=False)
    review_note = models.CharField(max_length=250, blank=True)
    reviewed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True,
        on_delete=models.SET_NULL, related_name='reviewed_kyc_documents')
    reviewed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        permissions = [('review_document', 'Review and approve identity documents'),
                       ('download_private_document', 'Download private identity documents'),
                       ('manage_document_hold', 'Place or release document retention holds')]


class DocumentAudit(models.Model):
    # No filenames, ID numbers, file contents or signed storage URLs in logs.
    document_id = models.UUIDField(db_index=True)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL)
    action = models.CharField(max_length=40)
    reason = models.CharField(max_length=250, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
