from django.contrib import admin
from .models import Document, DocumentAudit


class ReadOnlyAuditAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(Document)
class DocumentAdmin(ReadOnlyAuditAdmin):
    list_display = ['id', 'owner', 'kind', 'status', 'expires_at', 'legal_hold']
    fields = ['id', 'owner', 'kind', 'status', 'expires_at', 'legal_hold', 'created_at']
    list_filter = ['status', 'kind', 'legal_hold']


@admin.register(DocumentAudit)
class DocumentAuditAdmin(ReadOnlyAuditAdmin):
    list_display = ['document_id', 'actor', 'action', 'created_at']
    fields = ['document_id', 'actor', 'action', 'reason', 'created_at']
