"""Private blob access, with application encryption even on local disks."""
from cryptography.fernet import Fernet, MultiFernet, InvalidToken
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from rest_framework.exceptions import APIException


class PrivateStorageUnavailable(APIException):
    status_code = 503
    default_detail = 'Private document storage is unavailable. Please try again later.'


def cipher():
    try:
        if not settings.KYC_ENCRYPTION_KEYS:
            raise ValueError()
        return MultiFernet([Fernet(key.encode()) for key in settings.KYC_ENCRYPTION_KEYS])
    except (ValueError, TypeError):
        raise PrivateStorageUnavailable('Document encryption is not configured.') from None


def private_storage():
    if settings.PRIVATE_UPLOADS_USE_S3:
        if not settings.KYC_S3_BUCKET:
            raise PrivateStorageUnavailable()
        from storages.backends.s3 import S3Storage
        encryption = {'ServerSideEncryption': 'AES256'}
        if settings.KYC_S3_KMS_KEY_ID:
            encryption = {'ServerSideEncryption': 'aws:kms', 'SSEKMSKeyId': settings.KYC_S3_KMS_KEY_ID}
        return S3Storage(bucket_name=settings.KYC_S3_BUCKET,
            region_name=settings.KYC_S3_REGION, endpoint_url=settings.KYC_S3_ENDPOINT or None,
            default_acl=None, querystring_auth=True, file_overwrite=False,
            object_parameters=encryption, location='private-identity')
    if not settings.DEBUG:
        raise PrivateStorageUnavailable('Production identity uploads require private cloud storage.')
    return FileSystemStorage(location=settings.PRIVATE_UPLOAD_ROOT, base_url=None,
        file_permissions_mode=0o600, directory_permissions_mode=0o700)


def decrypt(data):
    try:
        return cipher().decrypt(data)
    except InvalidToken:
        raise PrivateStorageUnavailable('Unable to decrypt this document.') from None
